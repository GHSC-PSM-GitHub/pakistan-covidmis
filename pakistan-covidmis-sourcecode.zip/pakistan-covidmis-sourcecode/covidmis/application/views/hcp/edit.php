                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'hcp/index';?>">
                                        <i class="fa fa-arrow-left"></i> Back
                                    </a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <!-- <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Two Column Form</h5>
                                                </div>
                                            </div> -->
                                            <div class="panel-body">
                                                <h5 class="underline mt-n"><?= $page_title;?></h5>
                                                <form method="POST" action="<?= base_url().'hcp/edit/'.$hcp[0]['id'];?>">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="date">Date</label>
                                                                <div class='input-group datepicker' id='datepicker'>
                                                                    <input type='text' class="form-control" name="date" id="date" placeholder="Select Date" value="<?= date('m/d/Y', strtotime($hcp[0]['date']));?>" />
                                                                    <span class="input-group-addon">
                                                                        <span class="glyphicon glyphicon-calendar">
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="province_id">Province</label>
                                                                <select class="select2 form-control" id="province_id" name="province_id">
                                                                <?php if(!empty($provinces[0]['pk_id'])):?>
                                                                    <?php foreach($provinces as $province):?>
                                                                        <?php $sel = ($province['pk_id'] == $hcp[0]['province_id'])?'selected':'';?>
                                                                        <option value="<?= $province['pk_id'];?>" <?= $sel;?>><?= $province['location_name'];?></option>
                                                                    <?php endforeach;?>
                                                                <?php endif;?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="total_doctors">HCP Doctors</label>
                                                                <input type="text" class="form-control" id="total_doctors" name="total_doctors" placeholder="Enter HCP Doctors" value="<?= $hcp[0]['total_doctors'];?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="total_nurses">HCP Nurses</label>
                                                                <input type="text" class="form-control" id="total_nurses" name="total_nurses" placeholder="Enter HCP Nurses" value="<?= $hcp[0]['total_nurses'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="other_health_staff">HCP Other Health Staff</label>
                                                                <input type="text" class="form-control" id="other_health_staff" name="other_health_staff" placeholder="Enter HCP Other Health Staff" value="<?= $hcp[0]['other_health_staff'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="total_infected">HCP Total HCWs infected till date</label>
                                                                <input type="text" class="form-control" id="total_infected" name="total_infected" placeholder="Enter HCP Total HCWs infected till date" value="<?= $hcp[0]['total_infected'];?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="total_in_isolation">HCP In Isolation (Home / Others)</label>
                                                                <input type="text" class="form-control" id="total_in_isolation" name="total_in_isolation" placeholder="Enter HCP In Isolation (Home / Others)" value="<?= $hcp[0]['total_in_isolation'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="total_in_hospital">HCP In Hospital</label>
                                                                <input type="text" class="form-control" id="total_in_hospital" name="total_in_hospital" placeholder="Enter HCP In Hospital" value="<?= $hcp[0]['total_in_hospital'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="total_stable">HCP Stable</label>
                                                                <input type="text" class="form-control" id="total_stable" name="total_stable" placeholder="Enter HCP Stable" value="<?= $hcp[0]['total_stable'];?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="total_on_ventilator">HCP On Ventilator</label>
                                                                <input type="text" class="form-control" id="total_on_ventilator" name="total_on_ventilator" placeholder="Enter HCP On Ventilator" value="<?= $hcp[0]['total_on_ventilator'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="total_recovered_or_discharged">HCP Recovered/Discharged</label>
                                                                <input type="text" class="form-control" id="total_recovered_or_discharged" name="total_recovered_or_discharged" placeholder="Enter HCP Recovered/Discharged" value="<?= $hcp[0]['total_recovered_or_discharged'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="total_died">HCP Died</label>
                                                                <input type="text" class="form-control" id="total_died" name="total_died" placeholder="Enter HCP Died" value="<?= $hcp[0]['total_died'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 text-right">
                                                            <button type="submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                                <!-- /.row -->
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->