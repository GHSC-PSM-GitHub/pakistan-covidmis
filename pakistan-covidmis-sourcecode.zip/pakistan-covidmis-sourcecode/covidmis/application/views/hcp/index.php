                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'hcp/create';?>"><i class="fa fa-plus"></i> Add New</a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5><?= $page_title;?></h5>
                                                </div>
                                            </div>
                                            <div class="panel-body p-20" style="overflow: auto;">
                                                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 10%; text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>Total Doctors</th>
                                                            <th>Total Nurses</th>
                                                            <th>Other Health Staff</th>
                                                            <th>Total HCWs infected till date</th>
                                                            <th>In Isolation (Home / Others)</th>
                                                            <th>In Hospital</th>
                                                            <th>Stable</th>
                                                            <th>On Ventilator</th>
                                                            <th>Recovered / Discharged</th>
                                                            <th>Total Died</th>
                                                            <th style="text-align: center; width: 10%">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tfoot>
                                                        <tr>
                                                            <th style="text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>Total Doctors</th>
                                                            <th>Total Nurses</th>
                                                            <th>Other Health Staff</th>
                                                            <th>Total HCWs infected till date</th>
                                                            <th>In Isolation (Home / Others)</th>
                                                            <th>In Hospital</th>
                                                            <th>Stable</th>
                                                            <th>On Ventilator</th>
                                                            <th>Recovered / Discharged</th>
                                                            <th>Total Died</th>
                                                            <th style="text-align: center;">Action</th>
                                                        </tr>
                                                    </tfoot>
                                                    <tbody>
                                                    <?php if(!empty($hcps[0]['id'])):?>
                                                        <?php $loop = 0;?>
                                                        <?php foreach($hcps as $hcp):?>
                                                            <tr>
                                                                <td style="text-align: center;"><?= ++$loop;?></td>
                                                                <td><?= date('d F, Y', strtotime($hcp['date']));?></td>
                                                                <td><?= $hcp['province_name'];?></td>
                                                                <td><?= $hcp['total_doctors'];?></td>
                                                                <td><?= $hcp['total_nurses'];?></td>
                                                                <td><?= $hcp['other_health_staff'];?></td>
                                                                <td><?= $hcp['total_infected'];?></td>
                                                                <td><?= $hcp['total_in_isolation'];?></td>
                                                                <td><?= $hcp['total_in_hospital'];?></td>
                                                                <td><?= $hcp['total_stable'];?></td>
                                                                <td><?= $hcp['total_on_ventilator'];?></td>
                                                                <td><?= $hcp['total_recovered_or_discharged'];?></td>
                                                                <td><?= $hcp['total_died'];?></td>
                                                                <td style="text-align: center;">
                                                                    <a href="<?= base_url().'hcp/edit/'.$hcp['id'];?>">
                                                                        <i class="fa fa-edit"></i>
                                                                    </a> &nbsp;&nbsp;
                                                                    <a href="<?= base_url().'hcp/delete/'.$hcp['id'];?>">
                                                                        <i class="fa fa-trash"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->