 <style type="text/css">
        table {
            width:  80%;
            margin: auto;
        }
        td {
           
        }
        .scrollingTable {
            width: 70em;
            overflow-y: auto;
        }
    </style>
    <script type="text/javascript">
        function makeTableScroll() {
            // Constant retrieved from server-side via JSP
            var maxRows = 6;

            var table = document.getElementById('myTable');
            var wrapper = table.parentNode;
            var rowsInTable = table.rows.length;
            var height = 0;
            if (rowsInTable > maxRows) {
                for (var i = 0; i < maxRows; i++) {
                    height += table.rows[i].clientHeight;
                }
                wrapper.style.height = height + "px";
            }
        }
    </script>
       
    </head>
    
    <body onload="makeTableScroll();">
   
<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" >
                    <div class="panel-heading" style="background-color:#f8b32d;">
                        <div class="panel-title">
                            <h6 style="color:white;" class="panel-title txt-light"><?= $page_title; ?></h6>
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                            <form method="post" action="<?php echo base_url("Admin/save_data"); ?>">
                                    <!-- Row -->
                                      <?php
    if (isset($fetch_data) ) {
//        print_r($fetch_data); exit;
        ?>  
                                    <div class="col-md-12">
                                        <div class="card m-b-30">
                                            <div class="card-body">
                                                <div class="form-group row ">
                                                      <?php
            foreach ($fetch_data as $row) {
              //  $district_id = $row['district_id'];
//                 print_r($row['quantity']); exit;
                ?>
                                                    <div class="col-md-12">
                                                        <div class="form-group row ">
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"  >Vaccination Date </label>
                                                                <div class="controls">
                                                                    <input  type="date" class="form-control" maxlength="40" name="date" value="<?php echo $row['date'] ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"   >First Dose</label>
                                                                <div class="controls">
                                                                    <input  type="number" class="form-control" maxlength="8" name="first_dose" value="<?php echo $row['first_dose'] ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"   >Fully Vaccinated</label>
                                                                <div class="controls">
                                                                    <input  type="number" class="form-control" maxlength="8" name="full_vaccinated" value="<?php echo $row['full_vaccinated'] ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"   >Booster 1</label>
                                                                <div class="controls">
                                                                    <input  type="number" class="form-control" maxlength="8" name="booster_1" value="<?php echo $row['booster_1'] ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"  >Booster 2</label>
                                                                <div class="controls">
                                                                    <input  type="number" class="form-control" maxlength="8" name="booster_2" value="<?php echo $row['booster_2'] ?>">
                                                                </div>
                                                            </div>
                                                             <input type="hidden" name="hidden_id" value="<?php echo $row['pk_id']; ?>" />
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"   ></label>
                                                                <div class="controls">
                                                                    <input class="btn btn-success" type="submit" name="update" value="Update"/>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!--</div>-->
                                                    </div>
            <?php } ?>

                                                </div>
                                            </div>
                                        </div>  
                                    </div>
                                     <?php
    } else {
        ?>
                                    
                                    <div class="col-md-12">
                                        <div class="card m-b-30">
                                            <div class="card-body">
                                                <div class="form-group row ">
                                                    <div class="col-md-12">
                                                        <div class="form-group row ">
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"  >Vaccination Date </label>
                                                                <div class="controls">
                                                                    <input  type="date" class="form-control" maxlength="40" name="date" value="<?php echo date("Y-m-d") ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"   >First Dose</label>
                                                                <div class="controls">
                                                                    <input  type="number" class="form-control" maxlength="8" name="first_dose" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"   >Fully Vaccinated</label>
                                                                <div class="controls">
                                                                    <input  type="number" class="form-control" maxlength="8" name="full_vaccinated" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"   >Booster 1</label>
                                                                <div class="controls">
                                                                    <input  type="number" class="form-control" maxlength="8" name="booster_1" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"  >Booster 2</label>
                                                                <div class="controls">
                                                                    <input  type="number" class="form-control" maxlength="8" name="booster_2" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"   ></label>
                                                                <div class="controls">
                                                                    <input class="form-control btn btn-success btn-sm" type="submit" name="save"  value="Add"/>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!--</div>-->
                                                    </div>

                                                </div>
                                            </div>
                                        </div>  
                                    </div>
                                          <?php
    }
    ?>
                                </form>
                                                    
   <div>
                                    
                                  <h4>Record</h4>
                       <?php         
                       if (empty($from_date)) {
         $from_date = date('Y-m-01', strtotime('-1 month'));
    }
    if (empty($to_date)) {
        $to_date = date('Y-m-d');
    }
    ?>
                                  
                                  <form method="post" action="<?php echo base_url("Admin/index"); ?>">  
                                      <div class="col-md-12">
                                        <div class="card m-b-30">
                                            <div class="card-body">
                                                <div class="form-group row ">
                                                    <div class="col-md-12">
                                                        <div class="form-group row ">
                                                            <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"  >From Date </label>
                                                                <div class="controls">
                                                                    <input  type="date" class="form-control" maxlength="40" name="from_date" value="<?php echo $from_date ?>">
                                                                </div>
                                                            </div>
                                                         <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"  >To Date </label>
                                                                <div class="controls">
                                                                    <input  type="date" class="form-control" maxlength="40" name="to_date" value="<?php echo $to_date ?>">
                                                                </div>
                                                            </div>
                                                           <div class="col-md-2" id="show_receive_from_suppliers" >
                                                                <label class="example-text-input"></label>
                                                                <div class="controls">
                                                                    <input class="form-control btn  btn-warning btn-sm" type="submit" name="save"  value="Search"/>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!--</div>-->
                                                    </div>

                                                </div>
                                            </div>
                                        </div>  
                                    </div>
                                  </form>
                       <br>           
  <div class="scrollingTable">                                
<table  id="myTable" class=" table table-bordered table-condensed table-striped"  >
    <tr>
        <th>Sr.#</th>
        <th>Date</th>
        <th>First Dose</th>
        <th>Fully Vaccinated</th> 
        <th>Booster 1</th>
        <th>Booster 2</th>
        <th>Update</th>
    </tr>
    <?php
    $i = 1;
    foreach ($display as $row) {
        echo "<tr>";
        echo "<td>" . $i . "</td>";
        echo "<td>" . $row['date'] . "</td>";
        echo "<td>" . $row['first_dose'] . "</td>";
        echo "<td>" . $row['full_vaccinated'] . "</td>";
        echo "<td>" . $row['booster_1'] . "</td>";
        echo "<td>" . $row['booster_2'] . "</td>";
        echo "<td>"
        ?> <a class="btn btn-primary btn-sm" href="<?=base_url('admin/update_data/'.$row['pk_id']); ?> "> Edit</a> <?php
        "<td>";
        echo "</tr>";
        $i++;
    }
    ?>
</table>  
                                  </div>
                       <br>
                                </div>  

                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<!-- ========== END MAIN CONTENT ========== -->
