  <?php
//        echo '<pre>';
//    print_r($vents_drill);exit;
$label = 'Health Facility';
$label2 = 'Health Facilities ';
//   ------------------ Disease wise data START---------------------
    $label_arr = '["DHO"," DHQ"," Hospital Y"," Hospital Z","City Hospital"]';
    $data_arr = '[11,5,2,6,8]';
//    foreach ($vents_drill as $k => $val) {
//           $label_arr .= '"' . $vents_drill[$k]['name'] . '",';
//           $data_arr .= $vents_drill[$k]['total'] . ",";  
//    }
//    $label_arr = substr_replace($label_arr, "", -1);
//    $label_arr .= ']';
//    $data_arr = substr_replace($data_arr, "", -1);
//    $data_arr .= ']';

//echo $label_arr;
//echo $data_arr; exit;
//    ------------------ Disease wise data END-----------------------
   
    ?>

<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" >
                    <div class="panel-heading" style="background-color:#1473b3;">
                        <div class="panel-title">
                            <h6 style="color:white;" class="panel-title txt-light"><?php echo $label . ' Dashboard'; ?></h6>
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                   <div class="row">
               <div><b>Due to Non-Availability of Actual Data, Below Graph have Dummy Data. </b></div>
            <div class="col-lg-12">
                <div class="panel panel-default card-view">
                    <div class="panel-heading">
                        <div class="pull-left">
                            <h2 class="panel-title txt-dark"> <?php echo ' ' .$label2  ; ?></h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-wrapper collapse in">
                        <div class="panel-body">
                            <canvas id="myChart1" height="280"></canvas>
                        </div>
                    </div>

                </div>	
            </div>
        </div> 
     
        <!--<div><b>Click on the Graph for Drilldown</b></div>-->
        <input type="hidden" name="from_date" id="from_date" value="<?php echo $from_date; ?> ">
        <input type="hidden" name="to_date" id="to_date" value="<?php echo $to_date; ?> ">
        <input type="hidden" name="label_id" id="label_id" value="<?php echo $label; ?> ">       
                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->
<script>
    /*Chartjs Init*/

    $(document).ready(function () {
        "use strict";

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx Disease Wise PAtients START xxxxxxxxxxxxxxxxxxxxxxxx
        var ctx = document.getElementById("myChart1").getContext("2d");

        var config = {
            type: 'bar',
            data: {
                labels: <?php echo $label_arr; ?>,
                datasets: [{
                        label: "Patients",
                        type: "bar",
                        backgroundColor: [
                             "rgba(196, 88, 80,1)",
                            "rgba(237, 232, 83,1)",
                            "rgba(62, 149, 205,1)",
                            "rgba(142, 94, 162,1)",
                            "rgba(60, 186, 159,1)",
                            "rgba(232, 195, 185,1)",
                           
                            "rgba(139,195,74,1)",
                            "rgba(237, 132, 90,1)",
                            "rgba(33,150,243,1)",
                            "rgba(247, 184, 35,1)",
                            "rgba(250, 85, 192,1)"

                        ],
                        data: <?php echo $data_arr; ?>
                    }
                ]
            },
            options: {
                legend: {display: false},
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 1,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent
            }
        }; // end of var config


        var myLiveChart = new Chart(ctx, config);

        function chartClickEvent(event, array)
        {
            if (myLiveChart === undefined || myLiveChart == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }

            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];

            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            var label_id = document.getElementById("label_id").value;

//   var url = "http://example.com/?label=" + label + "&value=" + value;
//            window.open("http://localhost/drap_application_system/dashboard/list_for_assign", '_blank');
//            window.open("<?php echo base_url(); ?>dashboard/vent_drill_hf/" + label + "/" + from_date + "/" + to_date + "/" + label_id, '_blank');
            console.log(url);

            alert(series + ':' + label + ':' + value);
        }
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx Disease Wise PAtients END xxxxxxxxxxxxxxxxxxxxxxxx


    });


</script>
