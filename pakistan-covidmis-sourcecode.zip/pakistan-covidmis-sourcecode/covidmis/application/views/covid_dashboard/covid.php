    <?php
//    echo '<pre>';
//    print_r($total_positive);exit;
    
    if (empty($from_date)) {
         $from_date = date('Y-m-01', strtotime('-6 month'));
    }
// $from_date  = date('2020-06-01');
    if (empty($to_date)) {
        $to_date = date('Y-m-d');
    }

    //    ------------------ Total and Positive Cases PCR & RAT START---------------------
   if(!empty($total_tests)){
    $total_pcr = $total_rat = $positive_pcr = $positive_rat = ''; 
    foreach ($total_tests as $k => $val) {
        $total_pcr = $val['pcr']; 
        $total_rat = $val['rat'];
            }
    foreach ($total_positive as $k => $val) {
        $positive_pcr = $val['pcr_positive']; 
        $positive_rat = $val['rat_positive'];
            }
            $negative_pcr = $total_pcr - $positive_pcr ;
            $negative_rat = $total_rat - $positive_rat ;
            
     $pcr = "[" . round($total_pcr/1000) . "," . round($positive_pcr/1000) . "," . round($negative_pcr/1000) . "]";
    $rat = "[" . round($total_rat/1000) . "," . round($positive_rat/1000) . "," . round($negative_rat/1000) . "]"  ;   
   }
   else{
       $pcr = '[0,0,0]';
    $rat = '[0,0,0]';
   }
//echo $pcr;
//echo $rat; exit;
//    ------------------ Total and Positive Cases PCR & RAT END-----------------------
    
//    ------------------ Disease wise data START---------------------
   if(!empty($vents_data))
   { $vent_label = '[';
    $vent_data = '[';
    foreach ($vents_data as $k => $val) {
        foreach($val as $label => $sum)
        {
               $vent_data .= $sum . ",";
            $vent_label .= '"' . $label. '",';
        }
            }
    $vent_label = substr_replace($vent_label, "", -1);
    $vent_label .= ']';
    $vent_data = substr_replace($vent_data, "", -1);
    $vent_data .= ']';
   }
   else{
        $vent_label = '["No Data"]';
    $vent_data = '[0]';
   }
//echo $vent_label;
//echo $vent_data; exit;
//    ------------------ Disease wise data END-----------------------

    //    ------------------ Province WIse Positive DATA START---------------------
   if(!empty($positive_cases))
   {$positive_label = '[';
    $positive_data = '[';
    foreach ($positive_cases as $k => $val) {
//      print_r($val); exit;
      $sum = $val['pcr']+ $val['rat'];
               $positive_data .= $sum . ",";
            $positive_label .= '"' . $val['province']. '",';
        
            }
    $positive_label = substr_replace($positive_label, "", -1);
    $positive_label .= ']';
    $positive_data = substr_replace($positive_data, "", -1);
    $positive_data .= ']';
   }
   else{
       $positive_label = '["No Data"]';
    $positive_data = '[0]';
   }
//echo $positive_label;
//echo $positive_data; exit;
//    ------------------ Province WIse Positive DATA END-----------------------
    
    //    ------------------ Death wise data START---------------------
 if(!empty($deaths_data))
 {$death_label = '[';
    $death_data = '[';
    foreach ($deaths_data as $k => $val) {
        foreach($val as $label => $sum)
        {
               $death_data .= $sum . ",";
            $death_label .= '"' . $label. '",';
        }
            }
    $death_label = substr_replace($death_label, "", -1);
    $death_label .= ']';
    $death_data = substr_replace($death_data, "", -1);
    $death_data .= ']';
 }
 else{
      $death_label = '["No Data"]';
    $death_data ='["0"]';
 }
//echo $death_label;
//echo $death_data; exit;
//    ------------------ Death wise data END-----------------------
    
 //    ------------------ Oxygen Beds DATA START---------------------
 if(!empty($oxygen_beds)) {
 $bed_label = '[';
    $bed_data = '[';
    foreach ($oxygen_beds as $k => $val) {
        foreach($val as $label => $sum)
        {
           $bed_data .= $sum . ",";
            $bed_label .= '"' . $label. '",';
        }
                    }
    $bed_label = substr_replace($bed_label, "", -1);
    $bed_label .= ']';
    $bed_data = substr_replace($bed_data, "", -1);
    $bed_data .= ']';
 }
 else{
      $bed_label = '["No Data"]';
    $bed_data = '[0]';
 }
//echo $bed_label;
//echo $bed_data; exit;

//    ------------------ Oxygen Beds DATA END-----------------------
    
    ?>
<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" >
                    <div class="panel-heading" style="background-color:#1473b3;">
                        <div class="panel-title">
                            <h6 style="color:white;" class="panel-title txt-light"><?= $page_title; ?></h6>
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                 <div class="row" >
                    <div class="col-md-12" >
                        <form method="post"  name="form1" action="../dashboard/covid">
                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="email_inline">From Month </label>
                                    <input class="form-control"  type="date" id ="from_date" name="from_date" value="<?php echo $from_date ?>">
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="pwd_inline">To Month</label>
                                    <input class="form-control" type="date" id ="to_date" name="to_date" value="<?php echo $to_date ?>" >
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="pwd_inline">&nbsp;</label>
                                    <input class="btn btn-success form-control"  type="submit" name="save_btn1" id="save_btn1" value="Go"> 
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Covid Test (In Thousands)</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="myChart"  height="340"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                    <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Positive Cases Province Wise</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="piechart" height="200"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>
                </div>
                      <div class="row">
                           <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Oxygen Beds</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="bed" height="430"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>
                   <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Ventilators</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="ventilator" height="430"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>
                </div>
                <div><b>Due to Non-Availability of Actual Data, Below Graphs have Dummy Data. </b></div>
                <div class="row">
                
                         <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Gender Wise Positive Cases</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="gender" height="200"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>
                       <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Age Wise Confirmed Cases</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="age" height="200"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>      
                </div>
                    <div class="row">
                 
                              <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Death Cases</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="deathcases" height="200"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>
                         <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Incident Ratio</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="incident" height="400"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>
                         
                </div>
                <div><b>Click on the Graph for Drilldown</b></div>        
                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->
<script>
    /*Chartjs Init*/

    $(document).ready(function () {
        //        "use strict";

//        ----------------------- COVID TEST START -------------------------------

var ctx_test = document.getElementById("myChart").getContext("2d");

        var config_test = {
            type: 'bar',
            data:  {
                labels: ["Total", "Positive", "Negative"],
                datasets: [
                    {
                        type: "bar",
                        backgroundColor: "#edc61a",
                        borderColor: "rgba(54, 162, 235, 1)",
                        borderWidth: 1,
                        label: "PCR",
                        data: <?php echo $pcr; ?>
                    },
                    {
                        type: "bar",
                        label: "RAT",
                        backgroundColor: "#14b3a3",
                        data: <?php echo $rat; ?>,
                        lineTension: 0,
                        fill: false
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: true, position: 'top'},
                onClick: chartClickEventtest
            }
        }; // end of var config

        function chartClickEventtest(event, array)
        {
            if (myLiveCharttest === undefined || myLiveCharttest == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveCharttest.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
//            window.open("../dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveCharttest = new Chart(ctx_test, config_test);

//        ----------------------- COVID TEST END -------------------------------
//             ------------------- PIE CHART Province wise Positive Cases START --------------------
        var data = {
            datasets: [{
                    data: <?php echo $positive_data;?>,
                    backgroundColor: [
                        "#8251b8",
                        "#4c8ce6",
                        "#3fccc0",
                        "rgba(139,195,74,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)",
                        "rgba(245, 146, 93,1)",
                        "rgba(56, 37, 184,1)",
                        "rgba(222, 108, 27,1)"
                    ]
                }],
            labels: <?php echo $positive_label;?>
        };
        var pieOptions = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("piechart");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: data,
                        options: pieOptions
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];
                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
                            window.open("<?php echo base_url();?>dashboard/positive_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );
        //                  ------------------- PIE CHART END --------------------
        
         //             ------------------- PIE CHART  Death Cases START --------------------
        var datadeath = {
            datasets: [{
                    data: ['20','50','30'],
                    backgroundColor: [
                  "#ff7c43",
                  "#f95d6a",
                        "#a05195",     
                "#8251b8",
                        "#4c8ce6",
                        "#3fccc0",
                        "rgba(139,195,74,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)"
                      
                    ]
                }],
            labels: <?php echo $death_label; ?>
        };
        var pieOptionsdeath = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("deathcases");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'pie',
                        data: datadeath,
                        options: pieOptionsdeath
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];

                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
                            window.open("<?php echo base_url();?>dashboard/death_drill_prov/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );
        //                  ------------------- PIE CHART  Death END --------------------
        
                 //             ------------------- AGE WISE CASES START --------------------
        var dataage = {
            datasets: [{
                    data: ['03','09','17','19','15','13','07','08','05'],
                    backgroundColor: [
                  "#ff7c43",
                  "#f95d6a",
                        "#a05195",     
                "#8251b8",
                        "#4c8ce6",
                        "#3fccc0",
                        "rgba(139,195,74,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)"
                      
                    ]
                }],
            labels: ["0-9","10-19","20-29","30-39","40-49","50-59","60-69","70-79","80 Above"]
        };
        var pieOptionsage = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("age");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: dataage,
                        options: pieOptionsage
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];

                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
                            window.open("<?php echo base_url();?>dashboard/age_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );
        //                  ------------------- AGE WISE CASES END --------------------
        
                   //             ------------------- GENDER WISE CASES START --------------------
    var genderCanvas = document.getElementById("gender");

var genderData = {
  labels: ["Female","Male","Other"],
  datasets: [{
    data: [1630, 2255, 1120],
    backgroundColor: [
      "rgba(255, 0, 0, 0.5)",
      "rgba(100, 255, 0, 0.5)",
      "rgba(200, 50, 255, 0.5)",
      "rgba(0, 100, 255, 0.5)"
    ]
  }]
};

var polarAreaChart = new Chart(genderCanvas, {
  type: 'polarArea',
  data: genderData
});
        //                  ------------------- Gender WISE CASES END --------------------
        
// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Ventilator Chart Start (Bar Chart) xxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctxvent = document.getElementById("ventilator").getContext("2d");

        var configvent = {
            type: 'bar',
            data: {
                labels: <?php echo $vent_label; ?>,
                datasets: [{
                        label: "Quantity",
                        type: "bar",
                        backgroundColor: [
                            "#8251b8",
                            "#4c8ce6",
                            "#3fccc0",
                            "#99e692",
                            "#7ee9ac",
                            "#66eac6",
                            "#57eadd",
                            "#59e8f0"
                        ],
                        data: <?php echo $vent_data; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEventvent
            }
        }; // end of var config

        function chartClickEventvent(event, array)
        {
            if (myLiveChartvent === undefined || myLiveChartvent == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChartvent.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            window.open("<?php echo base_url();?>dashboard/vent_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChartvent = new Chart(ctxvent, configvent);
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    Ventilator END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Oxygen Beds Chart Start (Bar Chart) xxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctxbed = document.getElementById("bed").getContext("2d");

        var configbed = {
            type: 'bar',
            data: {
                labels: <?php echo $bed_label; ?>,
                datasets: [{
                        label: "Quantity",
                        type: "bar",
                        backgroundColor: [
                            "#4c70f5",
                            "#ff7477",
                            "#22b59f",
                            "#51c914",
                            "#7ee9ac",
                            "#66eac6",
                            "#57eadd",
                            "#59e8f0"
                        ],
                        data: <?php echo $bed_data ; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEventbed
            }
        }; // end of var config

        function chartClickEventbed(event, array)
        {
            if (myLiveChartbed === undefined || myLiveChartbed == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChartbed.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            window.open("<?php echo base_url();?>dashboard/bed_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChartbed = new Chart(ctxbed, configbed);
//xxxxxxxxxxxxxxxxxxxxxxxxxx    Oxygen Beds END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Incident Ratio Chart Start (Bar Chart) xxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctx = document.getElementById("incident").getContext("2d");

        var config = {
            type: 'bar',
            data: {
                labels: ["Punjab","Sindh","KP","Balochistan","AJK","GB","Islamabad"],
                datasets: [{
                        label: "Incident %",
                        type: "bar",
                        backgroundColor: [
                           '#e0aa14',
'#f88c2b',
'#ff6b4b',
'#ff4d6e',
'#f43c93',
'#d043b6',
'#9554d2',
'#1462e0',
                        ],
                        data: [38,41,31,28,22,18,20]
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent
            }
        }; // end of var config

        function chartClickEvent(event, array)
        {
            if (myLiveChart === undefined || myLiveChart == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
//            window.open("<?php echo base_url();?>dashboard/vent_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChart = new Chart(ctx, config);
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    Incident Ratio END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

//xxxxxxxxxxxxxxxxxxxxxxxxx ANIMATION START  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

//xxxxxxxxxxxxxxxxxxxxxxxxx ANIMATION EDN xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    });
</script>
