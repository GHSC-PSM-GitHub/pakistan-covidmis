    <?php
//    echo '<pre>';
//    print_r($patient_summary);exit;


    if (empty($from_date)) {
        $from_date = date('Y-m-01', strtotime('-6 month'));
    }
// $from_date  = date('2020-06-01');
    if (empty($to_date)) {
        $to_date = date('Y-m-d');
    }

    //    ------------------ Total and Positive Cases PCR & RAT START---------------------

    $total_pcr = $total_rat = $positive_pcr = $positive_rat = '';
    foreach ($total_tests as $k => $val) {
        $total_pcr = $val['pcr'];
        $total_rat = $val['rat'];
    }
    foreach ($total_positive as $k => $val) {
        $positive_pcr = $val['pcr_positive'];
        $positive_rat = $val['rat_positive'];
    }
    $negative_pcr = $total_pcr - $positive_pcr;
    $negative_rat = $total_rat - $positive_rat;

    $pcr = "[" . round($total_pcr / 1000) . "," . round($positive_pcr / 1000) . "," . round($negative_pcr / 1000) . "]";
    $rat = "[" . round($total_rat / 1000) . "," . round($positive_rat / 1000) . "," . round($negative_rat / 1000) . "]";

//echo $pcr;
//echo $rat; exit;
//    ------------------ Total and Positive Cases PCR & RAT END-----------------------
//    ------------------ Disease wise data START---------------------
    $vent_label = '[';
    $vent_data = '[';
    foreach ($vents_data as $k => $val) {
        foreach ($val as $label => $sum) {
            $vent_data .= $sum . ",";
            $vent_label .= '"' . $label . '",';
        }
    }
    $vent_label = substr_replace($vent_label, "", -1);
    $vent_label .= ']';
    $vent_data = substr_replace($vent_data, "", -1);
    $vent_data .= ']';

//echo $vent_label;
//echo $vent_data; exit;
//    ------------------ Disease wise data END-----------------------
    //    ------------------ Province WIse Positive DATA START---------------------
    $positive_label = '[';
    $positive_data = '[';
    foreach ($positive_cases as $k => $val) {
//      print_r($val); exit;
        $sum = $val['pcr'] + $val['rat'];
        $positive_data .= $sum . ",";
        $positive_label .= '"' . $val['province'] . '",';
    }
    $positive_label = substr_replace($positive_label, "", -1);
    $positive_label .= ']';
    $positive_data = substr_replace($positive_data, "", -1);
    $positive_data .= ']';

//echo $positive_label;
//echo $positive_data; exit;
//    ------------------ Province WIse Positive DATA END-----------------------
    //    ------------------ Death wise data START---------------------
    $death_label = '[';
    $death_data = '[';
    foreach ($deaths_data as $k => $val) {
        foreach ($val as $label => $sum) {
            $death_data .= $sum . ",";
            $death_label .= '"' . $label . '",';
        }
    }
    $death_label = substr_replace($death_label, "", -1);
    $death_label .= ']';
    $death_data = substr_replace($death_data, "", -1);
    $death_data .= ']';

//echo $death_label;
//echo $death_data; exit;
//    ------------------ Death wise data END-----------------------
    //    ------------------ Oxygen Beds DATA START---------------------
    $bed_label = '[';
    $bed_data = '[';
    foreach ($oxygen_beds as $k => $val) {
        foreach ($val as $label => $sum) {
            $bed_data .= $sum . ",";
            $bed_label .= '"' . $label . '",';
        }
    }
    $bed_label = substr_replace($bed_label, "", -1);
    $bed_label .= ']';
    $bed_data = substr_replace($bed_data, "", -1);
    $bed_data .= ']';

//echo $bed_label;
//echo $bed_data; exit;
//    ------------------ Oxygen Beds DATA END-----------------------
    ?>


<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                   <div>
                <img class='head' src="<?php echo base_url() . '/assets/images/usaidlogo.png'; ?> " > 
            </div> 
                <div class="col-md-12" >
                    
                    <div class="panel-body p-20" style="overflow: auto;">
                  
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="panel-heading" style="background-color:#f0305f;">
                            <div class="pull-left">
                                <h6 style="color:white;" class="panel-title txt-light">Vaccine Statistics</h6>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <br>
                        <div class="col-lg-3">
                            <div class="panel panel-default card-view pa-0 bg-purple">
                                <div class="panel-wrapper collapse in">
                                    <div class="panel-body pa-0">
                                        <div class="sm-data-box">
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col-xs-9 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                        <span class="block counter"><span class="counter-anim">124,342,276</span></span>
                                                        <span class="weight-500 uppercase-font block">Fully Vaccinated</span>
                                                    </div>
                                                    <div class="col-xs-3 text-center  pl-0 pr-0 data-wrap-right">
                                                        <i class="ti-medall-alt data-right-rep-icon txt-light"></i>
                                                    </div>
                                                </div>	
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="panel panel-default card-view pa-0 bg-purple">
                                <div class="panel-wrapper collapse in">
                                    <div class="panel-body pa-0">
                                        <div class="sm-data-box">
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col-xs-9 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                        <span class="block counter"><span class="counter-anim">135,926,474</span></span>
                                                        <span class="weight-500 uppercase-font block">First Dose</span>
                                                    </div>
                                                    <div class="col-xs-3 text-center  pl-0 pr-0 data-wrap-right">
                                                        <i class="ti-pin data-right-rep-icon txt-light"></i>
                                                    </div>
                                                </div>	
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <div class="panel panel-default card-view pa-0 bg-purple">
                                <div class="panel-wrapper collapse in">
                                    <div class="panel-body pa-0">
                                        <div class="sm-data-box">
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col-xs-9 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                        <span class="block counter"><span class="counter-anim">13,640,464</span></span>
                                                        <span class="weight-500 uppercase-font block">Booster Dose</span>
                                                    </div>
                                                    <div class="col-xs-3 text-center  pl-0 pr-0 data-wrap-right">
                                                        <i class="icon-energy data-right-rep-icon txt-light"></i>
                                                    </div>
                                                </div>	
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="panel panel-default card-view pa-0 bg-purple">
                                <div class="panel-wrapper collapse in">
                                    <div class="panel-body pa-0">
                                        <div class="sm-data-box">
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col-xs-9 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                        <span class="block counter"><span class="counter-anim">256,546,646</span></span>
                                                        <span class="weight-500 uppercase-font block">Total Doses</span>
                                                    </div>
                                                    <div class="col-xs-3 text-center  pl-0 pr-0 data-wrap-right">
                                                        <i class="icon-people data-right-rep-icon txt-light"></i>
                                                    </div>
                                                </div>	
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>      
                        <div class="panel-heading" style="background-color:#f8b32d;">
                        <div class="panel-title">
                            <h6 style="color:white;" class="panel-title txt-light"><?= $page_title; ?></h6>
                        </div>
                    </div>
<div class="panel-body">
             
                <div class="row">
                    <div class="col-xs-2 ">
                        <div class="panel panel-default card-view pa-25 bg-yellow">
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body pa-0">
                                    <div class="sm-data-box ">                                               
                                        <div class="row ">
                                            <h3 style="color:white;">Suspected</h3>
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">150</span></span>
                                                <span class="weight-500 uppercase-font block">In 24 Hours</span>
                                            </div>
                                            <div class="col-xs-6 text-center  pl-0 pr-0 data-wrap-right">
                                                <i class="fa fa-cogs data-right-rep-icon txt-light"></i>
                                                 <i class="fa fa-syringe tx-60 lh-0 tx-white op-7"></i>
                                            </div>
                                        </div>	
                                        <div class="row ">
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">789,244</span></span>
                                                <span class="weight-500 uppercase-font block">Accumulative</span>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-2 ">
                        <div class="panel panel-default card-view pa-25 bg-blue">
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body pa-0">
                                    <div class="sm-data-box ">                                               
                                        <div class="row ">
                                            <h3 style="color:white;">Test</h3>
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">139</span></span>
                                                <span class="weight-500 uppercase-font block">In 24 Hours</span>
                                            </div>
                                            <div class="col-xs-6 text-center  pl-0 pr-0 data-wrap-right">
                                                <i class="fa fa-stethoscope data-right-rep-icon txt-light"></i>
                                                 <i class="fa fa-syringe tx-60 lh-0 tx-white op-7"></i>
                                            </div>
                                        </div>	
                                        <div class="row ">
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">700,234</span></span>
                                                <span class="weight-500 uppercase-font block">Accumulative</span>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-2 ">
                        <div class="panel panel-default card-view pa-25 bg-red">
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body pa-0">
                                    <div class="sm-data-box ">                                               
                                        <div class="row ">
                                            <h3 style="color:white;">Confirmed</h3>
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">112</span></span>
                                                <span class="weight-500 uppercase-font block">In 24 Hours</span>
                                            </div>
                                            <div class="col-xs-6 text-center  pl-0 pr-0 data-wrap-right">
                                                <i class="ti-check-box data-right-rep-icon txt-light"></i>
                                                 <i class="fa fa-syringe tx-60 lh-0 tx-white op-7"></i>
                                            </div>
                                        </div>	
                                        <div class="row ">
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">503,766</span></span>
                                                <span class="weight-500 uppercase-font block">Accumulative</span>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-2 ">
                        <div class="panel panel-default card-view pa-25 bg-green">
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body pa-0">
                                    <div class="sm-data-box ">                                               
                                        <div class="row ">
                                            <h3 style="color:white;">Recovered</h3>
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">103</span></span>
                                                <span class="weight-500 uppercase-font block">In 24 Hours</span>
                                            </div>
                                            <div class="col-xs-6 text-center  pl-0 pr-0 data-wrap-right">
                                                <i class="ti-star data-right-rep-icon txt-light"></i>
                                                 <i class="fa fa-syringe tx-60 lh-0 tx-white op-7"></i>
                                            </div>
                                        </div>	
                                        <div class="row ">
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">211,103</span></span>
                                                <span class="weight-500 uppercase-font block">Accumulative</span>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-2 ">
                        <div class="panel panel-default card-view pa-25 bg-gold">
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body pa-0">
                                    <div class="sm-data-box ">                                               
                                        <div class="row ">
                                            <h3 style="color:white;">Critical</h3>
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">89</span></span>
                                                <span class="weight-500 uppercase-font block">In 24 Hours</span>
                                            </div>
                                            <div class="col-xs-6 text-center  pl-0 pr-0 data-wrap-right">
                                                <i class="ti-support data-right-rep-icon txt-light"></i>
                                                 <i class="fa fa-syringe tx-60 lh-0 tx-white op-7"></i>
                                            </div>
                                        </div>	
                                        <div class="row ">
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">255,181</span></span>
                                                <span class="weight-500 uppercase-font block">Accumulative</span>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-2 ">
                        <div class="panel panel-default card-view pa-25 bg-grey">
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body pa-0">
                                    <div class="sm-data-box ">                                               
                                        <div class="row ">
                                            <h3 style="color:white;">Deaths</h3>
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">0</span></span>
                                                <span class="weight-500 uppercase-font block">In 24 Hours</span>
                                            </div>
                                            <div class="col-xs-6 text-center  pl-0 pr-0 data-wrap-right">
                                                <i class="ti-heart-broken data-right-rep-icon txt-light"></i>
                                                 <i class="fa fa-syringe tx-60 lh-0 tx-white op-7"></i>
                                            </div>
                                        </div>	
                                        <div class="row ">
                                            <div class="col-xs-6 text-center pl-0 pr-0 data-wrap-left txt-light">
                                                <span class="block counter"><span class="counter-anim">133,510</span></span>
                                                <span class="weight-500 uppercase-font block">Accumulative</span>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Covid Test (In Thousands)</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="myChart"  height="340"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                    <div class="col-lg-4">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Positive Cases Province Wise</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="piechart" height="300"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>
                    <div class="col-lg-4">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Death Cases</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="deathcases" height="300"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>

                </div>

                <div><b>Due to Non-Availability of Actual Data, Below Graphs have Dummy Data. </b></div>

                <div class="row">

                    <div class="col-lg-4">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading" style="background-color:#e3d7b1;">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Incident Ratio</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="incident" height="220"></canvas>
                                </div>
                            </div>
                        </div>	
                    </div>
                    <div class="col-lg-4">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading" style="background-color:#e3d7b1;">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Patients Summary</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-body">
                                <table class="table-striped table-bordered " height="220">
                                    <tr>
                                        <th>Province</th>
                                        <th>Low Oxygen</th>
                                        <th>High Oxygen</th>
                                        <th>Ventilator</th>
                                        <th>Quarantine</th>

                                    </tr>
<?php
foreach ($patient_summary as $k => $val) {
    echo '<tr>';
    foreach ($val as $label => $sum) {
        echo '<td>' . $sum . '</td>';
    }
    echo '</tr>';
}
?>

                                </table>
                            </div>
                        </div>	
                    </div> 
                <div class="col-lg-4">
                <div class="panel panel-default card-view">
                    <div class="panel-heading" style="background-color:#e3d7b1;">
                        <div class="pull-left">
                            <h2 class="panel-title txt-dark">Cases & Recovery Trend </h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-wrapper collapse in">
                        <div class="panel-body">
                            <canvas id="line-chart" height="190"></canvas>
                        </div>
                    </div>
                </div>	
            </div>
                </div>
                <div><b>Click on the Graph for Drilldown</b></div>
            </div>
                       

                      

                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->

                











<script>
    /*Chartjs Init*/

    $(document).ready(function () {
        //        "use strict";

//        ----------------------- COVID TEST START -------------------------------

        var ctx_test = document.getElementById("myChart").getContext("2d");

        var config_test = {
            type: 'bar',
            data: {
                labels: ["Total", "Positive", "Negative"],
                datasets: [
                    {
                        type: "bar",
                        backgroundColor: "#edc61a",
                        borderColor: "rgba(54, 162, 235, 1)",
                        borderWidth: 1,
                        label: "PCR",
                        data: <?php echo $pcr; ?>
                    },
                    {
                        type: "bar",
                        label: "RAT",
                        backgroundColor: "#14b3a3",
                        data: <?php echo $rat; ?>,
                        lineTension: 0,
                        fill: false
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEventtest
            }
        }; // end of var config

        function chartClickEventtest(event, array)
        {
            if (myLiveCharttest === undefined || myLiveCharttest == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveCharttest.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
//            window.open("../dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveCharttest = new Chart(ctx_test, config_test);

//        ----------------------- COVID TEST END -------------------------------
//             ------------------- PIE CHART Province wise Positive Cases START --------------------
        var data = {
            datasets: [{
                    data: <?php echo $positive_data; ?>,
                    backgroundColor: [
                        "#8251b8",
                        "#4c8ce6",
                        "#3fccc0",
                        "rgba(139,195,74,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)",
                        "rgba(245, 146, 93,1)",
                        "rgba(56, 37, 184,1)",
                        "rgba(222, 108, 27,1)"
                    ]
                }],
            labels: <?php echo $positive_label; ?>
        };
        var pieOptions = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("piechart");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: data,
                        options: pieOptions
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];
                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
                            window.open("<?php echo base_url(); ?>dashboard/positive_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );
        //                  ------------------- PIE CHART END --------------------

        //             ------------------- PIE CHART  Death Cases START --------------------
        var datadeath = {
            datasets: [{
                    data: ['20', '50', '30'],
                    backgroundColor: [
                        "rgba(255, 0, 0, 0.5)",
                        "rgba(100, 255, 0, 0.5)",
                        "rgba(200, 50, 255, 0.5)",
                        "rgba(0, 100, 255, 0.5)",
                        "#ff7c43",
                        "#f95d6a",
                        "#a05195",
                        "#8251b8",
                        "#4c8ce6",
                        "#3fccc0",
                        "rgba(139,195,74,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)"

                    ]
                }],
            labels: <?php echo $death_label; ?>
        };
        var pieOptionsdeath = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("deathcases");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'pie',
                        data: datadeath,
                        options: pieOptionsdeath
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];

                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
//                            window.open("<?php echo base_url(); ?>dashboard/drill_lvl_1/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );
        //                  ------------------- PIE CHART  Death END --------------------



// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Incident Ratio Chart Start (Bar Chart) xxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctx = document.getElementById("incident").getContext("2d");

        var config = {
            type: 'bar',
            data: {
                labels: ["Punjab", "Sindh", "KP", "Balochistan", "AJK", "GB", "Islamabad"],
                datasets: [{
                        label: "Incident %",
                        type: "bar",
                        backgroundColor: [
                            '#e0aa14',
                            '#f88c2b',
                            '#ff6b4b',
                            '#ff4d6e',
                            '#f43c93',
                            '#d043b6',
                            '#9554d2',
                            '#1462e0',
                        ],
                        data: [38, 41, 31, 28, 22, 18, 20]
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent
            }
        }; // end of var config

        function chartClickEvent(event, array)
        {
            if (myLiveChart === undefined || myLiveChart == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
//            window.open("<?php echo base_url(); ?>dashboard/vent_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChart = new Chart(ctx, config);
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    Incident Ratio END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxx START LINE CHART xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        new Chart(document.getElementById("line-chart"), {
            type: 'line',
            data: {
                labels: ["5-Jun","6-Jun","7-Jun","8-Jun","9-Jun"],
                datasets: [{
                        data: ['150','130','135','137','121'],
                        label: "Positive Cases",
                        borderColor: "#8e5ea2",
                        fill: false
                    },
                    {
                        data: ['122','108','115','96','104'],
                        label: "Recovered",
                        borderColor: "#42f59b",
                        fill: false
                    }
                ]
            },
            options: {
                legend: {display: true},
                title: {
                    display: false,
                    text: ''
                }, scales: {
                    xAxes: [{
                            gridLines: {
                                display: false
                            }
                        }],
                    yAxes: [{
                            gridLines: {
                                display: true
                            },
                            ticks: {

                            },
                            legend: {display: true, position: 'top'}
                        }]
                }
            }
        });

//xxxxxxxxxxxxxxxxx END xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


    });
</script>
