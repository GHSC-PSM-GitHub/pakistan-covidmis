                    <!-- ========== LEFT SIDEBAR ========== -->
                    <div class="left-sidebar fixed-sidebar bg-black-300 box-shadow">
                        <div class="sidebar-content">
                            <div class="user-info closed">
                                <img src="" alt="John Doe" class="img-circle profile-img">
                                <h6 class="title">John Doe</h6>
                                <small class="info">PHP Developer</small>
                            </div>
                            <!-- /.user-info -->

                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li class="nav-header">
                                        <span class="">Dashboard</span>
                                    </li>
<!--                                    <li class="<?= ($this->uri->segment(1) == 'dashboard')?'active':'';?>">
                                        <a href="<?= base_url().'dashboard/index';?>">
                                            <i class="fa fa-dashboard"></i> 
                                            <span>Dashboard</span>
                                        </a>
                                          <ul class="child-nav">
                                            <li class="<?= ($this->uri->segment(1) == 'data')?'active':'';?>">
                                                <a href="<?= base_url().'data/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Vaccine Stock</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'clinical_status')?'active':'';?>">
                                                <a href="<?= base_url().'clinical_status/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>COVIM</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'hcp')?'active':'';?>">
                                                <a href="<?= base_url().'hcp/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>COVID</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'cases')?'active':'';?>">
                                                <a href="<?= base_url().'cases/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Diseases</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>-->
            <!------------------------  START  ---------------------------------->     
            <li class="nav-header">
                                        <!--<span class="">Dashbaord</span>-->
                                    </li>
                                    
<!--                                             <li class="<?= ($this->uri->segment(1) == 'snapshot')?'active':'';?>">
                                                <a href="<?= base_url().'dashboard/covid_snapshot';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Quick Snapshot</span>
                                                </a>
                                            </li>-->
                                    <li class="has-children <?= ( $this->uri->segment(1) == 'cases' || $this->uri->segment(1) == 'vaccination' || $this->uri->segment(1) == 'vaccine' )?'open':'';?>">
                                        <a href="#">
                                            <i class="fa fa-dashboard"></i> 
                                            <span>COVID</span> 
                                            <i class="fa fa-angle-right arrow"></i>
                                        </a>
                                        <ul class="child-nav">
                                            <li class="<?= ($this->uri->segment(1) == 'vaccine')?'active':'';?>">
                                                <a href="<?= base_url().'immunization/vaccine_stock';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Vaccine Stock</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'cases')?'active':'';?>">
                                                <a href="<?= base_url().'dashboard/covid';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Cases</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'vaccination')?'active':'';?>">
                                                <a href="<?= base_url().'dashboard/vaccination';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Vaccination</span>
                                                </a>
                                            </li>
                                            
                                        </ul>
                                    </li>
                                    
                                       <li class="has-children <?= ( $this->uri->segment(1) == 'covim_status' || $this->uri->segment(1) == 'monthly_status' || $this->uri->segment(1) == 'consumption_pattern' )?'open':'';?>">
                                        <a href="#">
                                            <i class="fa fa-dashboard"></i> 
                                            <span>COVIM</span> 
                                            <i class="fa fa-angle-right arrow"></i>
                                        </a>
                                        <ul class="child-nav">
                                           
                                            <li class="<?= ($this->uri->segment(1) == 'covim_status')?'active':'';?>">
                                                <a href="<?= base_url().'covim/stock_status';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Stock Status</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'monthly_status')?'active':'';?>">
                                                <a href="<?= base_url().'covim/monthly_status';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Monthly Status</span>
                                                </a>
                                            </li>
                                             <li class="<?= ($this->uri->segment(1) == 'consumption_pattern')?'active':'';?>">
                                                <a href="<?= base_url().'covim/consumption_pattern';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Consumption Trend</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    
                                         <li class="has-children <?= ($this->uri->segment(1) == 'infectious_diseases' || $this->uri->segment(1) == 'focused_diseases' )?'open':'';?>">
                                        <a href="#">
                                            <i class="fa fa-dashboard"></i> 
                                            <span>Diseases</span> 
                                            <i class="fa fa-angle-right arrow"></i>
                                        </a>
                                        <ul class="child-nav">
                                            <li class="<?= ($this->uri->segment(1) == 'infectious_diseases')?'active':'';?>">
                                                <a href="<?= base_url().'dashboard/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Infectious Diseases</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'focused_diseases')?'active':'';?>">
                                                <a href="<?= base_url().'dashboard/focused_diseases';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Focused Diseases</span>
                                                </a>
                                            </li>
                                          
                                        </ul>
                                    </li>
                                     <li class="nav-header">
                                        <span class="">Map</span>
                                    </li>
                                     <li class="<?= ($this->uri->segment(1) == 'map')?'active':'';?>">
                                                <a href="<?= base_url().'dashboard/vent_map';?>">
                                                    <i class="fa fa-map-marker"></i> 
                                                    <span>Distribution</span>
                                                </a>
                                            </li>
            <!----------------------------  END    ------------------------------------>
                               
                                    <li class="nav-header">
                                        <span class="">Data Entry</span>
                                    </li>
                                    <li class="has-children <?= ($this->uri->segment(1) == 'data' || $this->uri->segment(1) == 'clinical_status' || $this->uri->segment(1) == 'hcp' || $this->uri->segment(1) == 'cases' || $this->uri->segment(1) == 'hcp_details' || $this->uri->segment(1) == 'death_and_suspect')?'open':'';?>">
                                        <a href="#">
                                            <i class="fa fa-database"></i> 
                                            <span>Provincial Level</span> 
                                            <i class="fa fa-angle-right arrow"></i>
                                        </a>
                                        <ul class="child-nav">
                                            <li class="<?= ($this->uri->segment(1) == 'data')?'active':'';?>">
                                                <a href="<?= base_url().'data/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Tests & Cases</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'clinical_status')?'active':'';?>">
                                                <a href="<?= base_url().'clinical_status/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Clinical Status (Table 2A)</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'hcp')?'active':'';?>">
                                                <a href="<?= base_url().'hcp/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>HCP (Table 3A)</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'cases')?'active':'';?>">
                                                <a href="<?= base_url().'cases/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Cases (Table 1B)</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'hcp_details')?'active':'';?>">
                                                <a href="<?= base_url().'hcp_details/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>HCP Details (Table 3B)</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'death_and_suspect')?'active':'';?>">
                                                <a href="<?= base_url().'death_and_suspect/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Death & Suspects (Table 1C)</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="has-children <?= ($this->uri->segment(1) == 'ventilators' || $this->uri->segment(1) == 'oxygen' || $this->uri->segment(1) == 'situations')?'open':'';?>">
                                        <a href="#">
                                            <i class="fa fa-database"></i> 
                                            <span>District Level</span> 
                                            <i class="fa fa-angle-right arrow"></i>
                                        </a>
                                        <ul class="child-nav">
                                            <li class="<?= ($this->uri->segment(1) == 'ventilators')?'active':'';?>">
                                                <a href="<?= base_url().'ventilators/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Ventilators (Table 2B)</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'oxygen')?'active':'';?>">
                                                <a href="<?= base_url().'oxygen/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Oxygen (Table 2C)</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'situations')?'active':'';?>">
                                                <a href="<?= base_url().'situations/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Situations (Table 4)</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                      <li class="<?= ($this->uri->segment(1) == 'situations')?'active':'';?>">
                                                <a href="<?= base_url().'admin/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Daily Vaccination</span>
                                                </a>
                                            </li>
                                    <li class="nav-header">
                                        <span class="">Reports</span>
                                    </li>
                                    <li class="has-children <?= ($this->uri->segment(1) == 'provincial_reports' || $this->uri->segment(1) == 'district_reports')?'open':'';?>">
                                        <a href="#">
                                            <i class="fa fa-file-text"></i> 
                                            <span>Reports</span> 
                                            <i class="fa fa-angle-right arrow"></i>
                                        </a>
                                        <ul class="child-nav">
                                            <li class="<?= ($this->uri->segment(1) == 'provincial_reports')?'active':'';?>">
                                                <a href="<?= base_url().'provincial_reports/index';?>">
                                                    <i class="fa fa-file-text"></i> 
                                                    <span>Provincial Report</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'district_reports')?'active':'';?>">
                                                <a href="<?= base_url().'district_reports/index';?>">
                                                    <i class="fa fa-file-text"></i> 
                                                    <span>District Report</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="nav-header">
                                        <span class="">Configurations</span>
                                    </li>
                                    <li class="has-children <?= ($this->uri->segment(1) == 'districts' || $this->uri->segment(1) == 'province' || $this->uri->segment(1) == 'test_category' || $this->uri->segment(1) == 'test_type' || $this->uri->segment(1) == 'users')?'open':'';?>">
                                        <a href="#">
                                            <i class="fa fa-gears"></i> 
                                            <span>Settings</span> 
                                            <i class="fa fa-angle-right arrow"></i>
                                        </a>
                                        <ul class="child-nav">
                                            <li class="<?= ($this->uri->segment(1) == 'province')?'active':'';?>">
                                                <a href="<?= base_url().'province/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Provinces</span>
                                                </a>
                                            </li>
                                            <li class="<?= ($this->uri->segment(1) == 'districts')?'active':'';?>">
                                                <a href="<?= base_url().'districts/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Districts</span>
                                                </a>
                                            </li>
<!--                                            <li class="<?= ($this->uri->segment(1) == 'users')?'active':'';?>">
                                                <a href="<?= base_url().'users/index';?>">
                                                    <i class="fa fa-list"></i> 
                                                    <span>Users</span>
                                                </a>
                                            </li>-->
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>
                    <!-- /.left-sidebar -->