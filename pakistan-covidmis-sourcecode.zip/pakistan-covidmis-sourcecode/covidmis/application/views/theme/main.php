<!DOCTYPE html>
<html lang="en">
	<?php include 'header.php'?>
	<body class="top-navbar-fixed">
        <div class="main-wrapper">
			<!-- Preloader -->
			<?php //include 'preloader.php';?>
			<!-- /Preloader -->
			<!-- Top Menu Items -->
			<?php include 'top_bar.php';?>
			<!-- /Top Menu Items -->
			<!-- ========== WRAPPER FOR BOTH SIDEBARS & MAIN CONTENT ========== -->
	        <div class="content-wrapper">
	            <div class="content-container">
				<!-- Left Sidebar Menu -->
				<?php include 'left_sidebar.php';?>
				<!-- /Left Sidebar Menu -->
				<?php echo $main_content;?>
				<!-- Right Sidebar Menu -->
				<?php include 'right_sidebar.php';?>
				<!-- /Right Sidebar Menu -->
				</div>
			</div>
			<!-- Footer -->
			<?php
			include 'footer.php';
			?>
			<!-- /Footer -->
		</div>
		<!-- /Main Content -->
		<?php include 'javascript_files.php';?>
	</body>
</html>