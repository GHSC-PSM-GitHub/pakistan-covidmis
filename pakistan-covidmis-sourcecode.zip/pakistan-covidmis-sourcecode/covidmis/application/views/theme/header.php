	<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= $page_title;?> - COVID MIS</title>

        <!-- ========== COMMON STYLES ========== -->
        <link rel="stylesheet" href="<?= base_url().'assets/css/bootstrap.min.css';?>" media="screen" >
        <link rel="stylesheet" href="<?= base_url().'assets/css/font-awesome.min.css';?>" media="screen" >
        <link rel="stylesheet" href="<?= base_url().'assets/css/animate-css/animate.min.css';?>" media="screen" >
        <link rel="stylesheet" href="<?= base_url().'assets/css/lobipanel/lobipanel.min.css';?>" media="screen" >

        <!-- ========== PAGE STYLES ========== -->
        <link rel="stylesheet" href="<?= base_url().'assets/css/prism/prism.css';?>" media="screen" >
    <?php if($this->uri->segment(1) != 'dashboard'){ ?>
        <link rel="stylesheet" href="<?= base_url().'assets/css/select2/select2.min.css';?>" >
        <link rel="stylesheet" type="text/css" href="<?= base_url().'assets/css/date-picker/jquery.timepicker.css';?>" />
        <link rel="stylesheet" type="text/css" href="<?= base_url().'assets/css/date-picker/bootstrap-datepicker.css';?>" />
        <link rel="stylesheet" type="text/css" href="<?= base_url().'assets/js/DataTables/datatables.min.css';?>"/>
    <?php } ?>
        
        <!-- USED FOR DEMO HELP - YOU CAN REMOVE IT -->
        <link rel="stylesheet" href="<?= base_url().'assets/css/icheck/skins/line/blue.css';?>" >
        <link rel="stylesheet" href="<?= base_url().'assets/css/icheck/skins/line/red.css';?>" >
        <link rel="stylesheet" href="<?= base_url().'assets/css/icheck/skins/line/green.css';?>" >

        <!-- ========== THEME CSS ========== -->
        <link rel="stylesheet" href="<?= base_url().'assets/css/main.css';?>" media="screen" >
        <!-- <link rel="stylesheet" href="<?php //echo base_url().'assets/css/pace/pace-center-radar.css';?>" media="screen" > -->

        <!-- ========== MODERNIZR ========== -->
        <script src="<?= base_url().'assets/js/modernizr/modernizr.min.js';?>"></script>
    </head>