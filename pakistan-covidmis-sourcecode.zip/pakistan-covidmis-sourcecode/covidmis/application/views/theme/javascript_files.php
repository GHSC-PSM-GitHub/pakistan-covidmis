		<!-- ========== COMMON JS FILES ========== -->
        <script src="<?= base_url().'assets/js/jquery/jquery-2.2.4.min.js';?>"></script>
        <script src="<?= base_url().'assets/js/jquery-ui/jquery-ui.min.js';?>"></script>
        <script src="<?= base_url().'assets/js/bootstrap/bootstrap.min.js';?>"></script>
        <script src="<?= base_url().'assets/js/pace/pace.min.js';?>"></script>
        <script src="<?= base_url().'assets/js/lobipanel/lobipanel.min.js';?>"></script>
        <script src="<?= base_url().'assets/js/iscroll/iscroll.js';?>"></script>

        <!-- ========== PAGE JS FILES ========== -->
        <script src="<?= base_url().'assets/js/prism/prism.js';?>"></script>
    <?php if($this->uri->segment(1) != 'dashboard'){ ?>
        <script type="text/javascript">
            $('#province_id').change(function(){
                var province_id = $(this).val();
                // alert(province_id);
                $.ajax({
                    url: "<?= base_url() . 'dashboard/get_districts';?>",
                    method: "POST",
                    data: {
                        province_id: province_id
                    },
                    dataType: "json",
                    beforeSend: function () {
                    },
                    success: function (data) {
                        var html = '';
                        if (data.status) {
                            $.each(data.districts, function(index, data){
                                html += '<option value="'+data.pk_id+'">'+data.location_name+'</option>';
                            });
                        }else{
                            $('#district_id .select2-selection__rendered').html('');
                        }
                        $('#district_id').html(html);
                    }
                });
            });
        </script>
        <script src="<?= base_url().'assets/js/select2/select2.min.js';?>"></script>
        <script type="text/javascript">
            $(function($) {
                $(".select2").select2();
                // $(".js-states-limit").select2({
                //     maximumSelectionLength: 2
                // });
                // $(".js-states-hide").select2({
                //     minimumResultsForSearch: Infinity
                // });
            });
            $(document).ready(function(){
                $('.dropdown').click(function(){
                    if ($(this).hasClass('open')) {
                        $(this).removeClass('open');
                    }else{
                        $(this).addClass('open');
                    }
                });
            });
        </script>
        <script type="text/javascript" src="<?= base_url().'assets/js/date-picker/bootstrap-datepicker.js';?>"></script>
        <script type="text/javascript" src="<?= base_url().'assets/js/date-picker/jquery.timepicker.js';?>"></script>
        <script type="text/javascript" src="<?= base_url().'assets/js/date-picker/datepair.js';?>"></script>
        <script type="text/javascript" src="<?= base_url().'assets/js/date-picker/moment.js';?>"></script>
        <script type="text/javascript" src="<?= base_url().'assets/js/date-picker/bootstrap-datetimepicker.min.js';?>"></script>
        <script type="text/javascript">
            $(function($) {
                // 4th  datepicker
                $('.datepicker').datetimepicker({
                    viewMode: 'years',
                    format: 'M/DD/YYYY'
                });
            });
        </script>
        <script src="<?= base_url().'assets/js/DataTables/datatables.min.js';?>"></script>
        <script>
            $(function($) {
                $( document ).ready(function() {
                    $('#example').DataTable({
                        "processing": true,
                        // "sAjaxSource":"response.php",
                        "lengthMenu": [ [10, 25, 50, 100, 500, -1], [10, 25, 50, 100, 500, "All"] ],
                        "pageLength": 10,
                        "dom": 'lBfrtip',
                        "buttons": [
                            {
                                extend: 'collection',
                                text: 'Export',
                                buttons: [
                                    'copy',
                                    'excel',
                                    'csv',
                                    // 'pdf',
                                    // 'print'
                                ]
                            }
                        ]
                    });
                });
            });
        </script>
    <?php } ?>
        <!-- ========== THEME JS ========== -->
        <script src="<?= base_url().'assets/js/main.js';?>"></script>
        <script>
            // $(window).load(function() {
            //     $('.cssload-whirlpool').fadeOut();
            //     $('.pace-progress').delay(350).fadeOut('slow');
            //     $('body').delay(350).css({'overflow':'visible'});
            // });
        </script>
        <!-- ========== END COMMON JS FILES ========== -->