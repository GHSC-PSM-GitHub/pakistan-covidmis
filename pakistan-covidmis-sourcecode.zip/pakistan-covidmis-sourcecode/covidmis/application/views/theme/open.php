<!DOCTYPE html>
<html lang="en">
    <?php include 'header.php' ?>

    <body>
        <div class="wrapper theme-1-active pimary-color-green">
            <!-- Main Content -->
            <div class="page-wrapper">
                <div class="container pt-25">
                    <?php echo $main_content; ?>
                </div>
                <!-- Footer -->
                <?php
                include 'footer.php';
                ?>
                <!-- /Footer -->
            </div>
            <!-- /Main Content -->

        </div>
        <?php
        include 'javascript_functions.php';
        ?>
    </body>
</html>
