                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'death_and_suspect/create';?>"><i class="fa fa-plus"></i> Add New</a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5><?= $page_title;?></h5>
                                                </div>
                                            </div>
                                            <div class="panel-body p-20" style="overflow: auto;">
                                                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 10%; text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>Death Last 24 Hours</th>
                                                            <th>Died in Hospital On Ventilator</th>
                                                            <th>Died in Hospital Off Ventilator</th>
                                                            <th>Died at Home or Elsewhere</th>
                                                            <th>Suspect Contacts of Known COVID Pts</th>
                                                            <th>Suspect Others suspected</th>
                                                            <th>Suspect Total Suspects in last 24 hrs</th>
                                                            <th style="text-align: center; width: 10%">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tfoot>
                                                        <tr>
                                                            <th style="text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>Death Last 24 Hours</th>
                                                            <th>Died in Hospital On Ventilator</th>
                                                            <th>Died in Hospital Off Ventilator</th>
                                                            <th>Died at Home or Elsewhere</th>
                                                            <th>Suspect Contacts of Known COVID Pts</th>
                                                            <th>Suspect Others suspected</th>
                                                            <th>Suspect Total Suspects in last 24 hrs</th>
                                                            <th style="text-align: center;">Action</th>
                                                        </tr>
                                                    </tfoot>
                                                    <tbody>
                                                    <?php if(!empty($death_and_suspects[0]['id'])):?>
                                                        <?php $loop = 0;?>
                                                        <?php foreach($death_and_suspects as $death_and_suspect):?>
                                                            <tr>
                                                                <td style="text-align: center;"><?= ++$loop;?></td>
                                                                <td><?= date('d F, Y', strtotime($death_and_suspect['date']));?></td>
                                                                <td><?= $death_and_suspect['province_name'];?></td>
                                                                <td><?= $death_and_suspect['death_in_last_24_hours'];?></td>
                                                                <td><?= $death_and_suspect['died_in_hospital_on_ventilator'];?></td>
                                                                <td><?= $death_and_suspect['died_in_hospital_off_ventilator'];?></td>
                                                                <td><?= $death_and_suspect['died_at_home_or_elsewhere'];?></td>
                                                                <td><?= $death_and_suspect['suspect_contacts_of_known_covid_pts'];?></td>
                                                                <td><?= $death_and_suspect['others_suspected'];?></td>
                                                                <td><?= $death_and_suspect['suspects_in_last_24_hrs'];?></td>
                                                                <td style="text-align: center;">
                                                                    <a href="<?= base_url().'death_and_suspect/edit/'.$death_and_suspect['id'];?>">
                                                                        <i class="fa fa-edit"></i>
                                                                    </a> &nbsp;&nbsp;
                                                                    <a href="<?= base_url().'death_and_suspect/delete/'.$death_and_suspect['id'];?>">
                                                                        <i class="fa fa-trash"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->