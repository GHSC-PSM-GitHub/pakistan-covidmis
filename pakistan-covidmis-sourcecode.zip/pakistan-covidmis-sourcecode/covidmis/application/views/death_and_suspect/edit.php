                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'death_and_suspect/index';?>">
                                        <i class="fa fa-arrow-left"></i> Back
                                    </a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <!-- <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Two Column Form</h5>
                                                </div>
                                            </div> -->
                                            <div class="panel-body">
                                                <h5 class="underline mt-n"><?= $page_title;?></h5>
                                                <form method="POST" action="<?= base_url().'death_and_suspect/edit/'.$death_and_suspect[0]['id'];?>">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="date">Date</label>
                                                                <div class='input-group datepicker' id='datepicker'>
                                                                    <input type='text' class="form-control" name="date" id="date" placeholder="Select Date" value="<?= date('m/d/Y', strtotime($death_and_suspect[0]['date']));?>" />
                                                                    <span class="input-group-addon">
                                                                        <span class="glyphicon glyphicon-calendar">
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="province_id">Province</label>
                                                                <select class="select2 form-control" id="province_id" name="province_id">
                                                                <?php if(!empty($provinces[0]['pk_id'])):?>
                                                                    <?php foreach($provinces as $province):?>
                                                                        <?php $sel = ($province['pk_id'] == $death_and_suspect[0]['province_id'])?'selected':'';?>
                                                                        <option value="<?= $province['pk_id'];?>" <?= $sel;?>><?= $province['location_name'];?></option>
                                                                    <?php endforeach;?>
                                                                <?php endif;?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="death_in_last_24_hours">Death Last 24 Hours</label>
                                                                <input type="text" class="form-control" id="death_in_last_24_hours" name="death_in_last_24_hours" placeholder="Enter Death Last 24 Hours" value="<?= $death_and_suspect[0]['death_in_last_24_hours'];?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="died_in_hospital_on_ventilator">Died in Hospital On Ventilator</label>
                                                                <input type="text" class="form-control" id="died_in_hospital_on_ventilator" name="died_in_hospital_on_ventilator" placeholder="Enter Died in Hospital On Ventilator" value="<?= $death_and_suspect[0]['died_in_hospital_on_ventilator'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="died_in_hospital_off_ventilator">Died in Hospital Off Ventilator</label>
                                                                <input type="text" class="form-control" id="died_in_hospital_off_ventilator" name="died_in_hospital_off_ventilator" placeholder="Enter Died in Hospital Off Ventilator" value="<?= $death_and_suspect[0]['died_in_hospital_off_ventilator'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="died_at_home_or_elsewhere">Died at Home or Elsewhere</label>
                                                                <input type="text" class="form-control" id="died_at_home_or_elsewhere" name="died_at_home_or_elsewhere" placeholder="Enter Died at Home or Elsewhere" value="<?= $death_and_suspect[0]['died_at_home_or_elsewhere'];?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="suspect_contacts_of_known_covid_pts">Suspect Contacts of Known COVID Pts</label>
                                                                <input type="text" class="form-control" id="suspect_contacts_of_known_covid_pts" name="suspect_contacts_of_known_covid_pts" placeholder="Enter Suspect Contacts of Known COVID Pts" value="<?= $death_and_suspect[0]['suspect_contacts_of_known_covid_pts'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="others_suspected">Suspect Others suspected</label>
                                                                <input type="text" class="form-control" id="others_suspected" name="others_suspected" placeholder="Enter Suspect Others suspected" value="<?= $death_and_suspect[0]['others_suspected'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="suspects_in_last_24_hrs">Suspect Total Suspects in last 24 hrs</label>
                                                                <input type="text" class="form-control" id="suspects_in_last_24_hrs" name="suspects_in_last_24_hrs" placeholder="Enter Suspect Total Suspects in last 24 hrs" value="<?= $death_and_suspect[0]['suspects_in_last_24_hrs'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 text-right">
                                                            <button type="submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                                <!-- /.row -->
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->