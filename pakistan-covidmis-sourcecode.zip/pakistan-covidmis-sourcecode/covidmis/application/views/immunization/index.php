<?php
//    echo '<pre>';
//    echo $is_mobile;exit;

if (empty($from_date)) {
    $from_date = date('2021-01-01');
//       $from_date = date('Y-m-01', strtotime('-6 month'));
}
if (empty($to_date)) {
    $to_date = date('Y-m-d');
}


//    ------------------ COVID MIS - Vaccine Wise Stock Received (Doses) START   ---------------------
if (!empty($vaccine_wise_stock_received)) {
    $vaccine_wise_stock_received_label = '[';
    $vaccine_wise_stock_received_data = '[';
    foreach ($vaccine_wise_stock_received as $k2 => $val2) {
//            print_r($val); exit;
        $vaccine_wise_stock_received_data .= $val2['total'] . ",";
        $vaccine_wise_stock_received_label .= '"' . $val2['name'] . '",';
    }
    $vaccine_wise_stock_received_label = substr_replace($vaccine_wise_stock_received_label, "", -1);
    $vaccine_wise_stock_received_label .= ']';
    $vaccine_wise_stock_received_data = substr_replace($vaccine_wise_stock_received_data, "", -1);
    $vaccine_wise_stock_received_data .= ']';
} else {
    $vaccine_wise_stock_received_label = '["Sinopharm","CanSino","CoronaVac","GAM-COVID-Vac Sputnik V (2 Dose)","Vaxzevria (AstraZeneca)","Pfizer-BioNTech","PakVac(CanSino)","Spikevax(Moderna)"]';
    $vaccine_wise_stock_received_data = '[42764000,2842199,108500000,10000000,8647000,80538120,20258050,31605660]';
}

//echo $vaccine_wise_stock_received_label;
//echo $vaccine_wise_stock_received_data; exit; 
//    ------------------ COVID MIS - Vaccine Wise Stock Received (Doses) END   -----------------------
//    ------------------ COVID Vaccine Received (Doses) START   ---------------------
if (!empty($covid_vaccine_received)) {
    $covid_vaccine_received_label = '[';
    $covid_vaccine_received_data  = '['; $total_received = $covax = 0;
    foreach ($covid_vaccine_received as $k4 => $val4) {

        if ($val4['fundingsource'] == 'COVAX USG' || $val4['fundingsource'] == 'COVAX Facility') {
            $covax = $covax + $val4['totalqty'];
            $total_received = $total_received + $val4['totalqty'];
        } else {
            $covid_vaccine_received_data .= $val4['totalqty'] . ",";
            $total_received = $total_received + $val4['totalqty'];
            $covid_vaccine_received_label .= '"' . $val4['fundingsource'] . '",';
        }
    }
    $covid_vaccine_received_label .= '"COVAX","Total"]';
    $covid_vaccine_received_data .= $covax.','.$total_received;
    $covid_vaccine_received_data .= ']';
} else {
    $covid_vaccine_received_label = '["Govt","COVAX","Donation","Total"]';
    $covid_vaccine_received_data = '[2000095,6029375,28759,8058229]';
}
//echo $covid_vaccine_received_label;
//echo $covid_vaccine_received_data; exit; 
//    ------------------ COVID Vaccine Received (Doses) END   -----------------------   
//    ------------------ COVAX Facility - Chinese Breakup (Doses) START   ---------------------
if (!empty($yearly_comp)) {
    $yearly_comp_label = '[';
    $yearly_comp_data=$fd_name =$qty_2021= $qty_2022 = '['; $covax2021=$covax2022 = $total2021=$total2022 = 0;
    $year_arr = array();
    foreach ($yearly_comp as $k16 => $val16) {
//            print_r($val16); exit;
            if($val16['year'] == '2021')
            {
                if($val16['fundingsource'] == 'COVAX Facility' || $val16['fundingsource'] == 'COVAX USG')
                {
                    $covax2021 = $covax2021 + $val16['totalqty'];
                    $total2021= $total2021 +  $val16['totalqty'];
                }else
                {
                $fd_name .= '"' . $val16['fundingsource']  . '",'; 
                $qty_2021 .=  $val16['totalqty'] . ',';
                $total2021= $total2021 +  $val16['totalqty'];
                }
            }
            elseif($val16['year'] == '2022')
            {
                if($val16['fundingsource'] == 'COVAX Facility' || $val16['fundingsource'] == 'COVAX USG')
                {
                    $covax2022 = $covax2022 + $val16['totalqty'];
                    $total2022= $total2022 +  $val16['totalqty'];
                }else
                {
                $qty_2022 .=  $val16['totalqty'] . ',';
                $total2022= $total2022 +  $val16['totalqty'];
                }
            }
        $year_arr[$val16['year']] [$val16['fundingsource']]= $val16['totalqty'] ;
    }
    $fd_name .= '"COVAX","Total"]';
    $qty_2021 .= $covax2021.','.$total2021;
    $qty_2021 .= ']';
    $qty_2022 .= $covax2022.','.$total2022;
    $qty_2022 .= ']';
} else {
    $fd_name = '["GOP","Donation","Covax","Total"]';
    $qty_2021 = '[255000,129000,285000,669000]';
    $qty_2022 = '[459000,211000,174500,844500]';
}

//echo $fd_name;
//echo $qty_2021; echo $qty_2022; exit;
//    ------------------ COVAX Facility - Chinese Breakup (Doses) END   ----------------------- 
//    ------------------ COVID Vaccine Received - Percentage of Share START   ---------------------
if (!empty($covid_vaccine_received)) {
     $covid_vaccine_received_label_1 = '[';
     $covid_vaccine_received_data_1 = '[';   $covax_1 = 0;
    foreach ($covid_vaccine_received as $k4 => $val4a) {

        if($val4a['fundingsource'] == 'COVAX USG' || $val4a['fundingsource'] == 'COVAX Facility'){
        $covax_1 = $covax_1 + $val4a['totalqty'];
    }else{
        $covid_vaccine_received_data_1 .= $val4a['totalqty'] . ",";
        $covid_vaccine_received_label_1 .= '"' . $val4a['fundingsource'] . '",';
    }
    }
    $covid_vaccine_received_label_1 .= '"COVAX"';
    $covid_vaccine_received_label_1 .= ']';
    $covid_vaccine_received_data_1 .= $covax_1;
    $covid_vaccine_received_data_1 .= ']';
} else {
     $covid_vaccine_received_label_1 = '["Govt","COVAX","Donation"]';
    $covid_vaccine_received_data_1 = '[2000095,6029375,28759]';
}
//echo $covid_vaccine_received_label_1;
//echo $covid_vaccine_received_data_1; exit; 
//    ------------------ COVID Vaccine Received - Percentage of Share END   -----------------------   
//    ------------------ COVAX Facility - Region Wise Vaccine Breakup (Doses) START   ---------------------
if (!empty($covax_region_breakup)) {
    $covax_region_breakup_label = '[';
    $covax_region_breakup_data = '[';
    foreach ($covax_region_breakup as $k15 => $val15) {
//            print_r($val); exit;
        $covax_region_breakup_data .= $val15['totalqty'] . ",";
        if($val15['warehouse_name'] == 'COVAX USG'){
        $covax_region_breakup_label .= '"' . 'USG' . '",';
        }
        else
        {
            $covax_region_breakup_label .= '"' . $val15['transaction_reference'] . '",';
        }
    }
    $covax_region_breakup_label = substr_replace($covax_region_breakup_label, "", -1);
    $covax_region_breakup_label .= ']';
    $covax_region_breakup_data = substr_replace($covax_region_breakup_data, "", -1);
    $covax_region_breakup_data .= ']';
} else {
    $covax_region_breakup_label = '["USG","Chinese","Westren"]';
    $covax_region_breakup_data = '[440000,280000,89000]';
}

//echo $covax_region_breakup_label;
//echo $covax_region_breakup_data; exit;
//    ------------------ COVAX Facility - Region Wise Vaccine Breakup (Doses) END   -----------------------         
//    ------------------  Region Wise Vaccine Breakup (Doses) START   ---------------------
if (!empty($region_vaccine_breakup)) {
    $region_vaccine_breakup_label = '[';
    $region_vaccine_breakup_data = '[';
    foreach ($region_vaccine_breakup as $k6 => $val6) {
//            print_r($val); exit;
        $region_vaccine_breakup_data .= $val6['totalqty'] . ",";
        $region_vaccine_breakup_label .= '"' . $val6['transaction_reference'] . '",';
    }
    $region_vaccine_breakup_label = substr_replace($region_vaccine_breakup_label, "", -1);
    $region_vaccine_breakup_label .= ']';
    $region_vaccine_breakup_data = substr_replace($region_vaccine_breakup_data, "", -1);
    $region_vaccine_breakup_data .= ']';
} else {
    $region_vaccine_breakup_label = '["USG","Chinese","Westren"]';
    $region_vaccine_breakup_data = '[180000,320000,25000]';
}

//echo $region_vaccine_breakup_label;
//echo $region_vaccine_breakup_data; exit;
//    ------------------  Region Wise Vaccine Breakup (Doses) END   ----------------------- 
//    ------------------ COVID Vaccine - Govt Procured Breakup (Doses) START   ---------------------
if (!empty($govt_procured_breakup)) {
    $govt_procured_breakup_label = '[';
    $govt_procured_breakup_data = '[';
    foreach ($govt_procured_breakup as $k5 => $val5) {
//            print_r($val); exit;
        $govt_procured_breakup_data .= $val5['totalqty'] . ",";
        $govt_procured_breakup_label .= '"' . $val5['itmname'] . '",';
    }
    $govt_procured_breakup_label = substr_replace($govt_procured_breakup_label, "", -1);
    $govt_procured_breakup_label .= ']';
    $govt_procured_breakup_data = substr_replace($govt_procured_breakup_data, "", -1);
    $govt_procured_breakup_data .= ']';
} else {
    $govt_procured_breakup_label = '["Moderna","SinoVac","CanSino"]';
    $govt_procured_breakup_data = '[20000,40000,490]';
}

//echo $govt_procured_breakup_label;
//echo $govt_procured_breakup_data; exit;
//    ------------------ COVID Vaccine - Govt Procured Breakup (Doses) END   -----------------------   
//    ------------------ COVID Vaccine - COVAX Facility Breakup (Doses) START   ---------------------
if (!empty($covax_facility_breakup)) {
    $covax_facility_breakup_label = '[';
    $covax_facility_breakup_data = '[';
    foreach ($covax_facility_breakup as $k7 => $val7) {
//            print_r($val); exit;
        $covax_facility_breakup_data .= $val7['totalqty'] . ",";
        $covax_facility_breakup_label .= '"' . $val7['item_name'] . '",';
    }
    $covax_facility_breakup_label = substr_replace($covax_facility_breakup_label, "", -1);
    $covax_facility_breakup_label .= ']';
    $covax_facility_breakup_data = substr_replace($covax_facility_breakup_data, "", -1);
    $covax_facility_breakup_data .= ']';
} else {
    $covax_facility_breakup_label = '["Moderna","Pfizer","SinoPharm"]';
    $covax_facility_breakup_data = '[200555,100000,2500]';
}

//echo $covax_facility_breakup_label;
//echo $covax_facility_breakup_data; exit;
//    ------------------ COVID Vaccine - COVAX Facility Breakup (Doses) END   ---------------------   
//    ------------------ COVID Vaccine - Donation Breakup (Doses) START   ---------------------
if (!empty($donation_breakup)) {
    $donation_breakup_label = '[';
    $donation_breakup_data = '[';
    foreach ($donation_breakup as $k8 => $val8) {
//            print_r($val); exit;
        $donation_breakup_data .= $val8['totalqty'] . ",";
        $donation_breakup_label .= '"' . $val8['item_name'] . '",';
    }
    $donation_breakup_label = substr_replace($donation_breakup_label, "", -1);
    $donation_breakup_label .= ']';
    $donation_breakup_data = substr_replace($donation_breakup_data, "", -1);
    $donation_breakup_data .= ']';
} else {
    $donation_breakup_label = '["PakVac","SinoVac","CanSino"]';
    $donation_breakup_data = '[650,300,150,0]';
}

//echo $donation_breakup_label;
//echo $donation_breakup_data; exit;
//    ------------------ COVID Vaccine - Donation Breakup (Doses) END   ---------------------    
//    ------------------ COVAX Facility - USG Breakup (Doses) START   ---------------------
if (!empty($covax_usg_breakup)) {
    $covax_usg_breakup_label = '[';
    $covax_usg_breakup_data = '[';
    foreach ($covax_usg_breakup as $k9 => $val9) {
//            print_r($val); exit;
        $covax_usg_breakup_data .= $val9['totalqty'] . ",";
        $covax_usg_breakup_label .= '"' . $val9['itmname'] . '",';
    }
    $covax_usg_breakup_label = substr_replace($covax_usg_breakup_label, "", -1);
    $covax_usg_breakup_label .= ']';
    $covax_usg_breakup_data = substr_replace($covax_usg_breakup_data, "", -1);
    $covax_usg_breakup_data .= ']';
} else {
    $covax_usg_breakup_label = '["Pfizer","Moderna","SinoPharm"]';
    $covax_usg_breakup_data = '[200,400,650]';
}

//echo $covax_usg_breakup_label;
//echo $covax_usg_breakup_data; exit;
//    ------------------ COVAX Facility - USG Breakup (Doses) END   -----------------------  
//    ------------------ COVAX Facility - Chinese Breakup (Doses) START   ---------------------
if (!empty($covax_chinese_breakup)) {
    $covax_chinese_breakup_label = '[';
    $covax_chinese_breakup_data = '[';
    foreach ($covax_chinese_breakup as $k10 => $val10) {
//            print_r($val); exit;
        $covax_chinese_breakup_data .= $val10['totalqty'] . ",";
        $covax_chinese_breakup_label .= '"' . $val10['itmname'] . '",';
    }
    $covax_chinese_breakup_label = substr_replace($covax_chinese_breakup_label, "", -1);
    $covax_chinese_breakup_label .= ']';
    $covax_chinese_breakup_data = substr_replace($covax_chinese_breakup_data, "", -1);
    $covax_chinese_breakup_data .= ']';
} else {
    $covax_chinese_breakup_label = '["Moderna","SinoVac","PakVac"]';
    $covax_chinese_breakup_data = '[250,120,90]';
}

//echo $covax_chinese_breakup_label;
//echo $covax_chinese_breakup_data; exit;
//    ------------------ COVAX Facility - Chinese Breakup (Doses) END   -----------------------  
//    ------------------ COVAX Facility - Western Breakup (Doses) START   ---------------------
if (!empty($covax_western_breakup)) {
    $covax_western_breakup_label = '[';
    $covax_western_breakup_data = '[';
    foreach ($covax_western_breakup as $k11 => $val11) {
//            print_r($val); exit;
        $covax_western_breakup_data .= $val11['totalqty'] . ",";
        $covax_western_breakup_label .= '"' . $val11['itmname'] . '",';
    }
    $covax_western_breakup_label = substr_replace($covax_western_breakup_label, "", -1);
    $covax_western_breakup_label .= ']';
    $covax_western_breakup_data = substr_replace($covax_western_breakup_data, "", -1);
    $covax_western_breakup_data .= ']';
} else {
    $covax_western_breakup_label = '["Pfizer-BioNTech","SinoPharm","PakVac"]';
    $covax_western_breakup_data = '[50000,65000,470]';
}

//echo $covax_western_breakup_label;
//echo $covax_western_breakup_data; exit;
//    ------------------ COVAX Facility - Western Breakup (Doses) END   ----------------------- 
//    ------------------ FDI - USAID Monthly COVAX Reverse Logistics Analysis START   ---------------------
if(!empty($reverse_logistics_analysis)){
$reverse_logistics_analysis_label = '[';
$reverse_logistics_analysis_data = '[';
$total_doses = $total_boxes = 0;
foreach ($reverse_logistics_analysis as $k1 => $val1) {
    $yeararray = explode("-", $val1['month']);
    $year = $yeararray[1];
    $year = str_replace('20', '', $year);
    $monthName = date('M', mktime(0, 0, 0, $yeararray[0], 10)); // March
    $monthName = $monthName.'-'.$year ; 
    $reverse_logistics_analysis_data .= $val1['sum'] . ",";
    $reverse_logistics_analysis_label .= '"' . $monthName . '",';
    $total_doses = $total_doses + $val1['sum_doses'];
    $total_boxes = $total_boxes + $val1['sum'];
}
//    echo $total_doses;exit;
$reverse_logistics_analysis_label = substr_replace($reverse_logistics_analysis_label, "", -1);
$reverse_logistics_analysis_label .= ']';
$reverse_logistics_analysis_data = substr_replace($reverse_logistics_analysis_data, "", -1);
$reverse_logistics_analysis_data .= ']';
}
 else {
     $reverse_logistics_analysis_label = '["No Data","No Data","No Data"]';
    $reverse_logistics_analysis_data = '[0,0,0]';
}

//echo $reverse_logistics_analysis_label;
//echo $reverse_logistics_analysis_data; exit;
//    ------------------ FDI - USAID Monthly COVAX Reverse Logistics Analysis END   -----------------------    
//    ------------------ FDI - USAID COVAX Reverse Logistics Activity START---------------------
if(!empty($reverse_logistics_activity)){
$reverse_logistics_activity_label = '[';
$reverse_logistics_activity_data = '[';
$reverse_logistics_activity_color = '[';
$total_doses_activity = $total_boxes_activity =   array();
foreach ($reverse_logistics_activity as $k3 => $val3) {
    $reverse_logistics_activity_data .= $val3['sum'] . ",";
    $reverse_logistics_activity_label .= '"' . $val3['date'] . '",';
//    $total_doses_activity = $total_doses_activity + $val3['sum_doses'];
//    $total_boxes_activity = $total_boxes_activity + $val3['sum'];
    @$total_doses_activity[$val3['activity_type']] += $val3['sum_doses'];
    @$total_boxes_activity[$val3['activity_type']] += $val3['sum'];
	if ($val3['activity_type'] == 1){
		$reverse_logistics_activity_color .= '"#00401A",';
	}
	else{
		$reverse_logistics_activity_color .= '"#1265c9",';
	}
}
$reverse_logistics_activity_label = substr_replace($reverse_logistics_activity_label, "", -1);
$reverse_logistics_activity_label .= ']';
$reverse_logistics_activity_data = substr_replace($reverse_logistics_activity_data, "", -1);
$reverse_logistics_activity_data .= ']';
$reverse_logistics_activity_color = substr_replace($reverse_logistics_activity_color, "", -1);
$reverse_logistics_activity_color .= ']';
}
else{
    $reverse_logistics_activity_label = '["No Data","No Data","No Data"]';
$reverse_logistics_activity_data = '[0,0,0]';
}
//echo $reverse_logistics_activity_label;
//echo $reverse_logistics_activity_data; exit;
//    ------------------ FDI - USAID COVAX Reverse Logistics Activity END-----------------------

//    ------------------ Daily Vaccination START   ---------------------
if (!empty($daily_vaccination_1)) {
    $daily_vaccination_label = '[';
    $daily_vaccination_data = '['; 
    foreach ($daily_vaccination_1 as $k12 => $val12) {
//            print_r($val12); exit;
        $daily_vaccination_data .= $val12['first_dose'] . "," .$val12['full_vaccinated'] . "," .$val12['booster']  . ",";
       
    }
    $daily_vaccination_label = '["First Dose","Fully Vaccinated","Booster"]';
    $daily_vaccination_data = substr_replace($daily_vaccination_data, "", -1);
    $daily_vaccination_data .= ']';
} else {
    $daily_vaccination_label = '["First Dose","Fully Vaccinated","Booster"]';
    $daily_vaccination_data = '[139058054,131011824,40377035]';
}

//echo $daily_vaccination_label;
//echo $daily_vaccination_data; exit; 
if(!empty($total_vaccination)) {
    $first_dose = $full_vacc = $booster = 0; 
    foreach ($total_vaccination as $k13 => $val13) {
        $first_dose = $val13['first_dose'];
        $full_vacc = $val13['full_vaccinated'];
        $booster = $val13['booster'];
    }
}else
{
     $first_dose = 0;
        $full_vacc = 0;
        $booster = 0;
}
if (!empty($daily_vaccination)) {
    $first_dose_1 = $full_vacc_1 = $booster_1 = 0; $updated_date = '';
    foreach ($daily_vaccination as $k14 => $val14) {
//            print_r($val12); exit;
        $first_dose_1 = $val14['first_dose'];
        $full_vacc_1 = $val14['full_vaccinated'];
        $booster_1 = $val14['booster'];
         $updated_date = date("d-M-Y", strtotime($val14['date']));
    }
} else {
     $first_dose_1 = 0;
        $full_vacc_1 = 0;
        $booster_1 = 0;
}

//    ------------------ Daily Vaccination  END   -----------------------
?>

<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
			
                <div class="col-md-12" >
				
                    <div class="panel-heading" style="background-color:#1473b3;">
					
                        <div class="panel-title">
                            <h6 style="color:white; overflow:hidden; " class="panel-title txt-light"><?= $page_title; ?><img style="float: right;" src="https://chart.googleapis.com/chart?cht=qr&chs=50x50&chl=https://covid.lmis.gov.pk/immunization/vaccine_stock?qr=true" /></h6>
							
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                        <div class="row" >
                            <div class="col-md-12" >
                                <form method="post"  name="form1" action="<?php echo base_url(); ?>immunization/vaccine_stock">
                                    <div class="col-sm-4">
                                        <div class="form-group mr-15">
                                            <label class="control-label mr-10" for="email_inline">From Date </label>
                                            <input class="form-control"  type="date" id ="from_date" name="from_date" value="<?php echo $from_date ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group mr-15">
                                            <label class="control-label mr-10" for="pwd_inline">To Date</label>
                                            <input class="form-control" type="date" id ="to_date" name="to_date" value="<?php echo $to_date ?>" >
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group mr-15">
                                            <label class="control-label mr-10" for="pwd_inline">&nbsp;</label>
                                            <input class="btn btn-success form-control"  type="submit" name="save_btn1" id="save_btn1" value="Go"> 
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>                     
                        <div class="row">
                             <div class="col-lg-6">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading"  style="background-color:#fcd3a9;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVID Vaccine Received By Funding Source (Doses) as on <?php echo date("d-M-Y", strtotime($to_date)); ?></h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="incident" height="260"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div>
                           
                            <div class="col-lg-6">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading"  style="background-color:#fcd3a9;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark"> COVID Vaccine Stock Status as on Today: <?php echo date('d-M-Y'); ?></h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="stock_status"  height="260"></canvas>
                                        </div>
                                    </div>
                                    <div>Under Testing</div>
                                </div>	
                            </div> 
                                                      
                            </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#fcd3a9;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVID Vaccine – Antigen wise Stock Received (Doses) as on <?php echo date("d-M-Y", strtotime($to_date)); ?> </h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <?php if($is_mobile == 'No') { ?>
                                            <canvas id="myChart"  height="115"></canvas>
                                            <?php } else { ?>
                                            <canvas id="myChart"  height="310"></canvas>
                                            <?php }  ?>
                                        </div>
                                    </div>

                                </div>	
                            </div>  
                            
                        </div>
                        <div class="row"> 
                           

                            <div class="col-lg-4">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#fcd3a9;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVID Vaccine Received (Doses) – Share Percentage By Funding Source</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="piechart" height="280"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div>  
                            <div class="col-lg-4">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#fcd3a9;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVID Vaccine  Received (Doses) - Regional Sourcing Status</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="age" height="280"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div> 
                              <div class="col-lg-4">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#fcd3a9;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVAX Facility - Region wise Vaccine Breakup (Doses)</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="covax_share" height="280"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div> 
                        </div>

                        <div class="row">
                            <div class="col-lg-4">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#c3f7ba;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVID Vaccine - Govt Procured Breakup (Doses)</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="govt_breakup"  height="300"></canvas>
                                        </div>
                                    </div>

                                </div>	
                            </div>

                            <div class="col-lg-4">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#c3f7ba;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVID Vaccine - COVAX Facility Breakup (Doses)</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="facility_breakup"  height="300"></canvas>
                                        </div>
                                    </div>

                                </div>	
                            </div> 
                            <div class="col-lg-4">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#c3f7ba;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVID Vaccine - Donation Breakup (Doses)</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="donation_breakup" height="300"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div>
                        </div>
                        <div class="row">
                                  <div class="col-lg-4">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#c3f7ba;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVAX Facility - USG Breakup (Doses)</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="usg_breakup" height="330"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div>
                                <div class="col-lg-4">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#c3f7ba;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVAX Facility - Chinese Breakup (Doses)</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="chinese_breakup" height="310"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div>
                              <div class="col-lg-4">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#c3f7ba;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">COVAX Facility - Western Breakup (Doses)</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="western_breakup" height="310"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#efc4f5;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">FDI - Monthly Reverse Logistics Analysis</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="bed" height="380"></canvas>
                                        </div>
                                    </div>
                                    <div><?php echo 'Total ' . $total_boxes . ' thermal boxes'. '(COVAX ' . $total_boxes_activity[2] .' & Govt. Procured ' . $total_boxes_activity[1] .') with data loggers <br>' . round(($total_doses / 1000000), 2) . ' MLN Doses' . '(COVAX ' . round(($total_doses_activity[2] / 1000000), 2) .' & Govt. Procured ' . round(($total_doses_activity[1] / 1000000), 2) .' ) '; ?></div>
                                </div>	
                            </div>
                            <div class="col-lg-7">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#efc4f5;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">FDI - Reverse Logistics Activity</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="ventilator" height="370"></canvas>
                                        </div>
                                    </div>
									<div style="margin: 0% 0% 0% 10%;">
										<p class="text-primary"><?php echo 'COVAX ' . $total_boxes_activity[2] . ' thermal boxes with data loggers ' . round(($total_doses_activity[2] / 1000000), 2) . ' MLN Doses'; ?></p>
										<p class="text-success" style="margin-top: -17px"><?php echo 'Govt. Procured ' . $total_boxes_activity[1] . ' thermal boxes with data loggers ' . round(($total_doses_activity[1] / 1000000), 2) . ' MLN Doses'; ?></p>
									</div>

                                </div>
                            </div>      
                        </div>
                         <div class="row"> 
                            <div class="col-lg-6">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#bad4f7;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">Vaccination Doses Administrated</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                   <table class="table-striped table-bordered " height="220">
                                    <tr style="background-color:#ebcccc" colspan="3">
                                        <td>Total Till Date</td><td></td>
                                    </tr>
                                     <tr colspan="1">
                                         <td>First Dose</td><td><?php echo number_format($first_dose); ?></td>
                                    </tr>
                                     <tr colspan="1">
                                        <td>Fully Vaccinated</td><td><?php echo number_format($full_vacc); ?></td>
                                    </tr>
                                     <tr colspan="1">
                                        <td>Booster</td><td style="background-color:#fcf9cf"><?php echo number_format($booster); ?></td>
                                    </tr>
                                      <tr style="background-color:#bdf79c"  colspan="1">
                                        <td>Total Doses Administered</td><td><?php echo number_format($first_dose + $full_vacc + $booster); ?></td>
                                    </tr>
                                     <tr style="background-color:#ebcccc" colspan="3">
                                        <td>Last 24 Hours<?php echo ' (Updated on '. $updated_date .')' ; ?></td><td></td>
                                    </tr>
                                     <tr colspan="1">
                                         <td>First Dose</td><td><?php echo number_format($first_dose_1); ?></td>
                                    </tr>
                                     <tr colspan="1">
                                        <td>Fully Vaccinated</td><td><?php echo number_format($full_vacc_1); ?></td>
                                    </tr>
                                     <tr colspan="1">
                                        <td>Booster</td><td style="background-color:#fcf9cf"><?php echo number_format($booster_1); ?></td>
                                    </tr>
                                      <tr style="background-color:#bdf79c"  colspan="1">
                                        <td>Total Doses Administered</td><td><?php echo number_format($first_dose_1 + $full_vacc_1 + $booster_1); ?></td>
                                    </tr>

                                </table>
                                        </div>
                                    </div>
                                </div>	
                            </div>
                              <div class="col-lg-6">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading" style="background-color:#bad4f7;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">Vaccination Doses</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="daily_vaccinated" height="410"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div>  
                             </div>
                        <div class="row">
                               <div class="col-lg-12">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading"  style="background-color:#fcd3a9;">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark"> COVID Vaccine Received Yearly Comparison</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="comparison"  height="300"></canvas>
                                        </div>
                                    </div>

                                </div>	
                            </div> 
                            </div>
                        <div class="row" style="display: none">
                            <div class="col-lg-6">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">Death Cases</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="deathcases" height="200"></canvas>
                                        </div>
                                    </div>
                                </div>	
                            </div>
                            <div class="col-lg-6">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">Gender Wise Positive Cases</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="gender" height="200"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                        <!--<div><b>Click on the Graph for Drilldown</b></div>-->                           

                    </div>
                </div>

            </div>
        </div>
        <!-- /.row -->
    </section>
</div>
<!-- /.container-fluid -->

<!--</div>-->
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->

<script>
    /*Chartjs Init*/

    $(document).ready(function () {
        //        "use strict";

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Vaccine  Stock Status (Doses) Start xxxxxxxxxxxxxxxxxxxxxxxxxx
  var ctx_stockstatus = document.getElementById("stock_status").getContext("2d");
        var config_stockstatus = {
            type: 'bar',
            data: {
                labels: ["Received","Issued","SOH"],
                datasets: [{
                        label: "Quantity",
                        type: "bar",
                        backgroundColor: [
                            '#170b87',
                            '#17b329',
                            '#f0e11a',
                             '#c91212',
                            '#f43c93',
                            '#d043b6',
                            '#9554d2',
                            '#1462e0',
                        ],
                        data: ['314156380','311484932','2671448']
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                 tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.fillText(data, bar._model.x, bar._model.y );
                            });
                        });
//                        
//                             Chart.helpers.each(meta.data.forEach((bar, index) => {
//                                const label = this.data.labels[index];
//                                const labelPositionX = 20;
//                                const labelWidth = ctx.measureText(label).width + labelPositionX;
//                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
//                                ctx.textBaseline = 'middle';
//                                ctx.textAlign = 'left';
//                                ctx.fillStyle = '#030303';
////                                ctx.fillText(label, labelPositionX, bar._model.y);
//                                 ctx.fillText(data, bar._model.x + 5, bar._model.y );
//                            }));
                        
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent_stockstatus
            }
        }; // end of var config

        function chartClickEvent_stockstatus(event, array)
        {
            if (myLiveChart_stockstatus === undefined || myLiveChart_stockstatus == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart_stockstatus.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
//            window.open("<?php echo base_url(); ?>dashboard/vent_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChart_stockstatus = new Chart(ctx_stockstatus, config_stockstatus);
// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Vaccine  Stock Status (Doses) END xxxxxxxxxxxxxxxxxxxxxxxxxx

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   COVID MIS - Vaccine Wise Stock Received (Doses) Start xxxxxxxxxxxxxxxxxxxxxxxxxx
        $(document).ready(function () {
            var horizontalBarChartData = {
                labels: <?php echo $vaccine_wise_stock_received_label; ?>,
                datasets: [{
                        backgroundColor: "#0d7ad9",
                        borderColor: "#d90d0d",
                        borderWidth: 2,
                        data: <?php echo $vaccine_wise_stock_received_data; ?>
                    }]

            };
            var ctx = document.getElementById("myChart").getContext("2d");
            var myHorizontalBar = new Chart(ctx, {
                type: 'horizontalBar',
                data: horizontalBarChartData,
                options: {

                    scales: {
                        yAxes: [{
                                barThickness: 20,
                                ticks: {
                                    beginAtZero: false,
                                    mirror: false,
                                },
                            }],
                        xAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                },
                            }],
                    },
                     tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.xLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Horizontal Bar Chart'
                    },
                    animation: {
                        duration: 1,
                        onComplete() {
                            const chartInstance = this.chart;
                            const ctx = chartInstance.ctx;
                            const dataset = this.data.datasets[0];
                            const meta = chartInstance.controller.getDatasetMeta(0);

                            Chart.helpers.each(meta.data.forEach((bar, index) => {
                                const label = this.data.labels[index];
                                const labelPositionX = 20;
                                const labelWidth = ctx.measureText(label).width + labelPositionX;
                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.textBaseline = 'middle';
                                ctx.textAlign = 'left';
                                ctx.fillStyle = '#030303';
//                                ctx.fillText(label, labelPositionX, bar._model.y);
                                 ctx.fillText(data, bar._model.x + 5, bar._model.y );
                            }));
//                            
                           
                         //Loop through each data in the datasets
//                        this.data.datasets.forEach(function (dataset, i) {
//                               ctx.textAlign = 'center';
//                        ctx.fillStyle = "rgba(255, 255, 255, 1)";
//                        ctx.textBaseline = 'bottom';
//                            var meta = chartInstance.controller.getDatasetMeta(i);
//                            meta.data.forEach(function (bar, index) {
//                                const labelPositionX = 30;
//                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
////                                ctx.fillText(data, bar._model.x + 20, bar._model.y + 10);
//                                ctx.fillText(data, labelPositionX, bar._model.y +8);
//                            });
//                        });
                            
                        }
                    }
                }
            });
        });
//            xxxxxxxxxxxxxxxxxxxxxxxxxx  COVID MIS - Vaccine Wise Stock Received (Doses)   END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   COVID Vaccine Received (Doses) Start (Bar Chart) xxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctx = document.getElementById("incident").getContext("2d");

        var config = {
            type: 'bar',
            data: {
                labels: <?php echo $covid_vaccine_received_label; ?>,
                datasets: [{
                        label: "Quantity",
                        type: "bar",
                        backgroundColor: [

                            '#c91212','#12c918', '#170b87',
                            '#1265c9',
                            '#f43c93',
                            '#d043b6',
                            '#9554d2',
                            '#1462e0',
                        ],
                        data: <?php echo $covid_vaccine_received_data; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                 tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent
            }
        }; // end of var config

        function chartClickEvent(event, array)
        {
            if (myLiveChart === undefined || myLiveChart == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
//            window.open("<?php echo base_url(); ?>dashboard/vent_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChart = new Chart(ctx, config);
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    COVID Vaccine Received (Doses) END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

//             ------------------- COVID Vaccine Received - Percentage Of Share START --------------------
        var data = {
            datasets: [{
                    data: <?php echo $covid_vaccine_received_data_1; ?>,
                    backgroundColor: [
                        '#c91212','#12c918',
                        '#170b87',
                        '#1265c9',
                        '#f43c93',
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)",
                        "rgba(245, 146, 93,1)",
                        "rgba(56, 37, 184,1)",
                        "rgba(222, 108, 27,1)"
                    ]
                }],
            labels: <?php echo $covid_vaccine_received_label_1 ?>
        };
        var pieOptions = {
			/*legend: {
        display: true,
        labels: {
              fontSize: 15,
			  fontFamily: 'Arial'
        }},*/
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'right';
                    ctx.textBaseline = 'top';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";
                             var tot = Number((val / 1000000) .toFixed(2)) + "M";
//                            var tot = String(Math.round(val / 1000000)) + "M";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                                ctx.fillText(tot, model.x + x, model.y + y + 25);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("piechart");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'pie',
                        data: data,
                        options: pieOptions
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];
                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
//                            window.open("<?php echo base_url(); ?>dashboard/positive_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );
//                  ------------------- COVID Vaccine Received - Percentage Of Share END --------------------

//             -------------------  Region Wise Vaccine Breakup (Doses) START --------------------
        var dataage = {
            datasets: [{
                    data: <?php echo $region_vaccine_breakup_data; ?>,
                    backgroundColor: [
                        '#c91212',
                        '#170b87',
                        '#1265c9',
                        '#12c918',
                        '#f43c93',
                        "#4c8ce6",
                        "#3fccc0",
                        "rgba(139,195,74,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)"

                    ]
                }],
            labels: <?php echo $region_vaccine_breakup_label; ?>
        };
        var pieOptionsage = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";
//                            var tot = String(Math.round(val / 1 * 1)) + "Doses";
                            var tot = Number((val / 1000000) .toFixed(2)) + "M";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                                ctx.fillText(tot, model.x + x +10, model.y + y + 25);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("age");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: dataage,
                        options: pieOptionsage
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];

                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
//                            window.open("<?php echo base_url(); ?>dashboard/age_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );
//      -------------------  Region Wise Vaccine Breakup (Doses) END --------------------       

//      xxxxxxxxxxxxxxxxxxxxxxxxx   COVID Vaccine - Govt Procured Breakup (Doses) START xxxxxxxxxxxxxxxxxxxx
        $(document).ready(function () {
            var horizontalBarChartData = {
                labels: <?php echo $govt_procured_breakup_label; ?>,
                datasets: [{
                        backgroundColor: "#d90d0d",
                        borderWidth: 1,
                        data: <?php echo $govt_procured_breakup_data; ?>
                    }]

            };
            var ctx = document.getElementById("govt_breakup").getContext("2d");
            var myHorizontalBar = new Chart(ctx, {
                type: 'horizontalBar',
                data: horizontalBarChartData,
                options: {

                    scales: {
                        yAxes: [{
                                barThickness: 20,
                                ticks: {
                                    beginAtZero: false,
                                    mirror: false,
                                },
                            }],
                        xAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                },
                            }],
                    },
                       tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.xLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Horizontal Bar Chart'
                    },
                    animation: {
                        duration: 1,
                        onComplete() {
                            const chartInstance = this.chart;
                            const ctx = chartInstance.ctx;
                            const dataset = this.data.datasets[0];
                            const meta = chartInstance.controller.getDatasetMeta(0);

                              Chart.helpers.each(meta.data.forEach((bar, index) => {
                                const label = this.data.labels[index];
                                const labelPositionX = 20;
                                const labelWidth = ctx.measureText(label).width + labelPositionX;
                                 var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.textBaseline = 'middle';
                                ctx.textAlign = 'left';
                                ctx.fillStyle = '#030303';
//                                ctx.fillText(label, labelPositionX, bar._model.y);
                                 ctx.fillText(data, bar._model.x + 2, bar._model.y );
                            }));
                            
                            
                           
                        // Loop through each data in the datasets
//                        this.data.datasets.forEach(function (dataset, i) {
//                               ctx.textAlign = 'center';
//                        ctx.fillStyle = "rgba(255, 255, 255, 1)";
//                        ctx.textBaseline = 'bottom';
//                            var meta = chartInstance.controller.getDatasetMeta(i);
//                            meta.data.forEach(function (bar, index) {
//                                const labelPositionX = 30;
//                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
////                                ctx.fillText(data, bar._model.x + 20, bar._model.y + 10);
//                                ctx.fillText(data, labelPositionX, bar._model.y +8);
//                            });
//                        });
                        }
                    }
                }
            });
        });
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    COVID Vaccine - Govt Procured Breakup (Doses) END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

//           xxxxxxxxxxxxxxxxxxxxxx  COVID Vaccine - COVAX Facility Breakup (Doses) START xxxxxxxxxxxxxxxxxxxxxx
        $(document).ready(function () {
            var horizontalBarChartData = {
                labels: <?php echo $covax_facility_breakup_label; ?>,
                datasets: [{
                        backgroundColor: "#220f99",
                        borderWidth: 1,
                        data: <?php echo $covax_facility_breakup_data; ?>
                    }]

            };
            var ctx = document.getElementById("facility_breakup").getContext("2d");
            var myHorizontalBar = new Chart(ctx, {
                type: 'horizontalBar',
                data: horizontalBarChartData,
                options: {

                    scales: {
                        yAxes: [{
                                barThickness: 20,
                                ticks: {
                                    beginAtZero: false,
                                    mirror: false,
                                },
                            }],
                        xAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                },
                            }],
                    },
                       tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.xLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Horizontal Bar Chart'
                    },
                    animation: {
                        duration: 1,
                        onComplete() {
                            const chartInstance = this.chart;
                            const ctx = chartInstance.ctx;
                            const dataset = this.data.datasets[0];
                            const meta = chartInstance.controller.getDatasetMeta(0);

                                Chart.helpers.each(meta.data.forEach((bar, index) => {
                                const label = this.data.labels[index];
                                const labelPositionX = 20;
                                const labelWidth = ctx.measureText(label).width + labelPositionX;
                                 var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.textBaseline = 'middle';
                                ctx.textAlign = 'left';
                                ctx.fillStyle = '#030303';
//                                ctx.fillText(label, labelPositionX, bar._model.y);
                                 ctx.fillText(data, bar._model.x + 2, bar._model.y );
                            }));
                            
                            
                           
                        // Loop through each data in the datasets
//                        this.data.datasets.forEach(function (dataset, i) {
//                               ctx.textAlign = 'center';
//                        ctx.fillStyle = "rgba(255, 255, 255, 1)";
//                        ctx.textBaseline = 'bottom';
//                            var meta = chartInstance.controller.getDatasetMeta(i);
//                            meta.data.forEach(function (bar, index) {
//                                const labelPositionX = 30;
//                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
////                                ctx.fillText(data, bar._model.x + 20, bar._model.y + 10);
//                                ctx.fillText(data, labelPositionX, bar._model.y +8);
//                            });
//                        });
                        }
                    }
                }
            });
        });
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    COVID Vaccine - COVAX Facility Breakup (Doses) END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   COVID Vaccine - Donation Breakup (Doses) START xxxxxxxxxxxxxxxxxxxxxxxxxx

       $(document).ready(function () {
            var horizontalBarChartData = {
                labels: <?php echo $donation_breakup_label; ?>,
                datasets: [{
                        backgroundColor: "#1265c9",
                        borderWidth: 1,
                        data: <?php echo $donation_breakup_data; ?>
                    }]

            };
            var ctx = document.getElementById("donation_breakup").getContext("2d");
            var myHorizontalBar = new Chart(ctx, {
                type: 'horizontalBar',
                data: horizontalBarChartData,
                options: {

                    scales: {
                        yAxes: [{
                                barThickness: 20,
                                ticks: {
                                    beginAtZero: false,
                                    mirror: false,
                                },
                            }],
                        xAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                },
                            }],
                    },
                       tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.xLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Horizontal Bar Chart'
                    },
                    animation: {
                        duration: 1,
                        onComplete() {
                            const chartInstance = this.chart;
                            const ctx = chartInstance.ctx;
                            const dataset = this.data.datasets[0];
                            const meta = chartInstance.controller.getDatasetMeta(0);

                                Chart.helpers.each(meta.data.forEach((bar, index) => {
                                const label = this.data.labels[index];
                                const labelPositionX = 20;
                                const labelWidth = ctx.measureText(label).width + labelPositionX;
                                 var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.textBaseline = 'middle';
                                ctx.textAlign = 'left';
                                ctx.fillStyle = '#030303';
//                                ctx.fillText(label, labelPositionX, bar._model.y);
                                 ctx.fillText(data, bar._model.x + 2, bar._model.y );
                            }));
                        }
                    }
                }
            });
        });       
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    COVID VACCINE - Donation Breakup Doses END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

//       xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  COVAX Facility - USG Breakup (Doses) START xxxxxxxxxxxxxxxxxxxxxxxxxx
        $(document).ready(function () {
            var horizontalBarChartData = {
                labels: <?php echo $covax_usg_breakup_label; ?>,
                datasets: [{
                        backgroundColor: "#c91212",
                        borderWidth: 1,
                        data: <?php echo $covax_usg_breakup_data; ?>
                    }]

            };
            var ctx = document.getElementById("usg_breakup").getContext("2d");
            var myHorizontalBar = new Chart(ctx, {
                type: 'horizontalBar',
                data: horizontalBarChartData,
                options: {

                    scales: {
                        yAxes: [{
                                barThickness: 20,
                                ticks: {
                                    beginAtZero: false,
                                    mirror: false,
                                },
                            }],
                        xAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                },
                            }],
                    },
                       tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.xLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Horizontal Bar Chart'
                    },
                    animation: {
                        duration: 1,
                        onComplete() {
                            const chartInstance = this.chart;
                            const ctx = chartInstance.ctx;
                            const dataset = this.data.datasets[0];
                            const meta = chartInstance.controller.getDatasetMeta(0);

                               Chart.helpers.each(meta.data.forEach((bar, index) => {
                                const label = this.data.labels[index];
                                const labelPositionX = 20;
                                const labelWidth = ctx.measureText(label).width + labelPositionX;
                                 var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.textBaseline = 'middle';
                                ctx.textAlign = 'left';
                                ctx.fillStyle = '#030303';
//                                ctx.fillText(label, labelPositionX, bar._model.y);
                                 ctx.fillText(data, bar._model.x + 2, bar._model.y );
                            }));
                            
                            
                           
                        // Loop through each data in the datasets
//                        this.data.datasets.forEach(function (dataset, i) {
//                               ctx.textAlign = 'center';
//                        ctx.fillStyle = "rgba(255, 255, 255, 1)";
//                        ctx.textBaseline = 'bottom';
//                            var meta = chartInstance.controller.getDatasetMeta(i);
//                            meta.data.forEach(function (bar, index) {
//                                const labelPositionX = 30;
//                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
////                                ctx.fillText(data, bar._model.x + 20, bar._model.y + 10);
//                                ctx.fillText(data, labelPositionX, bar._model.y +8);
//                            });
//                        });
                        }
                    }
                }
            });
        });
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    COVAX Facility - USG Breakup (Doses) END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

//       xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  COVAX Facility - Chinese Breakup (Doses) START xxxxxxxxxxxxxxxxxxxxxxxxxx
        $(document).ready(function () {
            var horizontalBarChartData = {
                labels: <?php echo $covax_chinese_breakup_label; ?>,
                datasets: [{
                        backgroundColor: "#220f99",
                        borderWidth: 1,
                        data: <?php echo $covax_chinese_breakup_data; ?>
                    }]

            };
            var ctx = document.getElementById("chinese_breakup").getContext("2d");
            var myHorizontalBar = new Chart(ctx, {
                type: 'horizontalBar',
                data: horizontalBarChartData,
                options: {

                    scales: {
                        yAxes: [{
                                barThickness: 20,
                                ticks: {
                                    beginAtZero: false,
                                    mirror: false,
                                },
                            }],
                        xAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                },
                            }],
                    },
                       tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.xLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Horizontal Bar Chart'
                    },
                    animation: {
                        duration: 1,
                        onComplete() {
                            const chartInstance = this.chart;
                            const ctx = chartInstance.ctx;
                            const dataset = this.data.datasets[0];
                            const meta = chartInstance.controller.getDatasetMeta(0);

                               Chart.helpers.each(meta.data.forEach((bar, index) => {
                                const label = this.data.labels[index];
                                const labelPositionX = 20;
                                const labelWidth = ctx.measureText(label).width + labelPositionX;
                                 var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.textBaseline = 'middle';
                                ctx.textAlign = 'left';
                                ctx.fillStyle = '#030303';
//                                ctx.fillText(label, labelPositionX, bar._model.y);
                                 ctx.fillText(data, bar._model.x + 2, bar._model.y );
                            }));
                            
                            
                           
                        // Loop through each data in the datasets
//                        this.data.datasets.forEach(function (dataset, i) {
//                               ctx.textAlign = 'center';
//                        ctx.fillStyle = "rgba(255, 255, 255, 1)";
//                        ctx.textBaseline = 'bottom';
//                            var meta = chartInstance.controller.getDatasetMeta(i);
//                            meta.data.forEach(function (bar, index) {
//                                const labelPositionX = 30;
//                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
////                                ctx.fillText(data, bar._model.x + 20, bar._model.y + 10);
//                                ctx.fillText(data, labelPositionX, bar._model.y +8);
//                            });
//                        });
                        }
                    }
                }
            });
        });
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    COVAX Facility - Chinese Breakup (Doses) END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

//       xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  COVAX Facility - Western Breakup (Doses) START xxxxxxxxxxxxxxxxxxxxxxxxxx
        $(document).ready(function () {
            var horizontalBarChartData = {
                labels: <?php echo $covax_western_breakup_label; ?>,
                datasets: [{
                        backgroundColor: "#1265c9",
                        borderWidth: 1,
                        data: <?php echo $covax_western_breakup_data; ?>
                    }]

            };
            var ctx = document.getElementById("western_breakup").getContext("2d");
            var myHorizontalBar = new Chart(ctx, {
                type: 'horizontalBar',
                data: horizontalBarChartData,
                options: {

                    scales: {
                        yAxes: [{
                                barThickness: 20,
                                ticks: {
                                    beginAtZero: false,
                                    mirror: false,
                                },
                            }],
                        xAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                },
                            }],
                    },
                       tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.xLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Horizontal Bar Chart'
                    },
                    animation: {
                        duration: 1,
                        onComplete() {
                            const chartInstance = this.chart;
                            const ctx = chartInstance.ctx;
                            const dataset = this.data.datasets[0];
                            const meta = chartInstance.controller.getDatasetMeta(0);

                               Chart.helpers.each(meta.data.forEach((bar, index) => {
                                const label = this.data.labels[index];
                                const labelPositionX = 20;
                                const labelWidth = ctx.measureText(label).width + labelPositionX;
                                 var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.textBaseline = 'middle';
                                ctx.textAlign = 'left';
                                ctx.fillStyle = '#030303';
//                                ctx.fillText(label, labelPositionX, bar._model.y);
                                 ctx.fillText(data, bar._model.x +2, bar._model.y );
                            }));
                            
                            
                           
                        // Loop through each data in the datasets
//                        this.data.datasets.forEach(function (dataset, i) {
//                               ctx.textAlign = 'center';
//                        ctx.fillStyle = "rgba(255, 255, 255, 1)";
//                        ctx.textBaseline = 'bottom';
//                            var meta = chartInstance.controller.getDatasetMeta(i);
//                            meta.data.forEach(function (bar, index) {
//                                const labelPositionX = 30;
//                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
////                                ctx.fillText(data, bar._model.x + 20, bar._model.y + 10);
//                                ctx.fillText(data, labelPositionX, bar._model.y +8);
//                            });
//                        });
                        }
                    }
                }
            });
        });
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    COVAX Facility - Western Breakup (Doses) END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   FDI - USAID Monthly COVAX Reverse Logistics Analysis Start (Bar Chart) xxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctxbed = document.getElementById("bed").getContext("2d");

        var configbed = {
            type: 'bar',
            data: {
                labels: <?php echo $reverse_logistics_analysis_label; ?>,
                datasets: [{
                        label: "Quantity",
                        type: "bar",
                        backgroundColor: [
                            "#4c70f5",
                            "#ff7477",
                            "#22b59f",
                            "#51c914",
                            "#7ee9ac",
                            "#66eac6",
                            "#57eadd",
                            "#59e8f0"
                        ],
                        data: <?php echo $reverse_logistics_analysis_data; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEventbed
            }
        }; // end of var config

        function chartClickEventbed(event, array)
        {
            if (myLiveChartbed === undefined || myLiveChartbed == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChartbed.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChartbed = new Chart(ctxbed, configbed);
//xxxxxxxxxxxxxxxxxxxxxxxxxx    FDI - USAID Monthly COVAX Reverse Logistics Analysis END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   FDI - USAID COVAX Reverse Logistics Activity Start (Bar Chart) xxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctxvent = document.getElementById("ventilator").getContext("2d");

        var configvent = {
            type: 'bar',
            data: {
                labels: <?php echo $reverse_logistics_activity_label; ?>,
                datasets: [{
                        label: "Doses",
                        type: "bar",
                        // backgroundColor: ["#9ff03c", "#e01534"],
                        backgroundColor:  <?php echo $reverse_logistics_activity_color; ?>,
                        data: <?php echo $reverse_logistics_activity_data; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEventvent
            }
        }; // end of var config

        function chartClickEventvent(event, array)
        {
            if (myLiveChartvent === undefined || myLiveChartvent == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChartvent.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChartvent = new Chart(ctxvent, configvent);
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    FDI - USAID COVAX Reverse Logistics Activity END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

//          xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Daily Vaccination START xxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctx_daily = document.getElementById("daily_vaccinated").getContext("2d");
        var config_daily = {
            type: 'bar',
            data: {
                labels: <?php echo $daily_vaccination_label; ?>,
                datasets: [{
                        label: "Quantity",
                        type: "bar",
                        backgroundColor: [

                            '#c91212', '#170b87',
                            '#1265c9',
                            '#12c918',
                            '#f43c93',
                            '#d043b6',
                            '#9554d2',
                            '#1462e0',
                        ],
                        data: <?php echo $daily_vaccination_data; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.6}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                 tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "#ffff";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.fillText(data, bar._model.x, bar._model.y +19);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent_daily
            }
        }; // end of var config

        function chartClickEvent_daily(event, array)
        {
            if (myLiveChart_daily === undefined || myLiveChart_daily == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart_daily.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
//            window.open("<?php echo base_url(); ?>dashboard/vent_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChart_daily = new Chart(ctx_daily, config_daily);
//            xxxxxxxxxxxxxxxxxxxxxxxxxx    Daily Vaccination END   xxxxxxxxxxxxxxxxxxxxxxxxxxxx

//             ------------------- COVAX Facility - Region Wise Vaccine Breakup (Doses) START --------------------
        var datacovax = {
            datasets: [{
                    data: <?php echo $covax_region_breakup_data; ?>,
                    backgroundColor: [
                        '#c91212',
                        '#170b87',
                        '#1265c9',
                        '#12c918',
                        '#f43c93',
                        "#4c8ce6",
                        "#3fccc0",
                        "rgba(139,195,74,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)"

                    ]
                }],
            labels: <?php echo $covax_region_breakup_label; ?>
        };
        var pieOptionscovax = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";
//                            var tot = String(Math.round(val / 1 * 1)) + "Doses";
                            var tot = Number((val / 1000000) .toFixed(2)) + "M";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                                ctx.fillText(tot, model.x + x +10, model.y + y + 25);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("covax_share");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: datacovax,
                        options: pieOptionscovax
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];

                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
//                            window.open("<?php echo base_url(); ?>dashboard/age_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );
//      ------------------- COVAX Facility - Region Wise Vaccine Breakup (Doses) END --------------------       

//        ----------------------- Comparison Graph START -------------------------------

var ctx_test = document.getElementById("comparison").getContext("2d");

        var config_test = {
            type: 'bar',
            data:  {
                labels: <?php echo $fd_name; ?>,
                datasets: [
                    {
                        type: "bar",
                        backgroundColor: "#1265c9",
                        borderColor: "rgba(54, 162, 235, 1)",
                        borderWidth: 1,
                        label: "2021",
                        data: <?php echo $qty_2021; ?>
                    },
                    {
                        type: "bar",
                        label: "2022",
                        backgroundColor: "#170b87",
                        data: <?php echo $qty_2022; ?>,
                        lineTension: 0,
                        fill: false
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },  tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = Number((dataset.data[index] / 1000000) .toFixed(2)) + "M";
                                ctx.fillText(data, bar._model.x, bar._model.y );
                            });
                        });
//                        
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: true, position: 'bottom'},
                onClick: chartClickEventtest
            }
        }; // end of var config

        function chartClickEventtest(event, array)
        {
            if (myLiveCharttest === undefined || myLiveCharttest == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveCharttest.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
//            window.open("../dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveCharttest = new Chart(ctx_test, config_test);

//        ----------------------- Comparison Graph END -------------------------------

        //             ------------------- GENDER WISE CASES START --------------------
        var genderCanvas = document.getElementById("gender");

        var genderData = {
            labels: ["Female", "Male", "Other"],
            datasets: [{
                    data: [16307368, 22558789, 11331120],
                    backgroundColor: [
                        "rgba(255, 0, 0, 0.5)",
                        "rgba(100, 255, 0, 0.5)",
                        "rgba(200, 50, 255, 0.5)",
                        "rgba(0, 100, 255, 0.5)"
                    ]
                }]
        };
       
        var polarAreaChart = new Chart(genderCanvas, {
            type: 'polarArea',
            data: genderData
        });
        //                  ------------------- Gender WISE CASES END --------------------






    });
</script>

