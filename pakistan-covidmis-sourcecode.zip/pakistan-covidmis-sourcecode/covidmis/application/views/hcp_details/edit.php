                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'hcp_details/index';?>">
                                        <i class="fa fa-arrow-left"></i> Back
                                    </a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <!-- <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Two Column Form</h5>
                                                </div>
                                            </div> -->
                                            <div class="panel-body">
                                                <h5 class="underline mt-n"><?= $page_title;?></h5>
                                                <form method="POST" action="<?= base_url().'hcp_details/edit/'.$hcp_detail[0]['id'];?>">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="date">Date</label>
                                                                <div class='input-group datepicker' id='datepicker'>
                                                                    <input type='text' class="form-control" name="date" id="date" placeholder="Select Date" value="<?= date('m/d/Y', strtotime($hcp_detail[0]['date']));?>" />
                                                                    <span class="input-group-addon">
                                                                        <span class="glyphicon glyphicon-calendar">
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="province_id">Province</label>
                                                                <select class="select2 form-control" id="province_id" name="province_id">
                                                                <?php if(!empty($provinces[0]['pk_id'])):?>
                                                                    <?php foreach($provinces as $province):?>
                                                                        <?php $sel = ($province['pk_id'] == $hcp_detail[0]['province_id'])?'selected':'';?>
                                                                        <option value="<?= $province['pk_id'];?>" <?= $sel;?>><?= $province['location_name'];?></option>
                                                                    <?php endforeach;?>
                                                                <?php endif;?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="confirmed_cases_of_workers">Total Confirmed Cases Among Health Care Workers</label>
                                                                <input type="text" class="form-control" id="confirmed_cases_of_workers" name="confirmed_cases_of_workers" placeholder="Enter Total Confirmed Cases Among Health Care Workers" value="<?= $hcp_detail[0]['confirmed_cases_of_workers'];?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="performing_duties">Total Performing Duties in Critical Care</label>
                                                                <input type="text" class="form-control" id="performing_duties" name="performing_duties" placeholder="Enter Total Performing Duties in Critical Care" value="<?= $hcp_detail[0]['performing_duties'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="performing_duties_elsewhere">Total Performing Duties Elsewhere</label>
                                                                <input type="text" class="form-control" id="performing_duties_elsewhere" name="performing_duties_elsewhere" placeholder="Enter Total Performing Duties Elsewhere" value="<?= $hcp_detail[0]['performing_duties_elsewhere'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="contacts_identified">Total Contacts Identified</label>
                                                                <input type="text" class="form-control" id="contacts_identified" name="contacts_identified" placeholder="Enter Total Contacts Identified" value="<?= $hcp_detail[0]['contacts_identified'];?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="contacts_in_quarantine">Contacts in Quarantine</label>
                                                                <input type="text" class="form-control" id="contacts_in_quarantine" name="contacts_in_quarantine" placeholder="Enter Contacts in Quarantine" value="<?= $hcp_detail[0]['contacts_in_quarantine'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="contacts_tested_today">Contacts Tested till Date</label>
                                                                <input type="text" class="form-control" id="contacts_tested_today" name="contacts_tested_today" placeholder="Enter Contacts Tested till Date" value="<?= $hcp_detail[0]['contacts_tested_today'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="results_received">Results Received</label>
                                                                <input type="text" class="form-control" id="results_received" name="results_received" placeholder="Enter Results Received" value="<?= $hcp_detail[0]['results_received'];?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="contacts_found_positive">Contacts Found Positive</label>
                                                                <input type="text" class="form-control" id="contacts_found_positive" name="contacts_found_positive" placeholder="Enter Contacts Found Positive" value="<?= $hcp_detail[0]['contacts_found_positive'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="results_awaited">Number of Results Awaited</label>
                                                                <input type="text" class="form-control" id="results_awaited" name="results_awaited" placeholder="Enter Number of Results Awaited" value="<?= $hcp_detail[0]['results_awaited'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 text-right">
                                                            <button type="submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                                <!-- /.row -->
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->