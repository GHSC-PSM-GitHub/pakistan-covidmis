                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'hcp_details/create';?>"><i class="fa fa-plus"></i> Add New</a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5><?= $page_title;?></h5>
                                                </div>
                                            </div>
                                            <div class="panel-body p-20" style="overflow: auto;">
                                                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 10%; text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>Confirmed Cases Among Health Care Workers</th>
                                                            <th>Performing Duties in Critical Care</th>
                                                            <th>Performing Duties Elsewhere</th>
                                                            <th>Contacts Identified</th>
                                                            <th>Contacts in Quarantine</th>
                                                            <th>Contacts Tested till Date</th>
                                                            <th>Results Received</th>
                                                            <th>Contacts Found Positive</th>
                                                            <th>Results Awaited</th>
                                                            <th style="width: 8%; text-align: center;">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tfoot>
                                                        <tr>
                                                            <th style="text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>Confirmed Cases Among Health Care Workers</th>
                                                            <th>Performing Duties in Critical Care</th>
                                                            <th>Performing Duties Elsewhere</th>
                                                            <th>Contacts Identified</th>
                                                            <th>Contacts in Quarantine</th>
                                                            <th>Contacts Tested till Date</th>
                                                            <th>Results Received</th>
                                                            <th>Contacts Found Positive</th>
                                                            <th>Results Awaited</th>
                                                            <th style="text-align: center;">Action</th>
                                                        </tr>
                                                    </tfoot>
                                                    <tbody>
                                                    <?php if(!empty($hcp_details[0]['id'])):?>
                                                        <?php $loop = 0;?>
                                                        <?php foreach($hcp_details as $hcp_detail):?>
                                                            <tr>
                                                                <td style="text-align: center;"><?= ++$loop;?></td>
                                                                <td><?= date('d F, Y', strtotime($hcp_detail['date']));?></td>
                                                                <td><?= $hcp_detail['province_name'];?></td>
                                                                <td><?= $hcp_detail['confirmed_cases_of_workers'];?></td>
                                                                <td><?= $hcp_detail['performing_duties'];?></td>
                                                                <td><?= $hcp_detail['performing_duties_elsewhere'];?></td>
                                                                <td><?= $hcp_detail['contacts_identified'];?></td>
                                                                <td><?= $hcp_detail['contacts_in_quarantine'];?></td>
                                                                <td><?= $hcp_detail['contacts_tested_today'];?></td>
                                                                <td><?= $hcp_detail['results_received'];?></td>
                                                                <td><?= $hcp_detail['contacts_found_positive'];?></td>
                                                                <td><?= $hcp_detail['results_awaited'];?></td>
                                                                <td style="text-align: center;">
                                                                    <a href="<?= base_url().'hcp_details/edit/'.$hcp_detail['id'];?>">
                                                                        <i class="fa fa-edit"></i>
                                                                    </a> &nbsp;&nbsp;
                                                                    <a href="<?= base_url().'hcp_details/delete/'.$hcp_detail['id'];?>">
                                                                        <i class="fa fa-trash"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->