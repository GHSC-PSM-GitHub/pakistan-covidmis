                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'users/index';?>">
                                        <i class="fa fa-arrow-left"></i> Back
                                    </a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <!-- <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Two Column Form</h5>
                                                </div>
                                            </div> -->
                                            <div class="panel-body">
                                                <h5 class="underline mt-n"><?= $page_title;?></h5>
                                                <?php
                                                $attributes = array('method' => 'POST');
                                                echo form_open(base_url() . 'users/create', $attributes);
                                                ?>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="username">Username</label>
                                                        <?php
                                                        $data = array(
                                                            'name' => 'username',
                                                            'id' => 'username',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Username...',
                                                            'value' => set_value('username'),
                                                            'required' => 'required'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger username_message"><?= form_error('username'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="password">Password</label>
                                                        <?php
                                                        $data = array(
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Password...',
                                                            'required' => 'required'
                                                        );

                                                        echo form_password('password', set_value('password'), $data);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('password'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="fullname">Full Name</label>
                                                        <?php
                                                        $data = array(
                                                            'name' => 'fullname',
                                                            'id' => 'fullname',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Full Name...',
                                                            'value' => set_value('fullname'),
                                                            'required' => 'required'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('fullname'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="email">Email</label>
                                                        <?php
                                                        $data = array(
                                                            'type' => 'email',
                                                            'name' => 'email',
                                                            'id' => 'email',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Email...',
                                                            'value' => set_value('email'),
                                                            'required' => 'required'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('email'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="contact">Contact</label>
                                                        <?php
                                                        $data = array(
                                                            'name' => 'contact',
                                                            'id' => 'contact',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Contact Number...',
                                                            'value' => set_value('contact'),
                                                            'required' => 'required'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('contact'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="designation">Designation</label>
                                                        <?php
                                                        $data = array(
                                                            'name' => 'designation',
                                                            'id' => 'designation',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Designation...',
                                                            'value' => set_value('designation'),
                                                            'required' => 'required'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('designation'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="province_id">Province</label>
                                                        <?php
                                                        $options = array();
                                                        $options[''] = 'Select Province';
                                                        if (!empty($provinces[0]['id'])):
                                                            foreach ($provinces as $province):
                                                                $options[$province['id']] = $province['province'];
                                                            endforeach;
                                                        endif;
                                                        $attributes = array('class' => 'form-control', 'id' => 'province_id');
                                                        echo form_dropdown('province_id', $options, set_value('province_id'), $attributes);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('province_id'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="status">Status</label>
                                                        <div class="form-control">
                                                            <?php
                                                            echo form_radio('status', '1', TRUE) . '&nbsp; Active &nbsp;&nbsp;';
                                                            echo form_radio('status', '0', FALSE) . '&nbsp; InActive &nbsp;&nbsp;';
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 text-right mt-20">
                                                        <?php
                                                        $attributes = array(
                                                            'class' => 'btn btn-primary'
                                                        );
                                                        echo form_submit('save', 'Save', $attributes);
                                                        ?>
                                                        <a href='<?= base_url() . 'admin/users/index'; ?>' class="btn btn-warning">Cancel</a>
                                                    </div>
                                                <?= form_close(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>