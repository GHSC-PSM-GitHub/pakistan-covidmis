<!--<pre>--><?php //print_r($user);exit();  ?><!--</pre>-->
<form method="POST" action="<?= base_url() . 'admin/users/update_password'; ?>">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h6 class="panel-title txt-dark">User</h6>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <div class="col-md-3">
                                        <label class="form-label" for="city_name">UserName</label>
                                        <input readonly type="text" class="form-control" value="<?= $user[0]['username']; ?>" />
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label" for="city_name">Full Name</label>
                                        <input readonly type="text" class="form-control" value="<?= $user[0]['fullname']; ?>" />
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label" for="city_name">Designation</label>
                                        <input readonly type="text" class="form-control" value="<?= $user[0]['designation']; ?>" />
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label" for="city_name">Email</label>
                                        <input readonly type="text"  class="form-control" value="<?= $user[0]['email']; ?>" />
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label" for="city_name">Set New Password</label>
                                        <input type="password" name="password" id="password"  class="form-control" oninput="validate()" />
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label" for="city_name">Confirm Password</label>
                                        <input type="password" name="confirm_password" id="confirm_password" class="form-control" oninput="validate()" />
                                    </div>
                                </div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <div class="col-md-3 pull-left"><p id="msg" style="color: red"></p></div>
                                    <div class="col-md-3 pull-right" >
                                        <input type="hidden" name="id" value="<?= $user[0]['id'] ?>">
                                        <button disabled type="submit" class="btn btn-primary btn-sm" id="save">Save</button>
                                        <a href='<?= base_url() . 'admin/users/index'; ?>' class="btn btn-primary btn-sm">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<script>
    function validate(){
        var val1 = $('#password').val();
        var val2 = $('#confirm_password').val();

        if (val1 == '' && val2 == ''){
            $('#save').attr('disabled', 'disabled');
        }

        if (val1 == val2){
            $('#save').removeAttr('disabled');
            $('#msg').text('');

        }
        else {
            $('#save').attr('disabled', 'disabled');
            $('#msg').text('Passwords do not match');
        }
    }
</script>
