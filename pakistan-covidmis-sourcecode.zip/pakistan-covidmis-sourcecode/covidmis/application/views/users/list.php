                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'users/create';?>"><i class="fa fa-plus"></i> Add New</a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5><?= $page_title;?></h5>
                                                </div>
                                            </div>
                                            <div class="panel-body p-20" style="overflow: auto;">
                                                <?php if (isset($_SESSION['success']) && $_SESSION['success'] != ''): ?>
                                                    <div class="alert alert-success" style="line-height: 10px;"><?= $_SESSION['success'];?></div>
                                                <?php endif; ?>
                                                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th>Sr.No</th>
                                                            <th>Username</th>
                                                            <th>Login ID</th>
                                                            <th>Email</th>
                                                            <th>Contact</th>
                                                            <th>Designation</th>
                                                            <th>Status</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <?php if (!empty($users[0]['pk_id'])): ?>
                                                        <tbody id="myTable">
                                                            <?php $loop = 0; ?>
                                                            <?php foreach ($users as $user): ?>
                                                                <tr>
                                                                    <td style="width: 5%; text-align: center;"><?= ++$loop; ?></td>
                                                                    <td><?= $user['user_name']; ?></td>
                                                                    <td><?= $user['login_id']; ?></td>
                                                                    <td><?= $user['email']; ?></td>
                                                                    <td><?= $user['cell_number']; ?></td>
                                                                    <td><?= $user['designation']; ?></td>
                                                                    <td>
                                                                        <?= ($user['status'] == 1) ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">InActive</span>'; ?>
                                                                    </td>
                                                                    <td>
                                                                        <a class="btn btn-xs btn-warning" href="<?= base_url() . 'users/edit/' . $user['pk_id']; ?>">
                                                                            <i class="fa fa-edit"></i> Edit
                                                                        </a>                                                                        <a href="<?= base_url() . 'users/delete/' . $user['pk_id']; ?>"

                                                                        <a href="<?= base_url() . 'users/delete/' . $user['pk_id']; ?>"
                        												   <?php
                        												   $message = "'Are you sure you want to Delete'";
                        												   if ($user['status'] == 1){ echo 'onclick="return confirm('. $message .')"';}?>>
                                                                            <?= ($user['status'] == 1) ? '<span class="btn btn-xs btn-primary"><i class="fa fa-times"></i> Disable</span>' : '<span class="btn btn-xs btn-primary"><i class="fa fa-check"></i> Enable</span>'; ?>
                                                                        </a>
                                                                        <!-- <a href="<?= base_url() . 'users/change_password/' . $user['pk_id']; ?>">
                                                                            <span class="btn btn-xs btn-warning"><i class="fa fa-lock"></i> Change Password</span>
                                                                        </a> -->
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    <?php endif; ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>