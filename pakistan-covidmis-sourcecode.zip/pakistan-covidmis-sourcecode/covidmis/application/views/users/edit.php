                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'users/index';?>">
                                        <i class="fa fa-arrow-left"></i> Back
                                    </a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <!-- <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Two Column Form</h5>
                                                </div>
                                            </div> -->
                                            <div class="panel-body">
                                                <h5 class="underline mt-n"><?= $page_title;?></h5>
                                                <?php
                                                $attributes = array('method' => 'POST');
                                                echo form_open(base_url() . 'users/edit/' . $user[0]['pk_id'], $attributes);
                                                ?>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="username">Username</label>
                                                        <?php
                                                        $data = array(
                                                            'class' => 'form-control',
                                                            'value' => $user[0]['user_name'],
                                                            'readonly' => 'readonly',
                                                            'disabled' => 'disabled'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger username_message"><?= form_error('username'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="fullname">Login ID</label>
                                                        <?php
                                                        $data = array(
                                                            'name' => 'user_name',
                                                            'id' => 'fullname',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Full Name...',
                                                            'value' => $user[0]['login_id'],
                                                            'required' => 'required'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('fullname'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="email">Email</label>
                                                        <?php
                                                        $data = array(
                                                            'type' => 'email',
                                                            'name' => 'email',
                                                            'id' => 'email',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Email...',
                                                            'value' => $user[0]['email'],
                                                            'required' => 'required'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('email'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="contact">Contact</label>
                                                        <?php
                                                        $data = array(
                                                            'name' => 'cell_number',
                                                            'id' => 'contact',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Contact Number...',
                                                            'value' => $user[0]['cell_number'],
                                                            'required' => 'required'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('contact'); ?></span>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="designation">Designation</label>
                                                        <?php
                                                        $data = array(
                                                            'name' => 'designation',
                                                            'id' => 'designation',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'Enter Designation...',
                                                            'value' => $user[0]['designation'],
                                                            'required' => 'required'
                                                        );

                                                        echo form_input($data);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('designation'); ?></span>
                                                    </div>
<!--                                                    <div class="col-md-3">
                                                        <label class="form-label" for="province_id">Province</label>
                                                        <?php
                                                        $options = array();
                                                        $options[''] = 'Select Province';
                                                        if (!empty($provinces[0]['id'])):
                                                            foreach ($provinces as $province):
                                                                $options[$province['id']] = $province['province'];
                                                            endforeach;
                                                        endif;
                                                        $attributes = array('class' => 'form-control');
                                                        echo form_dropdown('province_id', $options, $user[0]['province_id'], $attributes);
                                                        ?>
                                                        <span class="text-danger"><?= form_error('province_id'); ?></span>
                                                    </div>-->
                                                    <div class="col-md-3">
                                                        <label class="form-label" for="status">Status</label>
                                                        <div class="form-control">
                                                            <?php
                                                            if ($user[0]['status'] == 1) {
                                                                echo form_radio('status', '1', TRUE) . '&nbsp; Active &nbsp;&nbsp;';
                                                            } else {
                                                                echo form_radio('status', '1', FALSE) . '&nbsp; Active &nbsp;&nbsp;';
                                                            }if ($user[0]['status'] == 0) {
                                                                echo form_radio('status', '0', TRUE) . '&nbsp; InActive &nbsp;&nbsp;';
                                                            } else {
                                                                echo form_radio('status', '0', FALSE) . '&nbsp; InActive &nbsp;&nbsp;';
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 text-right mt-20">
                                                        <?php
                                                        $attributes = array(
                                                            'class' => 'btn btn-primary btn-sm'
                                                        );
                                                        echo form_submit('update', 'Update', $attributes);
                                                        ?>
                                                        <a href='<?= base_url() . 'users/index'; ?>' class="btn btn-warning">Cancel</a>
                                                    </div>
                                                <?= form_close();?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>