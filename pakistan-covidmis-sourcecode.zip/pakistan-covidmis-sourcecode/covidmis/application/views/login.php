<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <title>CodeIgniter3_CRUD!</title>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css';?>">
    </head>
    <body style="background-color: lightgreen;">
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4">
                  <h3 class="text-center mt-5">Login Form</h3>
                  <form method="POST" action="<?= base_url().'welcome/login';?>">
                    <div class="form-group mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" value="<?php echo set_value('email');?>" aria-describedby="emailHelp">
                        <div class="form-text"><?php echo form_error('email');?></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" value="<?php echo set_value('password');?>">
                        <div class="form-text"><?php echo form_error('password');?></div>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
                </div>
            </div>
        </div>
    </body>
</html>