                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'ventilators/create';?>"><i class="fa fa-plus"></i> Add New</a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5><?= $page_title;?></h5>
                                                </div>
                                            </div>
                                            <div class="panel-body p-20" style="overflow: auto;">
                                                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 10%; text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>District</th>
                                                            <th>Available Ventilators</th>
                                                            <th>Ventilators allocated for COVID</th>
                                                            <th>Ventilators currently Occupied (by COVID patients)</th>
                                                            <th>Currently vacant Ventilators</th>
                                                            <th>Vacant NON COVID Ventilators</th>
                                                            <th style="width: 8%; text-align: center;">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tfoot>
                                                        <tr>
                                                            <th style="text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>District</th>
                                                            <th>Available Ventilators</th>
                                                            <th>Ventilators allocated for COVID</th>
                                                            <th>Ventilators currently Occupied (by COVID patients)</th>
                                                            <th>Currently vacant Ventilators</th>
                                                            <th>Vacant NON COVID Ventilators</th>
                                                            <th style="text-align: center;">Action</th>
                                                        </tr>
                                                    </tfoot>
                                                    <tbody>
                                                    <?php if(!empty($ventilators[0]['id'])):?>
                                                        <?php $loop = 0;?>
                                                        <?php foreach($ventilators as $ventilator):?>
                                                            <tr>
                                                                <td style="text-align: center;"><?= ++$loop;?></td>
                                                                <td><?= date('d F, Y', strtotime($ventilator['date']));?></td>
                                                                <td><?= $ventilator['province_name'];?></td>
                                                                <td><?= $ventilator['district_name'];?></td>
                                                                <td><?= $ventilator['available_ventilators'];?></td>
                                                                <td><?= $ventilator['ventilators_allocated_for_covid'];?></td>
                                                                <td><?= $ventilator['ventilators_occupied_by_covid_patients'];?></td>
                                                                <td><?= $ventilator['currently_vacant_ventilators'];?></td>
                                                                <td><?= $ventilator['vacant_non_covid_vents'];?></td>
                                                                <td style="text-align: center;">
                                                                    <a href="<?= base_url().'ventilators/edit/'.$ventilator['id'];?>">
                                                                        <i class="fa fa-edit"></i>
                                                                    </a> &nbsp;&nbsp;
                                                                    <a href="<?= base_url().'ventilators/delete/'.$ventilator['id'];?>">
                                                                        <i class="fa fa-trash"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->