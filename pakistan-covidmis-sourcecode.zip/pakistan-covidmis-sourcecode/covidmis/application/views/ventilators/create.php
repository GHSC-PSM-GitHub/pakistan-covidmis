                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
            							<li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
            							<li class="active"><?= $page_title;?></li>
            						</ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'ventilators/index';?>">
                                        <i class="fa fa-arrow-left"></i> Back
                                    </a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <!-- <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Two Column Form</h5>
                                                </div>
                                            </div> -->
                                            <div class="panel-body">
                                                <h5 class="underline mt-n"><?= $page_title;?></h5>
                                                <form method="POST" action="<?= base_url().'ventilators/create';?>">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="date">Date</label>
                                                                <div class='input-group datepicker' id='datepicker'>
                                                                    <input type='text' class="form-control" name="date" id="date" placeholder="Select Date" />
                                                                    <span class="input-group-addon">
                                                                        <span class="glyphicon glyphicon-calendar">
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="province_id">Province</label>
                                                                <select class="select2 form-control" id="province_id" name="province_id">
                                                                    <option value="">Select</option>
                                                                <?php if(!empty($provinces[0]['pk_id'])):?>
                                                                    <?php foreach($provinces as $province):?>
                                                                        <option value="<?= $province['pk_id'];?>"><?= $province['location_name'];?></option>
                                                                    <?php endforeach;?>
                                                                <?php endif;?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="district_id">District</label>
                                                                <select class="select2 form-control" id="district_id" name="district_id">
                                                                    <?php if(!empty($districts[0]['pk_id'])):?>
                                                                    <?php foreach($districts as $district):?>
                                                                    <?php // echo $district['location_name'];exit;?>
                                                                        <option value="<?= $district['pk_id'];?>"><?= $district['location_name'];?></option>
                                                                    <?php endforeach;?>
                                                                <?php endif;?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="available_ventilators">Available Ventilators</label>
                                                                <input type="text" class="form-control" id="available_ventilators" name="available_ventilators" placeholder="Enter Available Ventilators">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="ventilators_allocated_for_covid">Ventilators allocated for COVID</label>
                                                                <input type="text" class="form-control" id="ventilators_allocated_for_covid" name="ventilators_allocated_for_covid" placeholder="Enter Ventilators allocated for COVID">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="ventilators_occupied_by_covid_patients">Ventilators currently Occupied (by COVID patients)</label>
                                                                <input type="text" class="form-control" id="ventilators_occupied_by_covid_patients" name="ventilators_occupied_by_covid_patients" placeholder="Enter Ventilators currently Occupied (by COVID patients)">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="currently_vacant_ventilators">Currently vacant Ventilators</label>
                                                                <input type="text" class="form-control" id="currently_vacant_ventilators" name="currently_vacant_ventilators" placeholder="Enter Currently vacant Ventilators">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="vacant_non_covid_vents">Vacant NON COVID Ventilators</label>
                                                                <input type="text" class="form-control" id="vacant_non_covid_vents" name="vacant_non_covid_vents" placeholder="Enter Vacant NON COVID Ventilators">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 text-right">
                                                            <button type="submit" class="btn btn-primary">Save</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                                <!-- /.row -->
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->