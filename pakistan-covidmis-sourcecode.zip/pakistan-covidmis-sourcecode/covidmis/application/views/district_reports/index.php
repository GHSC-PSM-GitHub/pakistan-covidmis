                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <!--<a href="<?php //echo base_url().'situations/create';?>"><i class="fa fa-plus"></i> Add New</a>-->
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->
                        <!-- FILTERS SECTION -->
                        <section class="section" style="padding-bottom: 0px">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <!-- <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Two Column Form</h5>
                                                </div>
                                            </div> -->
                                            <div class="panel-body">
                                                <h5 class="underline mt-n">Search Filters</h5>
                                                <form method="POST" action="">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="date">Date</label>
                                                                <div class='input-group datepicker' id='datepicker'>
                                                                    <input type='text' class="form-control" name="date" id="date" placeholder="Select Date" value="<?= !empty($date)?date('m/d/Y', strtotime($date)):'';?>" />
                                                                    <span class="input-group-addon">
                                                                        <span class="glyphicon glyphicon-calendar">
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 text-right">
                                                            <button type="submit" class="btn btn-primary">Go</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                                <!-- /.row -->
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- ./FILTERS SECTION -->

                        <section class="section" style="padding-top: 0px">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5><?= $page_title;?></h5>
                                                </div>
                                            </div>
                                            <div class="panel-body p-20" style="overflow: auto;">
                                                <table class="display table table-striped table-bordered" cellspacing="0" width="100%" id="example">
                                                    <thead>
                                                        <tr>
                                                            <th colspan="4"></th>
                                                            <th colspan="6" style="text-align: center;">VENTS (Table 2B)</th>
                                                            <th colspan="7" style="text-align: center;">Oxygen (Table 2C)</th>
                                                            <th colspan="11" style="text-align: center;">Situations (Table 4)</th>
                                                        </tr>
                                                        <tr>
                                                            <th colspan="17"></th>
                                                            <th colspan="9" style="text-align: center;">Current Status of All Confirmed / Active Patients in Respective District</th>
                                                            <th colspan="2" style="text-align: center;">Deaths due to COVID</th>
                                                        </tr>
                                                        <tr>
                                                            <th colspan="10"></th>
                                                            <th colspan="7" style="text-align: center;">Occupancy of Beds with Oxygen Facility allocated for COVID</th>
                                                            <th colspan="11" style="text-align: center;">Critical Patients</th>
                                                        </tr>
                                                        <tr>
                                                            <th style="width: 10%; text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>District</th>
                                                            <th>Vent Total Number of Ventilators Available</th>
                                                            <th>Vent Number of Ventilators allocated for COVID</th>
                                                            <th>Vent Number of the allocated COVID Ventilators currently Occupied (by COVID patients)</th>
                                                            <th>Vent No of the allocated COVID Ventilators currently vacant</th>
                                                            <th>Vent % occupancy of COVID Ventilators</th>
                                                            <th>Vent Number of vacant non COVID vents (for potential use in case required)</th>
                                                            <th>Oxygen No. of Beds with Oxygen Facility Available</th>
                                                            <th>Oxygen No. of Beds with Oxygen Facility allocated for COVID</th>
                                                            <th>Oxygen No. of the allocated Beds with Oxygen Facility currently Occupied (by COVID patients)</th>
                                                            <th>Oxygen % occupancy of Beds with Oxygen Facility allocated for COVID</th>
                                                            <th>Oxygen Patients on Low Flow Oxygen</th>
                                                            <th>Oxygen Patients on High Flow Oxygen</th>
                                                            <th>Oxygen Number of the allocated Beds with Oxygen Facility currently vacant</th>
                                                            <th>Situation Covid-19 Lab Tests in Last 24 hours</th>
                                                            <th>Situation COVID-19 Lab. Confirmed Cases in Last 24 hours</th>
                                                            <th>Positivity %</th>
                                                            <th>Situation In Quarantine / Isolation at Home or Elsewhere</th>
                                                            <th>Situation Admitted In Hospital</th>
                                                            <th>Situation Clinically Stable</th>
                                                            <th>Situation On Low Flow Oxygen</th>
                                                            <th>Situation On High Flow Oxygen</th>
                                                            <th>Situation on Ventilator</th>
                                                            <th>Situation New Patients Admitted in Hospital in last 24 Hour</th>
                                                            <th>Situation Last 24 hours</th>
                                                            <th>Situation Cumulative</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php if(!empty($final_data[0]['id'])):?>
                                                        <?php $loop = 0;?>
                                                        <?php foreach($final_data as $data):?>
                                                            <tr>
                                                                <td style="text-align: center;"><?= ++$loop;?></td>
                                                                <td><?= date('d F, Y', strtotime($data['date']));?></td>
                                                                <td><?= $data['province_name'];?></td>
                                                                <td><?= $data['district_name'];?></td>
                                                                <td><?= $data['available_ventilators'];?></td>
                                                                <td><?= $data['ventilators_allocated_for_covid'];?></td>
                                                                <td><?= $data['ventilators_occupied_by_covid_patients'];?></td>
                                                                <td><?= $data['currently_vacant_ventilators'];?></td>
                                                                <td><?= ($data['ventilators_occupied_by_covid_patients'] != 0)?number_format((($data['ventilators_occupied_by_covid_patients']/($data['available_ventilators']+$data['ventilators_occupied_by_covid_patients']))*100), 2).'%':'0%';?></td>
                                                                <td><?= $data['vacant_non_covid_vents'];?></td>
                                                                <td><?= $data['available_oxygen_beds'];?></td>
                                                                <td><?= $data['available_oxygen_beds_for_covid'];?></td>
                                                                <td><?= $data['oxygen_beds_occupied_by_covid_patients'];?></td>
                                                                <td><?= ($data['oxygen_beds_occupied_by_covid_patients'] != 0)?number_format((($data['oxygen_beds_occupied_by_covid_patients']/($data['available_oxygen_beds']+$data['oxygen_beds_occupied_by_covid_patients']))*100), 2).'%':'0%';?></td>
                                                                <td><?= $data['patients_on_low_oxygen'];?></td>
                                                                <td><?= $data['patients_on_high_oxygen'];?></td>
                                                                <td><?= $data['vacant_beds_with_oxygen'];?></td>
                                                                <td><?= $data['covid_test_in_last_24_hrs'];?></td>
                                                                <td><?= $data['confirm_cases_in_last_24_hrs'];?></td>
                                                                <td><?=  ($data['confirm_cases_in_last_24_hrs'] != 0)?number_format((($data['confirm_cases_in_last_24_hrs']/($data['covid_test_in_last_24_hrs']+$data['confirm_cases_in_last_24_hrs']))*100), 2).'%':'0%';?></td>
                                                                <td><?= $data['s_in_quarantine'];?></td>
                                                                <td><?= $data['s_admitted_in_hospital'];?></td>
                                                                <td><?= $data['s_clinically_stable'];?></td>
                                                                <td><?= $data['s_on_low_flow_oxygen'];?></td>
                                                                <td><?= $data['s_on_high_flow_oxygen'];?></td>
                                                                <td><?= $data['s_on_ventilator'];?></td>
                                                                <td><?= $data['s_of_new_patients_admitted_in_hospital'];?></td>
                                                                <td><?= $data['s_in_last_24_hrs'];?></td>
                                                                <td><?= $data['cumulative'];?></td>
                                                            </tr>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->