                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'oxygen/index';?>">
                                        <i class="fa fa-arrow-left"></i> Back
                                    </a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <!-- <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Two Column Form</h5>
                                                </div>
                                            </div> -->
                                            <div class="panel-body">
                                                <h5 class="underline mt-n"><?= $page_title;?></h5>
                                                <form method="POST" action="<?= base_url().'oxygen/edit/'.$oxygen[0]['id'];?>">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="date">Date</label>
                                                                <div class='input-group datepicker' id='datepicker'>
                                                                    <input type='text' class="form-control" name="date" id="date" placeholder="Select Date" value="<?= date('m/d/Y', strtotime($oxygen[0]['date']));?>" />
                                                                    <span class="input-group-addon">
                                                                        <span class="glyphicon glyphicon-calendar">
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="province_id">Province</label>
                                                                <select class="select2 form-control" id="province_id" name="province_id">
                                                                <?php if(!empty($provinces[0]['pk_id'])):?>
                                                                    <?php foreach($provinces as $province):?>
                                                                        <?php $sel = ($province['pk_id'] == $oxygen[0]['province_id'])?'selected':'';?>
                                                                        <option value="<?= $province['pk_id'];?>" <?= $sel;?>><?= $province['location_name'];?></option>
                                                                    <?php endforeach;?>
                                                                <?php endif;?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="district_id">District</label>
                                                                <select class="select2 form-control" id="district_id" name="district_id">
                                                                <?php if(!empty($districts[0]['pk_id'])):?>
                                                                    <?php foreach($districts as $district):?>
                                                                        <?php $sel = ($district['pk_id'] == $oxygen[0]['district_id'])?'selected':'';?>
                                                                        <option value="<?= $district['pk_id'];?>" <?= $sel;?>><?= $district['location_name'];?></option>
                                                                    <?php endforeach;?>
                                                                <?php endif;?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="available_oxygen_beds">No. of Beds with Oxygen Facility Available</label>
                                                                <input type="text" class="form-control" id="available_oxygen_beds" name="available_oxygen_beds" placeholder="Enter No. of Beds with Oxygen Facility Available" value="<?= $oxygen[0]['available_oxygen_beds'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="available_oxygen_beds_for_covid">No. of Beds with Oxygen Facility allocated for COVID</label>
                                                                <input type="text" class="form-control" id="available_oxygen_beds_for_covid" name="available_oxygen_beds_for_covid" placeholder="Enter No. of Beds with Oxygen Facility allocated for COVID" value="<?= $oxygen[0]['available_oxygen_beds_for_covid'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="oxygen_beds_occupied_by_covid_patients">No. of the allocated Beds with Oxygen Facility currently Occupied (by COVID patients)</label>
                                                                <input type="text" class="form-control" id="oxygen_beds_occupied_by_covid_patients" name="oxygen_beds_occupied_by_covid_patients" placeholder="Enter No. of the allocated Beds with Oxygen Facility currently Occupied (by COVID patients)" value="<?= $oxygen[0]['oxygen_beds_occupied_by_covid_patients'];?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="patients_on_low_oxygen">Patients on Low Flow Oxygen</label>
                                                                <input type="text" class="form-control" id="patients_on_low_oxygen" name="patients_on_low_oxygen" placeholder="Enter Patients on Low Flow Oxygen" value="<?= $oxygen[0]['patients_on_low_oxygen'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="patients_on_high_oxygen">Patients on High Flow Oxygen</label>
                                                                <input type="text" class="form-control" id="patients_on_high_oxygen" name="patients_on_high_oxygen" placeholder="Enter Patients on High Flow Oxygen" value="<?= $oxygen[0]['patients_on_high_oxygen'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="vacant_beds_with_oxygen">Number of the allocated Beds with Oxygen Facility currently vacant</label>
                                                                <input type="text" class="form-control" id="vacant_beds_with_oxygen" name="vacant_beds_with_oxygen" placeholder="Enter Number of the allocated Beds with Oxygen Facility currently vacant" value="<?= $oxygen[0]['vacant_beds_with_oxygen'];?>" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 text-right">
                                                            <button type="submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                                <!-- /.row -->
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->