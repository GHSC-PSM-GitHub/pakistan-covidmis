                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'oxygen/create';?>"><i class="fa fa-plus"></i> Add New</a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5><?= $page_title;?></h5>
                                                </div>
                                            </div>
                                            <div class="panel-body p-20" style="overflow: auto;">
                                                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 10%; text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>District</th>
                                                            <th>No. of Beds with Oxygen Facility Available</th>
                                                            <th>No. of Beds with Oxygen Facility allocated for COVID</th>
                                                            <th>No. of the allocated Beds with Oxygen Facility currently Occupied (by COVID patients)</th>
                                                            <th>Patients on Low Flow Oxygen</th>
                                                            <th>Patients on High Flow Oxygen</th>
                                                            <th>Number of the allocated Beds with Oxygen Facility currently vacant</th>
                                                            <th style="text-align: center; width: 10%">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tfoot>
                                                        <tr>
                                                            <th style="text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>District</th>
                                                            <th>No. of Beds with Oxygen Facility Available</th>
                                                            <th>No. of Beds with Oxygen Facility allocated for COVID</th>
                                                            <th>No. of the allocated Beds with Oxygen Facility currently Occupied (by COVID patients)</th>
                                                            <th>Patients on Low Flow Oxygen</th>
                                                            <th>Patients on High Flow Oxygen</th>
                                                            <th>Number of the allocated Beds with Oxygen Facility currently vacant</th>
                                                            <th style="text-align: center;">Action</th>
                                                        </tr>
                                                    </tfoot>
                                                    <tbody>
                                                    <?php if(!empty($oxygens[0]['id'])):?>
                                                        <?php $loop = 0;?>
                                                        <?php foreach($oxygens as $oxygen):?>
                                                            <tr>
                                                                <td style="text-align: center;"><?= ++$loop;?></td>
                                                                <td><?= date('d F, Y', strtotime($oxygen['date']));?></td>
                                                                <td><?= $oxygen['province_name'];?></td>
                                                                <td><?= $oxygen['district_name'];?></td>
                                                                <td><?= $oxygen['available_oxygen_beds'];?></td>
                                                                <td><?= $oxygen['available_oxygen_beds_for_covid'];?></td>
                                                                <td><?= $oxygen['oxygen_beds_occupied_by_covid_patients'];?></td>
                                                                <td><?= $oxygen['patients_on_low_oxygen'];?></td>
                                                                <td><?= $oxygen['patients_on_high_oxygen'];?></td>
                                                                <td><?= $oxygen['vacant_beds_with_oxygen'];?></td>
                                                                <td style="text-align: center;">
                                                                    <a href="<?= base_url().'oxygen/edit/'.$oxygen['id'];?>">
                                                                        <i class="fa fa-edit"></i>
                                                                    </a> &nbsp;&nbsp;
                                                                    <a href="<?= base_url().'oxygen/delete/'.$oxygen['id'];?>">
                                                                        <i class="fa fa-trash"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->