<?php
//    echo '<pre>';
//    print_r($consumption);exit;
if (empty($from_date)) {
    $from_date = date('Y-m', strtotime('-5 month'));
}
if (empty($to_date)) {
    $to_date = date('Y-m');
}
//    ------------------ Products Array END-----------------------
//    ------------------ Province wise data START---------------------
$mw = array();
foreach ($consumption as $kk => $vall) {
    $mw[$vall['dmonth']] = $vall['consumption'];
}
$name_mw = $value_mw = '[';
if (!empty($mw)) {
    $val1 = 0;
    foreach ($mw as $k => $val) {
         $yeararray = explode("-", $k);
    $year = $yeararray[0];
    $year = str_replace('20', '', $year);
    $monthName = date('M', mktime(0, 0, 0, $yeararray[1], 10)); // March
    $monthName = $monthName.'-'.$year ; 
        $name_mw .= '"' . $monthName . '",';
        $value_mw .= $val + $val1 . ',';
        $val1 = $val + $val1;
    }
    $name_mw = substr_replace($name_mw, "", -1);
    $value_mw = substr_replace($value_mw, "", -1);
    $name_mw .= ']';
    $value_mw .= ']';
} else {
    $value_mw = '[0, 0, 0]';
    $name_mw = '["Zero", "Zero", "Zero"]';
}

//echo $name_mw;
//echo $value_mw; exit;
//    ------------------ Province GRAPH END-----------------------
?>

<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" >
                    <div class="panel-heading" style="background-color:#109184;">
                        <div class="panel-title">
                            <h6 style="color:white;" class="panel-title txt-light"><?= $page_title; ?></h6>
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                        <div class="row" >
                            <div class="col-md-12" >
                                <form method="post"  name="form1" action="../covim/consumption_pattern">


                                    <div class="col-sm-4">
                                        <div class="form-group mr-15">
                                            <label class="control-label mr-10" for="email_inline">From Month </label>
                                            <input class="form-control"  type="month" id ="from_date" name="from_date" value="<?php echo $from_date ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group mr-15">
                                            <label class="control-label mr-10" for="pwd_inline">To Month</label>
                                            <input class="form-control" type="month" id ="to_date" name="to_date" value="<?php echo $to_date ?>" >
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group mr-15">
                                            <label class="control-label mr-10" for="pwd_inline">&nbsp;</label>
                                            <input class="btn btn-success form-control"  type="submit" name="save_btn1" id="save_btn1" value="Go"> 
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-lg-8">
                                <div class="panel panel-default card-view">
                                    <div class="panel-heading">
                                        <div class="pull-left">
                                            <h2 class="panel-title txt-dark">Consumption Trend</h2>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-wrapper collapse in">
                                        <div class="panel-body">
                                            <canvas id="line-chart" height="120"></canvas>
                                        </div>
                                    </div>

                                </div>	
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->

<script>
    /*Chartjs Init*/

    $(document).ready(function () {

//xxxxxxxxxxxxxxxxxxxxx START xxxxxxxxxxxxxxxxxxxxxx

        new Chart(document.getElementById("line-chart"), {
            type: 'line',
            data: {
                labels: <?php echo $name_mw; ?>,
                datasets: [{
                        data: <?php echo $value_mw; ?>,
                        label: "",
                        borderColor: "#8e5ea2",
                        fill: true
                    }
                ]
            },
            options: {
                legend: {display: false},
                title: {
                    display: false,
                    text: ''
                }, scales: {
                    xAxes: [{
                            gridLines: {
                                display: false
                            }
                        }],
                    yAxes: [{
                            gridLines: {
                                display: true
                            },
                            ticks: {

                            },
                            legend: {display: false, position: 'top'}
                        }]
                },
                tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                }
            }
        });

//xxxxxxxxxxxxxxxxx END xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


    });
</script>
