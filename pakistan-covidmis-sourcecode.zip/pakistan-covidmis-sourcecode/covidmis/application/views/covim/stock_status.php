 <?php
//    echo '<pre>';
//    print_r($stock_on_hand);exit;
    if (empty($from_date)) {
        $from_date = date('Y-m-01', strtotime('-5 month'));
    }
// $from_date  = date('2020-06-01');
    if (empty($to_date)) {
        $to_date = date('Y-m-d');
    }

//    ------------------ Products Array START---------------------
 $product = array();
    foreach($fetched_product as $k => $val)
 {
      if ($val['item_code'] < 17) {
        $product[$val['item_code']] = $val['item_name'];
    }
}

//    ------------------ Products Array END-----------------------
//    ------------------ Province wise data START---------------------
    $cons = array();
    foreach ($consumption as $kk => $vall) {
          if ($vall['pk_id'] < 17) {
        $cons[$product[$vall['pk_id']]] = $vall['consumption'];
    }
}
   $name_cons = $value_cons = '[';
                            if (!empty($cons)) {
                                foreach ($cons as $kkk => $valll) {
                                    $name_cons .= '"' . $kkk . '",';
                                    $value_cons .= $valll . ',';
                                }
                                $name_cons = substr_replace($name_cons, "", -1);
                                $value_cons = substr_replace($value_cons, "", -1);
                                $name_cons .= ']';
                                $value_cons .= ']';
                            } else {
                                $value_cons = '[0, 0, 0]';
                                $name_cons = '["Zero", "Zero", "Zero"]';
                            }
   
//echo $name_cons;
//echo $value_cons; exit;
//    ------------------ Province GRAPH END-----------------------
    //    ------------------ Disease Trend data START---------------------
$soh = array();
  foreach ($stock_on_hand as $kav => $value) {
          if ($value['pk_id'] < 17) {
        $soh[$product[$value['pk_id']]] = $value['soh'];
    }
}
   $name_soh = $value_soh = '[';
                            if (!empty($soh)) {
                                foreach ($soh as $kavv => $valuee) {
                                    $name_soh .= '"' . $kavv . '",';
                                    $value_soh .= abs($valuee) . ',';
                                }
                                $name_soh = substr_replace($name_soh, "", -1);
                                $value_soh = substr_replace($value_soh, "", -1);
                                $name_soh .= ']';
                                $value_soh .= ']';
                            } else {
                                $value_soh = '[0, 0, 0]';
                                $name_soh = '["Zero", "Zero", "Zero"]';
                            }
//echo $name_soh;
//echo $value_soh; exit;                            
                            
//    ------------------ Disease Trend GRAPH END-----------------------
    ?>
<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" >
                    <div class="panel-heading" style="background-color:#109184;">
                        <div class="panel-title">
                            <h6 style="color:white;" class="panel-title txt-light"><?= $page_title; ?></h6>
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                      <div class="row" >
                    <div class="col-md-12" >
                        <form method="post"  name="form1" action="../covim/stock_status">


                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="email_inline">From Month </label>
                                    <input class="form-control"  type="date" id ="from_date" name="from_date" value="<?php echo $from_date ?>">
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="pwd_inline">To Month</label>
                                    <input class="form-control" type="date" id ="to_date" name="to_date" value="<?php echo $to_date ?>" >
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="pwd_inline">&nbsp;</label>
                                    <input class="btn btn-success form-control"  type="submit" name="save_btn1" id="save_btn1" value="Go"> 
                                </div>
                            </div>
                        </form>
                    </div>
                </div>


                <div class="row">

                    <div class="col-lg-12">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Stock Available</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="soh" height="100"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                   </div>
                    <div class="row">

                    <div class="col-lg-12">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Stock Consumption </h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="consumption" height="100"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                

                </div>

                <div><b>Click on the Graph for Drilldown</b></div>   

                       

                      

                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->

<script>
    /*Chartjs Init*/

  $(document).ready(function () {
        //        "use strict";


 
//                  ------------------- PIE CHART START Stock Avail--------------------
     var data1 = {
            datasets: [{
                    data: <?php echo $value_soh; ?>,
                    backgroundColor: [
                "rgba(139,195,74,1)",
                        "rgba(237, 232, 83,1)",
                        "rgba(237, 132, 90,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(245, 66, 170,1)",
                        "rgba(245, 146, 93,1)",
                        "rgba(56, 37, 184,1)",
                        "rgba(191, 115, 245,1)",
                        "rgba(222, 27, 89,1)",
                  "#ff7c43",
                  "#f95d6a",
                        "#a05195",     
                "#8251b8",
                        "#4c8ce6",
                        "#3fccc0"
                      
                    ]
                }],
            labels: <?php echo $name_soh; ?>
        };
        var pieOptions1 = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / 1000000)) + "M";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("soh");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: data1,
                        options: pieOptions1
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];

                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
                            window.open("<?php echo base_url();?>covim/soh_drill_1/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );  




        //                  ------------------- PIE CHART END --------------------


                     //             ------------------- AGE WISE CASES START --------------------
        var dataage = {
            datasets: [{
                    data: <?php echo $value_cons; ?>,
                    backgroundColor: [
                  "#ff7c43",
                  "#f95d6a",
                        "#a05195",     
                "#8251b8",
                        "#4c8ce6",
                        "#3fccc0",
                        "rgba(139,195,74,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)"
                      
                    ]
                }],
            labels: <?php echo $name_cons; ?>
        };
        var pieOptionsage = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / 1000000)) + "M";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("consumption");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: dataage,
                        options: pieOptionsage
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];

                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;
                            window.open("<?php echo base_url();?>covim/consumption_drill_1/" + label + "/" + from_date + "/" + to_date, '_blank');
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );
        //                  ------------------- AGE WISE CASES END --------------------

    });
</script>
