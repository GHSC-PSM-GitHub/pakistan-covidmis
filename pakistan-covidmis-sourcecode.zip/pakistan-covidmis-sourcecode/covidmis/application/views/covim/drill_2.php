 <?php
//    echo '<pre>';
//    print_r($consumption_drill);exit;
    ini_set('max_execution_time', '300');

//    ------------------ Products Array START---------------------


//    ------------------ Products Array END-----------------------
//    ------------------ Province wise data START---------------------
    $mw = array();
    foreach ($consumption_drill as $kk => $vall) {
     $mw[$vall['district']] = $vall['consumption'];
}
   $name_mw = $value_mw = '[';
                    if (!empty($mw)) {
                        foreach ($mw as $k => $val) {
                            $name_mw .= '"' . $k . '",';
                            $value_mw .= $val . ',';
                        }
                        $name_mw = substr_replace($name_mw, "", -1);
                        $value_mw = substr_replace($value_mw, "", -1);
                        $name_mw .= ']';
                        $value_mw .= ']';
                    } else {
                        $value_mw = '[0, 0, 0]';
                        $name_mw = '["Zero", "Zero", "Zero"]';
                    }
   
//echo $name_cons;
//echo $value_cons; exit;
//    ------------------ Province GRAPH END-----------------------
 
    ?>

<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" >
                    <div class="panel-heading" style="background-color:#109184;">
                        <div class="panel-title">
                            <h6  style="color:white;" class="panel-title txt-light">District Wise Consumption (<?php echo $item_name;?>)</h6>
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                  <div class="row" >
                    <div class="col-md-12" >
                         <input type="hidden" name="from_date" id="from_date" value="<?php echo $from_date; ?> ">
                    <input type="hidden" name="to_date" id="to_date" value="<?php echo $to_date; ?> ">
                    <input type="hidden" name="item_code" id="item_code" value="<?php echo $item_code; ?> ">
                    </div>
                </div>


                <div class="row">

                    <div class="col-lg-12">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Consumption</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="myChart1" height="350"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                   </div>      

                       

                      

                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->

<script>
    /*Chartjs Init*/

 
    $(document).ready(function () {
        //        "use strict";

        var ctx = document.getElementById("myChart1").getContext("2d");

        var config = {
            type: 'bar',
            data: {
                labels: <?php echo $name_mw; ?>,
                datasets: [{
                        label: "Consumption",
                        type: "bar",
                        backgroundColor: [
                              "rgba(139,195,74,1)",
                            "rgba(237, 232, 83,1)",
                            "rgba(237, 132, 90,1)",
                            "rgba(33,150,243,1)",
                            "rgba(247, 184, 35,1)",
                            "rgba(250, 85, 192,1)",
                            "rgba(245, 146, 93,1)",
                            "rgba(56, 37, 184,1)",
                            "rgba(222, 108, 27,1)",
                            "rgba(222, 27, 89,1)",
                            "rgba(73, 133, 230,1)",
                            "rgba(204, 88, 150,1)",
                            "rgba(232, 214, 56,1)",
                            "rgba(240, 156, 53,1)",
                            "rgba(240, 53, 109,1)",
                            "rgba(40, 29, 245,1)",
                            "rgba(237, 66, 66,1)",
                            "rgba(252, 242, 48,1)",
                            "rgba(48, 252, 235,1)",
                            "rgba(160, 48, 252,1)",
                            "rgba(123, 230, 57,1)"

                        ],
                        data: <?php echo $value_mw; ?>}
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 1,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent
            }
        }; // end of var config

        function chartClickEvent(event, array)
        {
            if (myLiveChart === undefined || myLiveChart == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }

            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];

            var label = chartData.labels[idx];
//            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            var item_code = document.getElementById("item_code").value;

            console.log(url);

            alert(series + ':' + label + ':' + value);
        }

        var myLiveChart = new Chart(ctx, config);



    });
</script>
