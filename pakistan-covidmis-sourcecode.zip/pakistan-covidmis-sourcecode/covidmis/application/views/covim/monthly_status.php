    <?php
//    echo '<pre>';
//    print_r($monthly_wastage);exit;
    if (empty($from_date)) {
        $from_date = date('Y-m', strtotime('-5 month'));
    }
// $from_date  = date('2020-06-01');
    if (empty($to_date)) {
        $to_date = date('Y-m');
    }

//    ------------------ Province wise data START---------------------
    $mw = array();
    foreach ($consumption as $kk => $vall) {
         $mw[$vall['dmonth']] = $vall['consumption'];
}
   $name_cons = $value_cons = '[';
                            if (!empty($mw)) {
                                foreach ($mw as $kkk => $valll) {
                                    $name_cons .= '"' . $kkk . '",';
                                    $value_cons .= $valll . ',';
                                }
                                $name_cons = substr_replace($name_cons, "", -1);
                                $value_cons = substr_replace($value_cons, "", -1);
                                $name_cons .= ']';
                                $value_cons .= ']';
                            } else {
                                $value_cons = '[0, 0, 0]';
                                $name_cons = '["Zero", "Zero", "Zero"]';
                            }
   
//echo $name_cons;
//echo $value_cons; exit;
//    ------------------ Province GRAPH END-----------------------
    //    ------------------ Disease Trend data START---------------------
$wastage = array();
  foreach ($monthly_wastage as $kav => $value) {      
         $wastage[$value['rep_month']] = $value['wastages'];
}
     $name_wastage = $value_wastage = '[';
                            if (!empty($wastage)) {
                                foreach ($wastage as $k => $val) {
                                    $name_wastage .= '"' . $k . '",';
                                    $value_wastage .= $val . ',';
                                }
                                $name_wastage = substr_replace($name_wastage, "", -1);
                                $value_wastage = substr_replace($value_wastage, "", -1);
                                $name_wastage .= ']';
                                $value_wastage .= ']';
                            } else {
                                $value_wastage = '[0, 0, 0]';
                                $name_wastage = '["Zero", "Zero", "Zero"]';
                            } 
//    ------------------ Disease Trend GRAPH END-----------------------
    ?>

<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" >
                    <div class="panel-heading" style="background-color:#109184;">
                        <div class="panel-title">
                            <h6 style="color:white;" class="panel-title txt-light"><?= $page_title; ?></h6>
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                   <div class="row" >
                    <div class="col-md-12" >
                        <form method="post"  name="form1" action="../covim/monthly_status">


                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="email_inline">From Month </label>
                                    <input class="form-control"  type="month" id ="from_date" name="from_date" value="<?php echo $from_date ?>">
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="pwd_inline">To Month</label>
                                    <input class="form-control" type="month" id ="to_date" name="to_date" value="<?php echo $to_date ?>" >
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="pwd_inline">&nbsp;</label>
                                    <input class="btn btn-success form-control"  type="submit" name="save_btn1" id="save_btn1" value="Go"> 
                                </div>
                            </div>
                        </form>
                    </div>
                </div>


                <div class="row">

                    <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Month Wise Consumption</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="mwc" height="250"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                 

                    <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Month Wise Estimated Wastage </h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="myChart11" height="250"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                

                </div>     

                       

                      

                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->

<script>
    /*Chartjs Init*/

   $(document).ready(function () {
        //        "use strict";

       //                  ------------------- Wastage Graph START --------------------
        var ctx1 = document.getElementById("myChart11").getContext("2d");

        var config1 = {
            type: 'bar',
            data: {
                labels: <?php echo $name_wastage; ?>,
                datasets: [{
                        label: "Wastage",
                        type: "bar",
                        backgroundColor: "rgba(217, 74, 74,1)",
                        data: <?php echo $value_wastage; ?>}
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 1,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent1
            }
        }; // end of var config

        function chartClickEvent1(event, array)
        {
            if (myLiveChart1 === undefined || myLiveChart1 == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart1.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }

            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];

            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;

            //            var url = "../dashboard/drill_lvl_11/?label=" + label + "&value=" + value;
            //            window.location.href = "../dashboard/drill_lvl_11";
            //            window.open("../dashboard/drill_lvl_1", '_blank');
         
//                window.open("drill1.php/" + label + "/" + from_date + "/" + to_date, '_blank');
            
            console.log(url);

            alert(series + ':' + label + ':' + value);
        }

        var myLiveChart1 = new Chart(ctx1, config1);

        //                  ------------------- Wastage Graph END --------------------
        //                  ------------------- Month Wise Consumption Graph START --------------------

        var ctx = document.getElementById("mwc").getContext("2d");

        var config = {
            type: 'bar',
            data: {
                labels: <?php echo $name_cons; ?>,
                datasets: [{
                        label: "Consumption",
                        type: "bar",
                        backgroundColor: "rgba(139,195,74,1)",
                        data: <?php echo $value_cons; ?>}
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                   tooltips: {
      callbacks: {
          label: function(tooltipItem, data) {
              return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
      }
  },
                animation: {
                    duration: 1,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent
            }
        }; // end of var config

        function chartClickEvent(event, array)
        {
            if (myLiveChart === undefined || myLiveChart == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }

            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];

            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;

            //            var url = "../dashboard/drill_lvl_11/?label=" + label + "&value=" + value;
            //            window.location.href = "../dashboard/drill_lvl_11";
            //            window.open("../dashboard/drill_lvl_1", '_blank');
          
//                window.open("drill1.php/" + label + "/" + from_date + "/" + to_date, '_blank');
            
            console.log(url);

            alert(series + ':' + label + ':' + value);
        }

        var myLiveChart = new Chart(ctx, config);

    });
</script>
