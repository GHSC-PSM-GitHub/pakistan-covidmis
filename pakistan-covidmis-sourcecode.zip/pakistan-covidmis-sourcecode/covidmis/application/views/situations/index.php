                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'situations/create';?>"><i class="fa fa-plus"></i> Add New</a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5><?= $page_title;?></h5>
                                                </div>
                                            </div>
                                            <div class="panel-body p-20" style="overflow: auto;">
                                                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 10%; text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>District</th>
                                                            <th>Situation Covid-19 Lab Tests in Last 24 hours</th>
                                                            <th>Situation COVID-19 Lab. Confirmed Cases in Last 24 hours</th>
                                                            <th>Situation In Quarantine / Isolation at Home or Elsewhere</th>
                                                            <th>Situation Admitted In Hospital</th>
                                                            <th>Situation Clinically Stable</th>
                                                            <th>Situation On Low Flow Oxygen</th>
                                                            <th>Situation On High Flow Oxygen</th>
                                                            <th>Situation on Ventilator</th>
                                                            <th>Situation New Patients Admitted in Hospital in last 24 Hour</th>
                                                            <th>Situation Last 24 hours</th>
                                                            <th>Cumulative</th>
                                                            <th style="text-align: center; width: 10%">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tfoot>
                                                        <tr>
                                                            <th style="text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>District</th>
                                                            <th>Situation Covid-19 Lab Tests in Last 24 hours</th>
                                                            <th>Situation COVID-19 Lab. Confirmed Cases in Last 24 hours</th>
                                                            <th>Situation In Quarantine / Isolation at Home or Elsewhere</th>
                                                            <th>Situation Admitted In Hospital</th>
                                                            <th>Situation Clinically Stable</th>
                                                            <th>Situation On Low Flow Oxygen</th>
                                                            <th>Situation On High Flow Oxygen</th>
                                                            <th>Situation on Ventilator</th>
                                                            <th>Situation New Patients Admitted in Hospital in last 24 Hour</th>
                                                            <th>Situation Last 24 hours</th>
                                                            <th>Cumulative</th>
                                                            <th style="text-align: center;">Action</th>
                                                        </tr>
                                                    </tfoot>
                                                    <tbody>
                                                    <?php if(!empty($situations[0]['id'])):?>
                                                        <?php $loop = 0;?>
                                                        <?php foreach($situations as $situation):?>
                                                            <tr>
                                                                <td style="text-align: center;"><?= ++$loop;?></td>
                                                                <td><?= date('d F, Y', strtotime($situation['date']));?></td>
                                                                <td><?= $situation['province_name'];?></td>
                                                                <td><?= $situation['district_name'];?></td>
                                                                <td><?= $situation['covid_test_in_last_24_hrs'];?></td>
                                                                <td><?= $situation['confirm_cases_in_last_24_hrs'];?></td>
                                                                <td><?= $situation['s_in_quarantine'];?></td>
                                                                <td><?= $situation['s_admitted_in_hospital'];?></td>
                                                                <td><?= $situation['s_clinically_stable'];?></td>
                                                                <td><?= $situation['s_on_low_flow_oxygen'];?></td>
                                                                <td><?= $situation['s_on_high_flow_oxygen'];?></td>
                                                                <td><?= $situation['s_on_ventilator'];?></td>
                                                                <td><?= $situation['s_of_new_patients_admitted_in_hospital'];?></td>
                                                                <td><?= $situation['s_in_last_24_hrs'];?></td>
                                                                <td><?= $situation['cumulative'];?></td>
                                                                <td style="text-align: center;">
                                                                    <a href="<?= base_url().'situations/edit/'.$situation['id'];?>">
                                                                        <i class="fa fa-edit"></i>
                                                                    </a> &nbsp;&nbsp;
                                                                    <a href="<?= base_url().'situations/delete/'.$situation['id'];?>">
                                                                        <i class="fa fa-trash"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->