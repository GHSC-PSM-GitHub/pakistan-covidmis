                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
            							<li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
            							<li class="active"><?= $page_title;?></li>
            						</ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <a href="<?= base_url().'situations/index';?>">
                                        <i class="fa fa-arrow-left"></i> Back
                                    </a>
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <!-- <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Two Column Form</h5>
                                                </div>
                                            </div> -->
                                            <div class="panel-body">
                                                <h5 class="underline mt-n"><?= $page_title;?></h5>
                                                <form method="POST" action="<?= base_url().'situations/create';?>">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="date">Date</label>
                                                                <div class='input-group datepicker' id='datepicker'>
                                                                    <input type='text' class="form-control" name="date" id="date" placeholder="Select Date" />
                                                                    <span class="input-group-addon">
                                                                        <span class="glyphicon glyphicon-calendar">
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="province_id">Province</label>
                                                                <select class="select2 form-control" id="province_id" name="province_id">
                                                                    <option value="">Select</option>
                                                                <?php if(!empty($provinces[0]['pk_id'])):?>
                                                                    <?php foreach($provinces as $province):?>
                                                                        <option value="<?= $province['pk_id'];?>"><?= $province['location_name'];?></option>
                                                                    <?php endforeach;?>
                                                                <?php endif;?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="district_id">District</label>
                                                                <select class="select2 form-control" id="district_id" name="district_id">
                                                                <?php if(!empty($districtss[0]['pk_id'])):?>
                                                                    <?php foreach($districts as $district):?>
                                                                        <option value="<?= $district['pk_id'];?>"><?= $district['location_name'];?></option>
                                                                    <?php endforeach;?>
                                                                <?php endif;?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="covid_test_in_last_24_hrs">Situation Covid-19 Lab Tests in Last 24 hours</label>
                                                                <input type="text" class="form-control" id="covid_test_in_last_24_hrs" name="covid_test_in_last_24_hrs" placeholder="Enter Situation Covid-19 Lab Tests in Last 24 hours">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="confirm_cases_in_last_24_hrs">Situation COVID-19 Lab. Confirmed Cases in Last 24 hours</label>
                                                                <input type="text" class="form-control" id="confirm_cases_in_last_24_hrs" name="confirm_cases_in_last_24_hrs" placeholder="Enter Situation COVID-19 Lab. Confirmed Cases in Last 24 hours">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="s_in_quarantine">Situation In Quarantine / Isolation at Home or Elsewhere</label>
                                                                <input type="text" class="form-control" id="s_in_quarantine" name="s_in_quarantine" placeholder="Enter Situation In Quarantine / Isolation at Home or Elsewhere">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="s_admitted_in_hospital">Situation Admitted In Hospital</label>
                                                                <input type="text" class="form-control" id="s_admitted_in_hospital" name="s_admitted_in_hospital" placeholder="Enter Situation Admitted In Hospital">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="s_clinically_stable">Situation Clinically Stable</label>
                                                                <input type="text" class="form-control" id="s_clinically_stable" name="s_clinically_stable" placeholder="Enter Situation Clinically Stable">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="s_on_low_flow_oxygen">Situation On Low Flow Oxygen</label>
                                                                <input type="text" class="form-control" id="s_on_low_flow_oxygen" name="s_on_low_flow_oxygen" placeholder="Enter Situation On Low Flow Oxygen">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="s_on_high_flow_oxygen">Situation On High Flow Oxygen</label>
                                                                <input type="text" class="form-control" id="s_on_high_flow_oxygen" name="s_on_high_flow_oxygen" placeholder="Enter Situation On High Flow Oxygen">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="s_on_ventilator">Situation on Ventilator</label>
                                                                <input type="text" class="form-control" id="s_on_ventilator" name="s_on_ventilator" placeholder="Enter Situation on Ventilator">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="s_of_new_patients_admitted_in_hospital">Situation New Patients Admitted in Hospital in last 24 Hour</label>
                                                                <input type="text" class="form-control" id="s_of_new_patients_admitted_in_hospital" name="s_of_new_patients_admitted_in_hospital" placeholder="Enter Situation New Patients Admitted in Hospital in last 24 Hour">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="s_in_last_24_hrs">Situation Last 24 hours</label>
                                                                <input type="text" class="form-control" id="s_in_last_24_hrs" name="s_in_last_24_hrs" placeholder="Enter Situation Last 24 hours">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="cumulative">Cumulative</label>
                                                                <input type="text" class="form-control" id="cumulative" name="cumulative" placeholder="Enter Cumulative">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 text-right">
                                                            <button type="submit" class="btn btn-primary">Save</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                                <!-- /.row -->
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->