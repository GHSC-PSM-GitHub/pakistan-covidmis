<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <title>CodeIgniter3_CRUD!</title>
        <link rel="stylesheet" type="text/css" href="<?= base_url().'assets/css/bootstrap.min.css';?>">
    </head>
    <body style="background-color: lightgreen;">
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4">
                  <h3 class="text-center mt-5">Update User</h3>
                  <form method="POST" action="<?= base_url().'user/edit/'.$user[0]['user_id']??'';?>">
                    <div class="form-group mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= set_value('name');?><?= $user[0]['name']??'';?>" aria-describedby="emailHelp" min='3' max='11'>
                        <div class="form-text"><?= form_error('name');?></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="gender" class="form-label">Gender</label>
                        <?php
                        if (!empty($genders)) {
                            $loop = 1;
                            foreach ($genders as $gender) {
                                if ($loop == 1) {
                        ?>
                                    <input type="radio" name="gender" value="<?= $gender['gender_name'];?>" <?php if($user[0]['gender'] == $gender['gender_name']) echo 'checked';?> />&nbsp;<?= $gender['gender_name'];?>
                        <?php
                                    $loop++;
                                }else{
                        ?>
                                    <input type="radio" name="gender" <?php if($user[0]['gender'] == $gender['gender_name']) echo 'checked';?> value="<?= $gender['gender_name'];?>" />&nbsp;<?= $gender['gender_name'];?>
                        <?php
                                }
                            }
                        }
                        ?>
                        <div class="form-text"><?= form_error('gender');?></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="designation" class="form-label">Designation</label>
                        <select name="designation" class="form-control">
                            <option>Select Designation</option>
                        <?php
                        if (!empty($designations)) {
                            foreach ($designations as $designation) {
                        ?>
                            <option value="<?= $designation['designation_id']?>"  <?php if($user[0]['designation'] == $designation['designation_name']) echo 'selected';?>><?= $designation['designation_name']?></option>
                        <?php
                            }
                        }
                        ?>
                        </select>
                        <div class="form-text"><?= form_error('designation');?></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?= set_value('email');?><?= $user[0]['email']??'';?>" aria-describedby="emailHelp">
                        <div class="form-text"><?= form_error('email');?></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" value="<?= set_value('password');?>" min='3' max='8'>
                        <div class="form-text"><?= form_error('password');?></div>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href='<?= base_url().'user/index';?>' class="btn btn-secondary" style='float: right;'>Cancel</a>
                </form>
                </div>
            </div>
        </div>
    </body>
</html>