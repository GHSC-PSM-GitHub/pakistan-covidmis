       <?php
    if (empty($from_date)) {
        $from_date = date('Y-m-01', strtotime('-2 month'));
    }
// $from_date  = date('2020-06-01');
    if (empty($to_date)) {
        $to_date = date('Y-m-d');
    }

    //    ------------------ Disease wise data START---------------------
    $label_arr = '[';
    $data_arr = '[';
    $i = 0;
    foreach ($disease_wise_data as $k => $val) {
        if ($i < 10) {
            $data_arr .= $val['total'] . ",";
            $label_arr .= '"' . $val['disease_name'] . '",';
            $i++;
        }
    }
    $label_arr = substr_replace($label_arr, "", -1);
    $label_arr .= ']';
    $data_arr = substr_replace($data_arr, "", -1);
    $data_arr .= ']';

//echo $label_arr;
//echo $data_arr; exit;
//    ------------------ Disease wise data END-----------------------
   //    ------------------ Disease Trend data START------------------------------
$disease_array = $month_array = $sum_array = array();
    foreach ($disease_trend as $k => $val) {
        $disease_array[$val['disease_name']][$val['month']] = $val['sum'];
        $month_array[] = $val['month'];
    }
    $month_array = array_values(array_unique($month_array));
    $trend_month = $disease1 = $disease2 = $disease3 = $disease4 = $disease5 = '[';
    $disease1_name = $disease2_name = $disease3_name = $disease4_name = $disease5_name = '';
//       echo '<pre>';
    $limit = count($month_array);
    foreach ($month_array as $k => $months) {
        $months = date("M-y",strtotime($months));
        $trend_month .= '"' . $months . '",';
    }
    $j = 0;
    foreach ($disease_array as $dis_name => $array) {
        foreach ($month_array as $k => $mon) {
//        echo '<pre>';
//            print_r ($disease_array); exit;
            $value = $disease_array[$dis_name][$mon];
            if ($j < $limit) {
                $disease1_name = $dis_name;
                $disease1 .= $value . ',';
            } elseif ($j < (2 * $limit)) {
                $disease2_name = $dis_name;
                $disease2 .= $value . ',';
            } elseif ($j < (3 * $limit)) {
                $disease3_name = $dis_name;
                $disease3 .= $value . ',';
            } elseif ($j < (4 * $limit)) {
                $disease4_name = $dis_name;
                $disease4 .= $value . ',';
            } elseif ($j < (5 * $limit)) {
                $disease5_name = $dis_name;
                $disease5 .= $value . ',';
            }
            $j++;
        }
    }
    $disease1 = substr_replace($disease1, "", -1);
    $disease1 .= ']';
    $disease2 = substr_replace($disease2, "", -1);
    $disease2 .= ']';
    $disease3 = substr_replace($disease3, "", -1);
    $disease3 .= ']';
    $disease4 = substr_replace($disease4, "", -1);
    $disease4 .= ']';
    $disease5 = substr_replace($disease5, "", -1);
    $disease5 .= ']';
    $trend_month = substr_replace($trend_month, "", -1);
    $trend_month .= ']';
//    echo $disease5; exit;
    ?>
  <!--<------------------ Disease Trend GRAPH END------------------------->
<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" >
                    <div class="panel-heading" style="background-color:#f8b32d;">
                        <div class="panel-title">
                            <h6 style="color:white;" class="panel-title txt-light"><?php echo $label . ' Dashboard'; ?></h6>
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                     <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default card-view">
                    <div class="panel-heading">
                        <div class="pull-left">
                            <h2 class="panel-title txt-dark"> Disease Wise Patients (Top 10)</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-wrapper collapse in">
                        <div class="panel-body">
                            <canvas id="myChart1" height="480"></canvas>
                        </div>
                    </div>

                </div>	
            </div>
        </div> 
        
         <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default card-view">
                    <div class="panel-heading">
                        <div class="pull-left">
                            <h2 class="panel-title txt-dark"> Disease Trend (Top 5)</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-wrapper collapse in">
                        <div class="panel-body">
                            <canvas id="line-chart" height="120"></canvas>
                        </div>
                    </div>
                </div>	
            </div>
        </div> 
         
         <input type="hidden" name="from_date" id="from_date" value="<?php echo $from_date; ?> ">
        <input type="hidden" name="to_date" id="to_date" value="<?php echo $to_date; ?> ">
        <input type="hidden" name="label_id" id="label_id" value="<?php echo $label_id; ?> ">                

                       

                      

                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->

<script>
    /*Chartjs Init*/

    $(document).ready(function () {
        "use strict";

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx Disease Wise PAtients START xxxxxxxxxxxxxxxxxxxxxxxx
        var ctx = document.getElementById("myChart1").getContext("2d");

        var config = {
            type: 'bar',
            data: {
                labels: <?php echo $label_arr; ?>,
                datasets: [{
                        label: "Patients",
                        type: "bar",
                        backgroundColor: [
                            "rgba(62, 149, 205,1)",
                            "rgba(142, 94, 162,1)",
                            "rgba(60, 186, 159,1)",
                            "rgba(232, 195, 185,1)",
                            "rgba(196, 88, 80,1)",
                            "rgba(237, 232, 83,1)",
                            "rgba(139,195,74,1)",
                            "rgba(237, 132, 90,1)",
                            "rgba(33,150,243,1)",
                            "rgba(247, 184, 35,1)",
                            "rgba(250, 85, 192,1)"

                        ],
                        data: <?php echo $data_arr; ?>
                    }
                ]
            },
            options: {
                legend: {display: false},
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 1,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent
            }
        }; // end of var config


        var myLiveChart = new Chart(ctx, config);

        function chartClickEvent(event, array)
        {
            if (myLiveChart === undefined || myLiveChart == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }

            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];

            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            var label_id = document.getElementById("label_id").value;

//   var url = "http://example.com/?label=" + label + "&value=" + value;
//            window.open("http://localhost/drap_application_system/dashboard/list_for_assign", '_blank');
//            window.open("<?php echo base_url(); ?>dashboard/view_application/" + label + "/" + from_date + "/" + to_date + "/" + label_id, '_blank');
            console.log(url);

            alert(series + ':' + label + ':' + value);
        }
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx Disease Wise PAtients END xxxxxxxxxxxxxxxxxxxxxxxx
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxx START LINE CHART xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        new Chart(document.getElementById("line-chart"), {
            type: 'line',
            data: {
                labels: <?php echo $trend_month; ?>,
                datasets: [{
                        data: <?php echo $disease1; ?>,
                        label: "<?php echo $disease1_name;?>",
                        borderColor: "#8e5ea2",
                        fill: false
                    },
                    {
                        data: <?php echo $disease2;?>,
                        label: "<?php echo $disease2_name;?>",
                        borderColor: "#42f59b",
                        fill: false
                    },
                    {
                        data: <?php echo $disease3;?>,
                        label: "<?php echo $disease3_name;?>",
                        borderColor: "#f5bf42",
                        fill: false
                    },
                            {
                        data: <?php echo $disease4;?>,
                        label: "<?php echo $disease4_name;?>",
                        borderColor: "#f58d42",
                        fill: false
                    },
                            {
                        data: <?php echo $disease5;?>,
                        label: "<?php echo $disease5_name;?>",
                        borderColor: "#f5429e",
                        fill: false
                    }
                ]
            },
            options: {
                legend: {display: true},
                title: {
                    display: false,
                    text: ''
                }, scales: {
                    xAxes: [{
                            gridLines: {
                                display: false
                            }
                        }],
                    yAxes: [{
                            gridLines: {
                                display: true
                            },
                            ticks: {

                            },
                            legend: {display: true, position: 'top'}
                        }]
                }
            }
        });

//xxxxxxxxxxxxxxxxx END xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx



    });


</script>                