<body>
    <?php
//    echo '<pre>';
//    print_r($disease_trend);exit;
    if (empty($from_date)) {
        $from_date = date('Y-m', strtotime('-5 month'));
    }
// $from_date  = date('2020-06-01');
    if (empty($to_date)) {
        $to_date = date('Y-m');
    }

//    ------------------ Disease wise data START---------------------
    $label_arr = '[';
    $data_arr = '[';
    $i = 0;
    foreach ($disease_wise_data as $k => $val) {
        if ($i < 10) {
            $data_arr .= $val['total'] . ",";
            $label_arr .= '"' . $val['disease_name'] . '",';
            $i++;
        }
    }
    $label_arr = substr_replace($label_arr, "", -1);
    $label_arr .= ']';
    $data_arr = substr_replace($data_arr, "", -1);
    $data_arr .= ']';

//echo $label_arr;
//echo $data_arr; exit;
//    ------------------ Disease wise data END-----------------------
//    ------------------ Province wise data START---------------------
    $province_label = '[';
    $province_data = '[';
    foreach ($province_wise_data as $k => $val) {
        $province_data .= $val['total'] . ",";
        $province_label .= '"' . $val['location'] . '",';
    }
    $province_label = substr_replace($province_label, "", -1);
    $province_label .= ']';
    $province_data = substr_replace($province_data, "", -1);
    $province_data .= ']';

//echo $province_label;
//echo $province_data; exit;
//    ------------------ Province GRAPH END-----------------------
    //    ------------------ Disease Trend data START---------------------
    $disease_array = $month_array = $sum_array = array();
    foreach ($disease_trend as $k => $val) {
        $disease_array[$val['disease_name']][$val['month']] = $val['sum'];
        $month_array[] = $val['month'];
    }
    $month_array = array_values(array_unique($month_array));
    $trend_month = $disease1 = $disease2 = $disease3 = $disease4 = $disease5 = '[';
    $disease1_name = $disease2_name = $disease3_name = $disease4_name = $disease5_name = '';
//       echo '<pre>';
    $limit = count($month_array);
    foreach ($month_array as $k => $months) {
        $months = date("M-y",strtotime($months));
        $trend_month .= '"' . $months . '",';
    }
    $j = 0;
    foreach ($disease_array as $dis_name => $array) {
        foreach ($month_array as $k => $mon) {
//        echo '<pre>';
//            print_r ($disease_array); exit;
            $value = $disease_array[$dis_name][$mon];
            if ($j < $limit) {
                $disease1_name = $dis_name;
                $disease1 .= $value . ',';
            } elseif ($j < (2 * $limit)) {
                $disease2_name = $dis_name;
                $disease2 .= $value . ',';
            } elseif ($j < (3 * $limit)) {
                $disease3_name = $dis_name;
                $disease3 .= $value . ',';
            } elseif ($j < (4 * $limit)) {
                $disease4_name = $dis_name;
                $disease4 .= $value . ',';
            } elseif ($j < (5 * $limit)) {
                $disease5_name = $dis_name;
                $disease5 .= $value . ',';
            }
            $j++;
        }
    }
    $disease1 = substr_replace($disease1, "", -1);
    $disease1 .= ']';
    $disease2 = substr_replace($disease2, "", -1);
    $disease2 .= ']';
    $disease3 = substr_replace($disease3, "", -1);
    $disease3 .= ']';
    $disease4 = substr_replace($disease4, "", -1);
    $disease4 .= ']';
    $disease5 = substr_replace($disease5, "", -1);
    $disease5 .= ']';
    $trend_month = substr_replace($trend_month, "", -1);
    $trend_month .= ']';
//    echo $disease5; exit;
//    ------------------ Disease Trend GRAPH END-----------------------
    ?>

    <!--Preloader-->
    <div class="preloader-it">
        <div class="la-anim-1"></div>
    </div>
    <!--/Preloader-->

    <div class="container">
        <div class="panel panel-primary card-view">
            <div class="panel-heading" style="background-color:#f8b32d;">
                <div class="pull-left">
                    <h6 style="color:white;" class="panel-title txt-light">Infectious Diseases Dashboard</h6>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="panel-body">
                <div class="row" >
                    <div class="col-md-12" >
                        <form method="post"  name="form1" action="../dashboard/index">


                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="email_inline">From Month </label>
                                    <input class="form-control"  type="month" id ="from_date" name="from_date" value="<?php echo $from_date ?>">
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="pwd_inline">To Month</label>
                                    <input class="form-control" type="month" id ="to_date" name="to_date" value="<?php echo $to_date ?>" >
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group mr-15">
                                    <label class="control-label mr-10" for="pwd_inline">&nbsp;</label>
                                    <input class="btn btn-success form-control"  type="submit" name="save_btn1" id="save_btn1" value="Go"> 
                                </div>
                            </div>
                        </form>
                    </div>
                </div>


                <div class="row">

                    <div class="col-lg-12">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Disease Wise Patients (Top 5)</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="myChart1" height="430"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
</div> 
                <div class="row">
                    <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Province Wise Patients </h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="province" height="320"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                

                    <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Diseases Trend (Top 5)</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="line-chart" height="180"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                  
                </div>

                <div><b>Click on the Graph for Drilldown</b></div>
            </div>
        </div>
    </div>


    <script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>

</body>
<script>
    /*Chartjs Init*/

    $(document).ready(function () {
        //        "use strict";

        //                  ------------------- PIE CHART START --------------------
        var data = {
            datasets: [{
                    data: <?php echo $province_data; ?>,
                    backgroundColor: [
                        "#8251b8",
                        "#4c8ce6",
                        "#3fccc0",
                        "rgba(139,195,74,1)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)",
                        "rgba(245, 146, 93,1)",
                        "rgba(56, 37, 184,1)",
                        "rgba(222, 108, 27,1)"
                    ]
                }],
            labels: <?php echo $province_label; ?>
        };
        var pieOptions = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale: true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                    total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                                    mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                                    start_angle = model.startAngle,
                                    end_angle = model.endAngle,
                                    mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
                function () {
                    var canvas = document.getElementById("myChart");
                    var ctx = canvas.getContext("2d");
                    var myNewChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: data,
                        options: pieOptions
                    });

                    canvas.onclick = function (evt) {
                        var activePoints = myNewChart.getElementsAtEvent(evt);
                        if (activePoints[0]) {
                            var chartData = activePoints[0]['_chart'].config.data;
                            var idx = activePoints[0]['_index'];

                            var label = chartData.labels[idx];
                            var value = chartData.datasets[0].data[idx];
                            var from_date = document.getElementById("from_date").value;
                            var to_date = document.getElementById("to_date").value;

                            //                            var url = "http://example.com/?label=" + label + "&value=" + value;
                            if (label != 'Submitted ( unassigned )') {
                                window.open("<?php echo base_url();?>dashboard/drill_lvl_1/" + label + "/" + from_date + "/" + to_date, '_blank');
                            } else {
                                window.open("../dashboard/total_submitted/Submitted/" + from_date + "/" + to_date, '_blank');
                            }
                            console.log(url);
                            alert(url);
                        }
                    };
                }
        );

        //                  ------------------- PIE CHART END --------------------
   var ctx1 = document.getElementById("myChart1").getContext("2d");

        var config1 = {
            type: 'bar',
            data: {
                labels: <?php echo $label_arr; ?>,
                datasets: [{
                        label: "Patients",
                        type: "bar",
                        backgroundColor: [
                            "#f0d159",
                            "#d3da66",
                            "#b5e17a",
                            "#99e692",
                            "#7ee9ac",
                            "#c4cb6e",
                            "#f0a668",
                            '#f78590',
                            "#59e8f0",
                            '#97e97e'
                        ],
                        data: <?php echo $data_arr; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent1
            }
        }; // end of var config

        function chartClickEvent1(event, array)
        {
            if (myLiveChart1 === undefined || myLiveChart1 == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart1.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }

            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];

            var label = chartData.labels[idx];
//            var label1 =  encodeURI(label);
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;

//                        var url = "../dashboard/disease_drill/?label=" + label + "&from_date=" + from_date;
            //            window.location.href = "../dashboard/drill_lvl_11";
                        window.open("<?php echo base_url();?>dashboard/disease_drill/?label=" + label + "&from_date=" + from_date + "&to_date=" + to_date, '_blank');
           
//                window.open("../dashboard/disease_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
           
            console.log(url);

            alert(series + ':' + label + ':' + value);
        }

        var myLiveChart1 = new Chart(ctx1, config1);
// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Province Chart Start (Bar Chart) xxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctx = document.getElementById("province").getContext("2d");

        var config = {
            type: 'bar',
            data: {
                labels: <?php echo $province_label; ?>,
                datasets: [{
                        label: "Patients",
                        type: "bar",
                        backgroundColor: [
                            "#8251b8",
                            "#4c8ce6",
                            "#3fccc0",
                            "#99e692",
                            "#7ee9ac",
                            "#66eac6",
                            "#57eadd",
                            "#59e8f0"
                        ],
                        data: <?php echo $province_data; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                                ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent
            }
        }; // end of var config

        function chartClickEvent(event, array)
        {
            if (myLiveChart === undefined || myLiveChart == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            window.open("<?php echo base_url();?>dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChart = new Chart(ctx, config);

//xxxxxxxxxxxxxxxxxxxxx START xxxxxxxxxxxxxxxxxxxxxx

        new Chart(document.getElementById("line-chart"), {
            type: 'line',
            data: {
                labels: <?php echo $trend_month; ?>,
                datasets: [{
                        data: <?php echo $disease1; ?>,
                        label: "<?php echo $disease1_name;?>",
                        borderColor: "#8e5ea2",
                        fill: false
                    },
                    {
                        data: <?php echo $disease2;?>,
                        label: "<?php echo $disease2_name;?>",
                        borderColor: "#42f59b",
                        fill: false
                    },
                    {
                        data: <?php echo $disease3;?>,
                        label: "<?php echo $disease3_name;?>",
                        borderColor: "#f5bf42",
                        fill: false
                    },
                            {
                        data: <?php echo $disease4;?>,
                        label: "<?php echo $disease4_name;?>",
                        borderColor: "#f58d42",
                        fill: false
                    },
                            {
                        data: <?php echo $disease5;?>,
                        label: "<?php echo $disease5_name;?>",
                        borderColor: "#f5429e",
                        fill: false
                    }
                ]
            },
            options: {
                legend: {display: true},
                title: {
                    display: false,
                    text: ''
                }, scales: {
                    xAxes: [{
                            gridLines: {
                                display: false
                            }
                        }],
                    yAxes: [{
                            gridLines: {
                                display: true
                            },
                            ticks: {

                            },
                            legend: {display: true, position: 'top'}
                        }]
                }
            }
        });

//xxxxxxxxxxxxxxxxx END xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
  

    });
</script>
</html>
