                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title"><?= $page_title;?></h2>
                                    <!-- <p class="sub-title">One stop solution for perfect admin dashboard!</p> -->
                                </div>
                                <!-- /.col-md-6 -->
                                <!-- <div class="col-md-6 right-side">
                                    <a class="btn bg-black toggle-code-handle" role="button">Toggle Code!</a>
                                </div> -->
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li>
                                            <a href="<?= base_url().'dashboard/index';?>">
                                                <i class="fa fa-dashboard"></i> Dashboard
                                            </a>
                                        </li>
                                        <li class="active"><?= $page_title;?></li>
                                    </ul>
                                </div>
                                <!-- /.col-md-6 -->
                                <div class="col-md-6 text-right">
                                    <!--<a href="<?php //echo base_url().'datas/create';?>"><i class="fa fa-plus"></i> Add New</a>-->
                                    <!-- <a href="#" class="pl-20"><i class="fa fa-cog"></i> Settings</a> -->
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5><?= $page_title;?></h5>
                                                </div>
                                            </div>
                                            <div class="panel-body p-20" style="overflow: auto;">
                                                <table class="display table table-striped table-bordered" cellspacing="0" width="100%" id="example">
                                                    <thead>
                                                        <tr>
                                                            <th colspan="3"></th>
                                                            <th colspan="9" style="text-align: center;">Tests & Cases</th>
                                                            <th colspan="9" style="text-align: center;">Cases (Table 1B)</th>
                                                            <th colspan="11" style="text-align: center;">Death and Suspectes (Table 1C)</th>
                                                            <th colspan="14" style="text-align: center;">CLINICAL STATUS (Table 2A)</th>
                                                            <th colspan="10" style="text-align: center;">HCP (Table 3A)</th>
                                                            <th colspan="9" style="text-align: center;">HCP Details (Table 3B)</th>
                                                        </tr>
                                                        <tr>
                                                            <th colspan="3"></th>
                                                            <th colspan="3" style="text-align: center;">PCR Tests</th>
                                                            <th colspan="3" style="text-align: center;">Rapid Antigen Tests</th>
                                                            <th colspan="3" style="text-align: center;">Total Tests (PCR + Rapid Antigen Tests)</th>
                                                            <th colspan="3" style="text-align: center;">Cases from PCR Testing</th>
                                                            <th colspan="3" style="text-align: center;">Cases from Antigen Testing</th>
                                                            <th colspan="3" style="text-align: center;">Total COVID Cases (from PCR + Antigen Testing)</th>
                                                            <th colspan="3" style="text-align: center;">Deaths Due to COVID-19</th>
                                                            <th colspan="3" style="text-align: center;">Number Among Deaths in last 24 hours</th>
                                                            <th style="text-align: center;">Till 31 Mar(8:00 PM)</th>
                                                            <th colspan="4" style="text-align: center;">Suspected Cases in Last 24 Hour (with Breakup)</th>
                                                            <th colspan="14" style="text-align: center;">Hospitalized</th>
                                                            <th colspan="4" style="text-align: center;">Confirmed Cases Among Healthcare Workers (HCWs)</th>
                                                            <th colspan="6" style="text-align: center;">Status of Confirmed Cases of Healthcare Workers</th>
                                                            <th style="text-align: center;"></th>
                                                            <th colspan="2" style="text-align: center;">Out of Total Confirmed Cases Among Health Care Workers</th>
                                                            <th colspan="6" style="text-align: center;">Contacts of Healthcare Workers</th>
                                                        </tr>
                                                        <tr>
                                                            <th style="width: 10%; text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>Test Till Yesterday (8:00 PM)</th>
                                                            <th>Test Last 24 Hours</th>
                                                            <th>Test Total Tests Conducted till date</th>
                                                            <th>Rapid Till Yesterday (8:00 PM)</th>
                                                            <th>Rapid Last 24 Hours</th>
                                                            <th>Rapid Total Tests Conducted till date</th>
                                                            <th>Grand Total Tests Till Yesterday (8:00 PM)</th>
                                                            <th>Grand Total Tests In Last 24 Hours</th>
                                                            <th>Grand Total Tests Conducted till date</th>
                                                            <th>PCases Till Yesterday(8:00 PM)</th>
                                                            <th>PCases Last 24 hours</th>
                                                            <th>PCases Cumulative</th>
                                                            <th>ACases Till Yesterday(8:00 PM)</th>
                                                            <th>Acases Last 24 hours</th>
                                                            <th>Acases Cumulative</th>
                                                            <th>Grand Total Cases Till Yesterday (8:00 PM)</th>
                                                            <th>Grand Total Cases in Last 24 hours</th>
                                                            <th>Grand Total Cases till date</th>
                                                            <th>Death till Yesterday (8:00 PM)</th>
                                                            <th>Death Last 24 hours</th>
                                                            <th>Death Cumulative / Total Deaths</th>
                                                            <th>Died in Hospital On Ventilator</th>
                                                            <th>Died in Hospital Off Ventilator</th>
                                                            <th>Died at Home or Elsewhere</th>
                                                            <th>Suspect Till Yesterday(8:00 PM)</th>
                                                            <th>Suspect Contacts of Known COVID Pts</th>
                                                            <th>Suspect Others suspected</th>
                                                            <th>Suspect Total Suspects in last 24 hrs</th>
                                                            <th>Suspect Cumulative suspects</th>
                                                            <th>Clinic Total No. Of Hospitals with COVID Isolations / Case Mgt Facilities</th>
                                                            <th>Clinic Total No. Of Beds Allocated for COVID Patients</th>
                                                            <th>Clinic Total No. of Beds with Oxygen Facility allocated for COVID Patients</th>
                                                            <th>Clinic Total No. Of Ventilators allocated for COVID Patients</th>
                                                            <th>Clinic Patients Admitted in last 24 Hours</th>
                                                            <th>Clinic Total No. Of COVID Patients currently Admitted</th>
                                                            <th>Clinic Total No of Patients Clinically Stable</th>
                                                            <th>Clinic On Low Flow Oxygen</th>
                                                            <th>Clinic On High Flow Oxygen</th>
                                                            <th>Clinic Total (on Oxygen)</th>
                                                            <th>Clinic Total No. of Patients currently on Ventilator</th>
                                                            <th>Clinic Total No of Patients in Quarantine at Home or Elsewhere</th>
                                                            <th>Clinic Total Numbers Recovered and Discharged so far</th>
                                                            <th>Clinic Total Deaths till date</th>
                                                            <th>HCP Doctors (1)</th>
                                                            <th>HCP Nurses (2)</th>
                                                            <th>HCP Other Health Staff (3)</th>
                                                            <th>HCP Total HCWs infected till date (1+2+3)</th>
                                                            <th>HCP In Isolation (Home / Others)</th>
                                                            <th>HCP In Hospital</th>
                                                            <th>HCP Stable</th>
                                                            <th>HCP On Ventilator</th>
                                                            <th>HCP RecoveredAnd /OrDischarged</th>
                                                            <th>HCP Died</th>
                                                            <th>HCPDet Total Confirmed Cases Among Health Care Workers</th>
                                                            <th>HCPDet Number Performing Duties in Critical Care</th>
                                                            <th>HCPDet Number Performing Duties Elsewhere</th>
                                                            <th>HCPDet Total Contacts Identified</th>
                                                            <th>HCPDet Contacts in Quarantine</th>
                                                            <th>HCPDet Contacts Tested till Date</th>
                                                            <th>HCPDet Results Received</th>
                                                            <th>HCPDet Contacts Found Positive</th>
                                                            <th>HCPDet Number of Results Awaited</th>
                                                        </tr>
                                                    </thead>
                                                    <!-- <tfoot>
                                                        <tr>
                                                            <th style="text-align: center;">#</th>
                                                            <th>Date</th>
                                                            <th>Province</th>
                                                            <th>Test Till Yesterday (8:00 PM)</th>
                                                            <th>Test Last 24 Hours</th>
                                                            <th>Test Total Tests Conducted till date</th>
                                                            <th>Rapid Till Yesterday (8:00 PM)</th>
                                                            <th>Rapid Last 24 Hours</th>
                                                            <th>Rapid Total Tests Conducted till date</th>
                                                            <th>Grand Total Tests Till Yesterday (8:00 PM)</th>
                                                            <th>Grand Total Tests In Last 24 Hours</th>
                                                            <th>Grand Total Tests Conducted till date</th>
                                                            <th>PCases Till Yesterday(8:00 PM)</th>
                                                            <th>PCases Last 24 hours</th>
                                                            <th>PCases Cumulative</th>
                                                            <th>ACases Till Yesterday(8:00 PM)</th>
                                                            <th>Acases Last 24 hours</th>
                                                            <th>Acases Cumulative</th>
                                                            <th>Grand Total Cases Till Yesterday (8:00 PM)</th>
                                                            <th>Grand Total Cases in Last 24 hours</th>
                                                            <th>Grand Total Cases till date</th>
                                                            <th>Death till Yesterday (8:00 PM)</th>
                                                            <th>Death Last 24 hours</th>
                                                            <th>Death Cumulative / Total Deaths</th>
                                                            <th>Died in Hospital On Ventilator</th>
                                                            <th>Died in Hospital Off Ventilator</th>
                                                            <th>Died at Home or Elsewhere</th>
                                                            <th>Suspect Till Yesterday(8:00 PM)</th>
                                                            <th>Suspect Contacts of Known COVID Pts</th>
                                                            <th>Suspect Others suspected</th>
                                                            <th>Suspect Total Suspects in last 24 hrs</th>
                                                            <th>Suspect Cumulative suspects</th>
                                                            <th>Clinic Total No. Of Hospitals with COVID Isolations / Case Mgt Facilities</th>
                                                            <th>Clinic Total No. Of Beds Allocated for COVID Patients</th>
                                                            <th>Clinic Total No. of Beds with Oxygen Facility allocated for COVID Patients</th>
                                                            <th>Clinic Total No. Of Ventilators allocated for COVID Patients</th>
                                                            <th>Clinic Patients Admitted in last 24 Hours</th>
                                                            <th>Clinic Total No. Of COVID Patients currently Admitted</th>
                                                            <th>Clinic Total No of Patients Clinically Stable</th>
                                                            <th>Clinic On Low Flow Oxygen</th>
                                                            <th>Clinic On High Flow Oxygen</th>
                                                            <th>Clinic Total (on Oxygen)</th>
                                                            <th>Clinic Total No. of Patients currently on Ventilator</th>
                                                            <th>Clinic Total No of Patients in Quarantine at Home or Elsewhere</th>
                                                            <th>Clinic Total Numbers Recovered and Discharged so far</th>
                                                            <th>Clinic Total Deaths till date</th>
                                                            <th>HCP Doctors (1)</th>
                                                            <th>HCP Nurses (2)</th>
                                                            <th>HCP Other Health Staff (3)</th>
                                                            <th>HCP Total HCWs infected till date (1+2+3)</th>
                                                            <th>HCP In Isolation (Home / Others)</th>
                                                            <th>HCP In Hospital</th>
                                                            <th>HCP Stable</th>
                                                            <th>HCP On Ventilator</th>
                                                            <th>HCP RecoveredAnd /OrDischarged</th>
                                                            <th>HCP Died</th>
                                                            <th>HCPDet Total Confirmed Cases Among Health Care Workers</th>
                                                            <th>HCPDet Number Performing Duties in Critical Care</th>
                                                            <th>HCPDet Number Performing Duties Elsewhere</th>
                                                            <th>HCPDet Total Contacts Identified</th>
                                                            <th>HCPDet Contacts in Quarantine</th>
                                                            <th>HCPDet Contacts Tested till Date</th>
                                                            <th>HCPDet Results Received</th>
                                                            <th>HCPDet Contacts Found Positive</th>
                                                            <th>HCPDet Number of Results Awaited</th>
                                                        </tr>
                                                        <tr>
                                                            <th colspan="3"></th>
                                                            <th colspan="3" style="text-align: center;">PCR Tests</th>
                                                            <th colspan="3" style="text-align: center;">Rapid Antigen Tests</th>
                                                            <th colspan="3" style="text-align: center;">Total Tests (PCR + Rapid Antigen Tests)</th>
                                                            <th colspan="3" style="text-align: center;">Cases from PCR Testing</th>
                                                            <th colspan="3" style="text-align: center;">Cases from Antigen Testing</th>
                                                            <th colspan="3" style="text-align: center;">Total COVID Cases (from PCR + Antigen Testing)</th>
                                                            <th colspan="3" style="text-align: center;">Deaths Due to COVID-19</th>
                                                            <th colspan="3" style="text-align: center;">Number Among Deaths in last 24 hours</th>
                                                            <th style="text-align: center;">Till 31 Mar(8:00 PM)</th>
                                                            <th colspan="4" style="text-align: center;">Suspected Cases in Last 24 Hour (with Breakup)</th>
                                                            <th colspan="14" style="text-align: center;">Hospitalized</th>
                                                            <th colspan="4" style="text-align: center;">Confirmed Cases Among Healthcare Workers (HCWs)</th>
                                                            <th colspan="6" style="text-align: center;">Status of Confirmed Cases of Healthcare Workers</th>
                                                            <th style="text-align: center;"></th>
                                                            <th colspan="2" style="text-align: center;">Out of Total Confirmed Cases Among Health Care Workers</th>
                                                            <th colspan="6" style="text-align: center;">Contacts of Healthcare Workers</th>
                                                        </tr>
                                                        <tr>
                                                            <th colspan="3"></th>
                                                            <th colspan="9" style="text-align: center;">Tests & Cases</th>
                                                            <th colspan="9" style="text-align: center;">Cases (Table 1B)</th>
                                                            <th colspan="11" style="text-align: center;">Death and Suspectes (Table 1C)</th>
                                                            <th colspan="14" style="text-align: center;">CLINICAL STATUS (Table 2A)</th>
                                                            <th colspan="10" style="text-align: center;">HCP (Table 3A)</th>
                                                            <th colspan="9" style="text-align: center;">HCP Details (Table 3B)</th>
                                                        </tr>
                                                    </tfoot> -->
                                                    <tbody>
                                                    <?php if(!empty($final_data[0]['id'])):?>
                                                        <?php $loop = 0;?>
                                                        <?php foreach($final_data as $data):?>
                                                            <tr>
                                                                <td style="text-align: center;"><?= ++$loop;?></td>
                                                                <td><?= date('d F, Y', strtotime($data['date']));?></td>
                                                                <td><?= $data['province_name'];?></td>
                                                                <td>
                                                                <?php 
                                                                echo !empty($data['pcr_till_yesterday'])?$data['pcr_till_yesterday']:0; 
                                                                $total_pcr = $data['pcr_till_yesterday'];
                                                                $grand_total_pcr_rapid_yesterday = $data['pcr_till_yesterday'];
                                                                ?>
                                                                </td>
                                                                <td>
                                                                <?php 
                                                                echo $data['pcr_in_last_24_hours']; 
                                                                $total_pcr += $data['pcr_in_last_24_hours'];
                                                                $grand_total_pcr_rapid_last_24_hrs = $data['pcr_in_last_24_hours'];
                                                                ?></td>
                                                                <td><?= $grand_total_coducted_till_today = $total_pcr;?></td>
                                                                <td>
                                                                <?php 
                                                                echo !empty($data['rapid_till_yesterday'])?$data['rapid_till_yesterday']:0; 
                                                                $total_rapid = $data['rapid_till_yesterday'];
                                                                $grand_total_pcr_rapid_yesterday += $data['rapid_till_yesterday'];
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo $data['rapid_in_last_24_hours']; 
                                                                $total_rapid += $data['rapid_in_last_24_hours'];
                                                                $grand_total_pcr_rapid_last_24_hrs += $data['rapid_in_last_24_hours'];
                                                                ?></td>
                                                                <td><?php echo $total_rapid; $grand_total_coducted_till_today += $total_rapid;?></td>
                                                                <td><?= $grand_total_pcr_rapid_yesterday;?></td>
                                                                <td><?= $grand_total_pcr_rapid_last_24_hrs;?></td>
                                                                <td><?= $grand_total_coducted_till_today;?></td>
                                                                <td>
                                                                <?php 
                                                                echo !empty($data['pcases_till_yesterday'])?$data['pcases_till_yesterday']:'0';
                                                                $total_pcases = $data['pcases_till_yesterday'];
                                                                $total_pcases_acases_yesterday = $data['pcases_till_yesterday'];
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo $data['pcases_in_last_24_hours'];
                                                                $total_pcases += $data['pcases_in_last_24_hours'];
                                                                $total_pcases_acases_last_24_hrs = $data['pcases_in_last_24_hours'];
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo $total_pcases;
                                                                $grand_total = $total_pcases;
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo !empty($data['acases_till_yesterday'])?$data['acases_till_yesterday']:'0';
                                                                $total_acases = $data['acases_till_yesterday'];
                                                                $total_pcases_acases_yesterday += $data['acases_till_yesterday'];
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo $data['acases_in_last_24_hrs'];
                                                                $total_acases += $data['acases_in_last_24_hrs'];
                                                                $total_pcases_acases_last_24_hrs += $data['acases_in_last_24_hrs'];
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo $total_acases;
                                                                $grand_total += $total_acases;
                                                                ?></td>
                                                                <td><?= $total_pcases_acases_yesterday;?></td>
                                                                <td><?= $total_pcases_acases_last_24_hrs;?></td>
                                                                <td><?= $grand_total;?></td>
                                                                <td>
                                                                <?php 
                                                                echo !empty($data['death_till_yesterday'])?$data['death_till_yesterday']:'0';
                                                                $total_deaths = $data['death_till_yesterday'];
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo $data['death_in_last_24_hours'];
                                                                $total_deaths += $data['death_in_last_24_hours'];
                                                                ?></td>
                                                                <td><?= $total_deaths;?></td>
                                                                <td><?= $data['died_in_hospital_on_ventilator'];?></td>
                                                                <td><?= $data['died_in_hospital_off_ventilator'];?></td>
                                                                <td><?= $data['died_at_home_or_elsewhere'];?></td>
                                                                <td>
                                                                <?php 
                                                                echo !empty($data['suspect_till_yesterday'])?$data['suspect_till_yesterday']:'0';
                                                                $cumulative_suspects = $data['suspect_till_yesterday'];
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo $data['suspect_contacts_of_known_covid_pts'];
                                                                $cumulative_suspects += $data['suspect_contacts_of_known_covid_pts'];
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo $data['others_suspected'];
                                                                $cumulative_suspects += $data['others_suspected'];
                                                                ?></td>
                                                                <td>
                                                                <?php 
                                                                echo $data['suspects_in_last_24_hrs'];
                                                                $cumulative_suspects += $data['suspects_in_last_24_hrs'];
                                                                ?></td>
                                                                <td><?= $cumulative_suspects;?></td>
                                                                <td><?= $data['hospitals_for_covid_isolation'];?></td>
                                                                <td><?= $data['beds_for_covid_patients'];?></td>
                                                                <td><?= $data['oxygen_beds_facility_for_covid_patients'];?></td>
                                                                <td><?= $data['vantilators_for_covid_patients'];?></td>
                                                                <td><?= $data['admitted_in_last_24_hours'];?></td>
                                                                <td><?= $data['covid_patients_currently_admitted'];?></td>
                                                                <td><?= $data['patients_clinically_stable'];?></td>
                                                                <td><?= $data['patients_on_low_flow_oxygen'];?></td>
                                                                <td><?= $data['patients_on_high_flow_oxygen'];?></td>
                                                                <td><?= '0';?></td>
                                                                <td><?= $data['patients_on_ventilator'];?></td>
                                                                <td><?= $data['patients_in_quarantine'];?></td>
                                                                <td><?= $data['patients_recovered_and_discharged'];?></td>
                                                                <td><?= $data['total_deaths_today'];?></td>
                                                                <td><?= $data['total_doctors'];?></td>
                                                                <td><?= $data['total_nurses'];?></td>
                                                                <td><?= $data['other_health_staff'];?></td>
                                                                <td><?= $data['total_infected'];?></td>
                                                                <td><?= $data['total_in_isolation'];?></td>
                                                                <td><?= $data['total_in_hospital'];?></td>
                                                                <td><?= $data['total_stable'];?></td>
                                                                <td><?= $data['total_on_ventilator'];?></td>
                                                                <td><?= $data['total_recovered_or_discharged'];?></td>
                                                                <td><?= $data['total_died'];?></td>
                                                                <td><?= $data['confirmed_cases_of_workers'];?></td>
                                                                <td><?= $data['performing_duties'];?></td>
                                                                <td><?= $data['performing_duties_elsewhere'];?></td>
                                                                <td><?= $data['contacts_identified'];?></td>
                                                                <td><?= $data['contacts_in_quarantine'];?></td>
                                                                <td><?= $data['contacts_tested_today'];?></td>
                                                                <td><?= $data['results_received'];?></td>
                                                                <td><?= $data['contacts_found_positive'];?></td>
                                                                <td><?= $data['results_awaited'];?></td>
                                                            </tr>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
                    </div>
                    <!-- /.main-page -->