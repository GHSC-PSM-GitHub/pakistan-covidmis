<?php
if (!empty($districts)) {
    foreach($districts as $district){
?>
      <option value="<?= $district['id'];?>"><?= $district['name'];?></option>
<?php
    }
}else{
?>
  <p>No Record Found</p>
<?php } ?>