<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <title>CodeIgniter3_CRUD!</title>
        <link rel="stylesheet" type="text/css" href="<?= base_url().'assets/css/bootstrap.min.css';?>" >
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    </head>
    <body style="background-color: lightgreen;">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                  <div class="row">
                    <div class="col-md-6">
                      <h3 class="mt-5">View Users</h3>
                    </div>
                    <div class="col-md-6" style="text-align: right;">
                      <a href="<?= base_url().'user/create';?>" class='mt-5 btn btn-primary btn-sm'>
                        <i class="fa fa-plus"></i>
                      </a>
                      <a href="<?= base_url().'user/logout';?>" class='mt-5 btn btn-primary btn-sm'>
                        <i class="fa fa-sign-out"></i>
                      </a>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="alert alert-success" role="alert" style="display: none; height: 30px; line-height: 0px;"></div>
                    </div>
                  </div>
                  <table class="table table-striped">
                      <thead>
                          <tr>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Gender</th>
                              <th>Designation</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody id="show-data">
                        <?php
                        if (!empty($users[0]['name'])) {
                            foreach($users as $user){
                        ?>
                                <tr>
                                  <td><?= $user['name'];?></td>
                                  <td><?= $user['email'];?></td>
                                  <td><?= $user['gender'];?></td>
                                  <td><?= $user['designation'];?></td>
                                  <td>
                                      <a href="<?= base_url().'user/edit/'.$user['user_id'];?>">
                                          <i class="fas fa-edit"></i>
                                      </a>&nbsp;&nbsp;
                                      <a href='<?= base_url().'user/delete/'.$user['user_id'];?>' class="delete-record">
                                          <i class="fas fa-trash"></i>
                                      </a>
                                  </td>
                              </tr>
                        <?php
                            }
                        }else{
                        ?>
                          <tr>
                              <td class="text-center" colspan="4">No Record Found</td>
                          </tr>
                        <?php } ?>
                      </tbody>
                  </table>
                </div>
            </div>
        </div>
        <script src="<?= base_url().'assets/js/jquery-3.6.0.min.js';?>"></script>
        <script type="text/javascript">
          $(document).ready(function(){
            function success_function(responseText, statusText, XMLHttpRequest){
              if (XMLHttpRequest.status == 200 && XMLHttpRequest.statusText == "OK" && statusText == "success") {
                jsonData = JSON.parse(responseText);
                if (jsonData['status'] == 'success') {
                  $("#show-data").html(jsonData['table_content']);
                  $('.alert').removeClass('alert-danger')
                            .addClass('alert-success')
                            .html("Record Deleted Successfully!...")
                            .css('display', 'block');
                }else{
                  $('.alert').removeClass('alert-success')
                            .addClass('alert-danger')
                            .html('Record Not Deleted!...')
                            .css('display-block');
                }
              }
            }
            
            function error_function(XMLHttpRequest){
              $("#error_message").html(responseText);
            }
            
            $(document).on('click', '.delete-record', function(e){
              e.preventDefault();
              $.ajax({
                url: $(this).attr("href"),
                success: success_function,
                error:error_function
              });
            });
          });
        </script>
    </body>
</html>