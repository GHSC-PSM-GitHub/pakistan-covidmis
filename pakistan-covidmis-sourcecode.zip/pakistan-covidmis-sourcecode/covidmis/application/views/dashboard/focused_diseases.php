
  <?php
//    echo '<pre>';
//    print_r($disease_trend);exit;
    if (empty($from_date)) {
        $from_date = date('Y-m', strtotime('-5 month'));
    }
// $from_date  = date('2020-06-01');
    if (empty($to_date)) {
        $to_date = date('Y-m');
    }

//    ------------------ Disease wise data START---------------------
      $label_arr = '[';
    $data_arr = '[';
    $i=0;
    foreach($disease_wise_data as $k => $val)
    {
        if($i<5)
    {
       $data_arr .= $val['total'] . ",";
        $label_arr .= '"' . $val['disease_name'] . '",';
        $i++;
    }
    }
     $label_arr = substr_replace($label_arr, "", -1);
    $label_arr .= ']';
    $data_arr = substr_replace($data_arr, "", -1);
    $data_arr .= ']';
       
//echo $label_arr;
//echo $data_arr; exit;
//    ------------------ Disease wise data END-----------------------
//    ------------------ Province wise data START---------------------
    $province_label = '[';
    $province_data = '[';
    foreach($province_wise_data as $k => $val)
    {
       $province_data .= $val['total'] . ",";
        $province_label .= '"' . $val['location'] . '",';
    }
     $province_label = substr_replace($province_label, "", -1);
    $province_label .= ']';
    $province_data = substr_replace($province_data, "", -1);
    $province_data .= ']';
       
    //echo $province_label;
//echo $province_data; exit;
//    ------------------ Province GRAPH END------------------------------------
//    ---------------------XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX------------
//    ------------------ Disease Trend data START------------------------------
$disease_array = $month_array = $sum_array = array();
    foreach ($disease_trend as $k => $val) {
        $disease_array[$val['disease_name']][$val['month']] = $val['sum'];
        $month_array[] = $val['month'];
    }
    $month_array = array_values(array_unique($month_array));
    $trend_month = $disease1 = $disease2 = $disease3 = $disease4 = $disease5 = '[';
    $disease1_name = $disease2_name = $disease3_name = $disease4_name = $disease5_name = '';
//       echo '<pre>';
    $limit = count($month_array);
    foreach ($month_array as $k => $months) {
        $months = date("M-y",strtotime($months));
        $trend_month .= '"' . $months . '",';
    }
    $j = 0;
    foreach ($disease_array as $dis_name => $array) {
        foreach ($month_array as $k => $mon) {
//        echo '<pre>';
//            print_r ($disease_array); exit;
            $value = $disease_array[$dis_name][$mon];
            if ($j < $limit) {
                $disease1_name = $dis_name;
                $disease1 .= $value . ',';
            } elseif ($j < (2 * $limit)) {
                $disease2_name = $dis_name;
                $disease2 .= $value . ',';
            } elseif ($j < (3 * $limit)) {
                $disease3_name = $dis_name;
                $disease3 .= $value . ',';
            } elseif ($j < (4 * $limit)) {
                $disease4_name = $dis_name;
                $disease4 .= $value . ',';
            } elseif ($j < (5 * $limit)) {
                $disease5_name = $dis_name;
                $disease5 .= $value . ',';
            }
            $j++;
        }
    }
    $disease1 = substr_replace($disease1, "", -1);
    $disease1 .= ']';
    $disease2 = substr_replace($disease2, "", -1);
    $disease2 .= ']';
    $disease3 = substr_replace($disease3, "", -1);
    $disease3 .= ']';
    $disease4 = substr_replace($disease4, "", -1);
    $disease4 .= ']';
    $disease5 = substr_replace($disease5, "", -1);
    $disease5 .= ']';
    $trend_month = substr_replace($trend_month, "", -1);
    $trend_month .= ']';
//    echo $disease5; exit;
//    ------------------ Disease Trend GRAPH END-----------------------
    ?>

<!-- ========== MAIN CONTENT ========== -->
<div class="main-page">
    <!-- /.container-fluid -->
    <section class="section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12" >
                    <div class="panel-heading" style="background-color:#db2742;">
                        <div class="panel-title">
                            <h6 style="color:white;" class="panel-title txt-light"><?= $page_title; ?></h6>
                        </div>
                    </div>
                    <div class="panel-body p-20" style="overflow: auto;">
                         <div class="row" >
                    <div class="col-md-12" >
                        <form method="post"  name="form1" action="../dashboard/focused_diseases">
                            
                            
                                    <div class="col-sm-4">
                                        <div class="form-group mr-15">
                                            <label class="control-label mr-10" for="email_inline">From Month </label>
                                            <input class="form-control"  type="month" id ="from_date" name="from_date" value="<?php echo $from_date ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group mr-15">
                                            <label class="control-label mr-10" for="pwd_inline">To Month</label>
                                            <input class="form-control" type="month" id ="to_date" name="to_date" value="<?php echo $to_date ?>" >
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group mr-15">
                                            <label class="control-label mr-10" for="pwd_inline">&nbsp;</label>
                                            <input class="btn btn-success form-control"  type="submit" name="save_btn1" id="save_btn1" value="Go"> 
                                        </div>
                                    </div>
                        </form>
                    </div>
                </div>
                        
                 <div class="row">

                    <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Focused Diseases </h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="myChart1" height="400"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                   
                    <div class="col-lg-6">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Province Wise Patients </h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <canvas id="province" height="400"></canvas>
                                </div>
                            </div>

                        </div>	
                    </div>
                </div>         
                
                 <div class="row">

                    <div class="col-lg-12">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h2 class="panel-title txt-dark">Diseases Trend (Top 5)</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                              <div class="panel-wrapper collapse in">
                                            <div class="panel-body">
                                                <canvas id="line-chart" height="120"></canvas>
                                            </div>
                                        </div>

                        </div>	
                    </div>
                      </div>

                <div><b>Click on the Graph for Drilldown</b></div>        
                       

                      

                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<script src="<?php echo base_url(); ?>/assets/charts_js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/charts_js/Chart.min.js"></script>
<!-- ========== END MAIN CONTENT ========== -->

<script>
    /*Chartjs Init*/

    $(document).ready(function () {
        //        "use strict";

        var ctx = document.getElementById("myChart1").getContext("2d");

        var config = {
            type: 'bar',
            data: {
                labels: <?php echo $label_arr; ?>,
                datasets: [{
                        label: "Patients",
                        type: "bar",
                        backgroundColor: [
                                    "#a05195",
                                    "#d45087",
                                    "#f95d6a",
                                    "#ff7c43",
                                    "#ffa600",
                                    "#d6a204",
"#57eadd",
"#59e8f0"
                        ],
                        data: <?php echo $data_arr; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                  tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                        ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent
            }
        }; // end of var config

        function chartClickEvent(event, array)
        {
            if (myLiveChart === undefined || myLiveChart == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
                         window.open("<?php echo base_url();?>dashboard/disease_drill/?label=" + label + "&from_date=" + from_date + "&to_date=" + to_date, '_blank');
//            window.open("../dashboard/disease_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveChart = new Chart(ctx, config);
        
// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Province Chart Start (Bar Chart) xxxxxxxxxxxxxxxxxxxxxxxxxx

 var ctx1 = document.getElementById("province").getContext("2d");

        var config1 = {
            type: 'bar',
            data: {
                labels: <?php echo $province_label; ?>,
                datasets: [{
                        label: "Patients",
                        type: "bar",
                        backgroundColor: [
                '#edd851',
                '#51beed',
                '#51ed73',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(45, 128, 63, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
,
                        data: <?php echo $province_data; ?>
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{barPercentage: 0.5}],
                    yAxes: [{id: 'Dataset1', position: 'left', type: 'linear',
                            ticks: {min: 0, beginAtZero: false}}]
                },
                  tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            return tooltipItem.yLabel.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                        }
                    }
                },
                animation: {
                    duration: 3000,
                    onComplete: function () {
                        var chartInstance = this.chart,
                        ctx = chartInstance.ctx;
                        ctx.textAlign = 'center';
                        ctx.fillStyle = "rgba(0, 0, 0, 1)";
                        ctx.textBaseline = 'bottom';
                        // Loop through each data in the datasets
                        this.data.datasets.forEach(function (dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            meta.data.forEach(function (bar, index) {
                                var data = dataset.data[index];
                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                            });
                        });
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {display: false, position: 'bottom'},
                onClick: chartClickEvent1
            }
        }; // end of var config

        function chartClickEvent1(event, array)
        {
            if (myLiveChart1 === undefined || myLiveChart1 == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveChart1.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }

            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            window.open("<?php echo base_url();?>dashboard/focused_drill_prov/" + label + "/" + from_date + "/" + to_date, '_blank');   
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }

        var myLiveChart1 = new Chart(ctx1, config1);

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxx START LINE CHART xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        new Chart(document.getElementById("line-chart"), {
            type: 'line',
            data: {
                labels: <?php echo $trend_month; ?>,
                datasets: [{
                        data: <?php echo $disease1; ?>,
                        label: "<?php echo $disease1_name;?>",
                        borderColor: "#8e5ea2",
                        fill: false
                    },
                    {
                        data: <?php echo $disease2;?>,
                        label: "<?php echo $disease2_name;?>",
                        borderColor: "#42f59b",
                        fill: false
                    },
                    {
                        data: <?php echo $disease3;?>,
                        label: "<?php echo $disease3_name;?>",
                        borderColor: "#f5bf42",
                        fill: false
                    },
                            {
                        data: <?php echo $disease4;?>,
                        label: "<?php echo $disease4_name;?>",
                        borderColor: "#f58d42",
                        fill: false
                    },
                            {
                        data: <?php echo $disease5;?>,
                        label: "<?php echo $disease5_name;?>",
                        borderColor: "#f5429e",
                        fill: false
                    }
                ]
            },
            options: {
                legend: {display: true},
                title: {
                    display: false,
                    text: ''
                }, scales: {
                    xAxes: [{
                            gridLines: {
                                display: false
                            }
                        }],
                    yAxes: [{
                            gridLines: {
                                display: true
                            },
                            ticks: {

                            },
                            legend: {display: true, position: 'top'}
                        }]
                }
            }
        });

//xxxxxxxxxxxxxxxxx END xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


    });
</script>                






