<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ventilators extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Ventilator_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// end __construct function

	public function index(){
		$data['page_title'] = 'Ventilators (Table 2B)';
		$data['ventilators'] = $this->Ventilator_model->all();
		$data['main_content'] = $this->load->view('ventilators/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function

	public function create(){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		$this->form_validation->set_rules('district_id', 'District', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'Ventilator (Table 2B)';
			$data['provinces'] = $this->Ventilator_model->getProvinces();
			$data['main_content'] = $this->load->view('ventilators/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'date'                                   => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'                            => $this->input->post('province_id'),
				'district_id'                            => $this->input->post('district_id'),
				'available_ventilators'                  => $this->input->post('available_ventilators'),
				'ventilators_allocated_for_covid'        => $this->input->post('ventilators_allocated_for_covid'),
				'ventilators_occupied_by_covid_patients' => $this->input->post('ventilators_occupied_by_covid_patients'),
				'currently_vacant_ventilators'           => $this->input->post('currently_vacant_ventilators'),
				'vacant_non_covid_vents'                 => $this->input->post('vacant_non_covid_vents'),
				'status'                                 => 1,
			);
			$this->Ventilator_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'ventilators/index');
		}
	}// end create function

	public function edit($id=''){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		$this->form_validation->set_rules('district_id', 'District', 'required');
		if ($this->form_validation->run() == false) {
			$ventilator = $this->Ventilator_model->getDataById($id);
			if (!empty($ventilator[0]['id'])) {
				$data = array(
					'ventilator' => $ventilator,
				);
				$data['page_title'] = 'Ventilator (Table 2B)';
				$data['provinces'] = $this->Ventilator_model->getProvinces();
				$data['districts'] = $this->Ventilator_model->getDistrictsById($ventilator[0]['province_id']);
				$data['main_content'] = $this->load->view('ventilators/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'ventilators/index');
			}
		}else{
			$formArray = array(
				'date'                                   => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'                            => $this->input->post('province_id'),
				'district_id'                            => $this->input->post('district_id'),
				'available_ventilators'                  => $this->input->post('available_ventilators'),
				'ventilators_allocated_for_covid'        => $this->input->post('ventilators_allocated_for_covid'),
				'ventilators_occupied_by_covid_patients' => $this->input->post('ventilators_occupied_by_covid_patients'),
				'currently_vacant_ventilators'           => $this->input->post('currently_vacant_ventilators'),
				'vacant_non_covid_vents'                 => $this->input->post('vacant_non_covid_vents'),
			);
			$this->Ventilator_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'ventilators/index');
		}
	}// end edit function

	public function delete($id){
		$this->Ventilator_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'ventilators/index');
	}//end delete function
}// end Ventilators Class