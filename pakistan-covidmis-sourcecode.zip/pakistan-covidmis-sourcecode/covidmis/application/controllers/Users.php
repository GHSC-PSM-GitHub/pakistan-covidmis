<?php
	class Users extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->helper('url');
			$this->load->helper('form');
			$this->load->library('form_validation');
			$this->load->library('session');
			$this->load->model('User_model');
			$this->load->model('Province_model');
			if (empty($this->session->userdata('pk_id'))) {
				redirect(base_url().'common/login');
			}
		}//end __construct function

		public function index(){
			$data['page_title'] = 'Users';
			$data['users'] = $this->User_model->getAll();
			$data['main_content'] = $this->load->view('users/list', $data, TRUE);
			$this->load->view('theme/main', $data);
		}//end index function

		public function create(){
			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');
			$this->form_validation->set_rules('fullname', 'Full Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('contact', 'Contact Number', 'required');
			$this->form_validation->set_rules('designation', 'Designation', 'required');
			if ($this->form_validation->run() == false) {
				$data['page_title'] = 'User';
				$data['provinces'] = $this->Province_model->all();
				$data['main_content'] = $this->load->view('users/create', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				$formArray = array(
					'username'    => $this->input->post('username'),
					'password'    => md5($this->input->post('password')),
					'fullname'    => $this->input->post('fullname'),
					'email'       => $this->input->post('email'),
					'contact'     => $this->input->post('contact'),
					'designation' => $this->input->post('designation'),
					'province_id' => $this->input->post('province_id'),
					'status'      => $this->input->post('status'),
				);
				$this->User_model->create($formArray);
				$this->session->set_flashdata('success', 'Record Added Successfully!...');
				redirect(base_url().'users/index');
			}
		}//end create function

		public function edit($id = ''){
			$this->form_validation->set_rules('fullname', 'Full Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('contact', 'Contact Number', 'required');
			$this->form_validation->set_rules('designation', 'Designation', 'required');
			if ($this->form_validation->run() == false) {
				$data['page_title'] = 'User';
				$data['user'] = $this->User_model->find_by_id($id);
				$data['provinces'] = $this->Province_model->all();
				$data['main_content'] = $this->load->view('users/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				$formArray = array(
					'fullname'    => $this->input->post('fullname'),
					'email'       => $this->input->post('email'),
					'contact'     => $this->input->post('contact'),
					'designation' => $this->input->post('designation'),
					'province_id' => $this->input->post('province_id'),
					'status'      => $this->input->post('status'),
				);
				$this->User_model->update($id, $formArray);
				$this->session->set_flashdata('success', 'Record Updated Successfully!...');
				redirect(base_url().'users/index');
			}
		}//end edit function

		public function check_username(){
			$username = $this->input->post('username');
			$username_result = $this->User_model->check_username($username);
			if (!empty($username_result[0]['username'])) {
				$data = array('message' => 'This Username is Already Exists!...');
				echo json_encode($data);
			}else{
				$data = array('message' => '');
				echo json_encode($data);
			}
		}//end check_username function

		public function delete($id){
			$user = $this->User_model->find_by_id($id);
			if ($user[0]['status'] == 1) {
				$dataArray['status'] = 0;
				$message = 'InActive';
			}else{
				$dataArray['status'] = 1;
				$message = 'Active';
			}
			$this->User_model->delete($id, $dataArray);
			$this->session->set_flashdata('success', "Record $message Successfully!...");
			redirect(base_url().'users/index');
		}//end delete function

		public function change_password($id){
			$data['user'] = $this->User_model->find_by_id($id);
			$data['main_content'] = $this->load->view('users/change_password', $data, TRUE);
			$this->load->view('theme/main', $data);
		}

		public function update_password(){
			$id = $this->input->post('id');
			$password = md5($this->input->post('password'));
			$data = array(
				'password' => $password,
			);
			$this->User_model->update_password($id, $data);
			$this->session->set_flashdata('success', 'Password Updated Successfully!...');
			redirect(base_url().'users/index');
		}
	}//end Users Class
?>