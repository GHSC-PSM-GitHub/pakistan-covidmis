<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class District_reports extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('District_report_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// end __construct function

	public function index(){
		$data['page_title'] = 'District Report';
		$data['date'] = date('Y-m-d', strtotime($this->input->post('date')));
		$situations = $this->District_report_model->getSituationsData($data['date']);
		$oxygen = $this->District_report_model->getOxygenData($data['date']);
		$ventilators = $this->District_report_model->getVentilatorsData($data['date']);
		$i=$j=$k=$index=0;
		for (; (!empty($situations[$i]['id']) || !empty($oxygen[$j]['id']) || !empty($ventilators[$k]['id'])) ; ) { 
			if (!empty($situations[$i]['id'])) {
				$date = $situations[$i]['date'];
				$province_id = $situations[$i]['province_id'];
				$district_id = $situations[$i]['district_id'];
			}elseif(!empty($oxygen[$j]['id'])){
				$date = $oxygen[$j]['date'];
				$province_id = $oxygen[$j]['province_id'];
				$district_id = $oxygen[$j]['district_id'];
			}elseif(!empty($ventilators[$k]['id'])){
				$date = $ventilators[$k]['date'];
				$province_id = $ventilators[$k]['province_id'];
				$district_id = $ventilators[$k]['district_id'];
			}

			if (!empty($situations[$i]['id']) && $situations[$i]['date'] == $date && $situations[$i]['province_id'] == $province_id && $situations[$i]['district_id'] == $district_id) {
				$data['final_data'][$index] = $situations[$i];
				++$i;
			}else{
				$data['final_data'][$index]['covid_test_in_last_24_hrs'] = 0;
				$data['final_data'][$index]['confirm_cases_in_last_24_hrs'] = 0;
				$data['final_data'][$index]['s_in_quarantine'] = 0;
				$data['final_data'][$index]['s_admitted_in_hospital'] = 0;
				$data['final_data'][$index]['cumulative'] = 0;
				$data['final_data'][$index]['s_clinically_stable'] = 0;
				$data['final_data'][$index]['s_on_low_flow_oxygen'] = 0;
				$data['final_data'][$index]['s_on_high_flow_oxygen'] = 0;
				$data['final_data'][$index]['s_on_ventilator'] = 0;
				$data['final_data'][$index]['s_of_new_patients_admitted_in_hospital'] = 0;
				$data['final_data'][$index]['s_in_last_24_hrs'] = 0;
			}

			if (!empty($oxygen[$j]['id']) && $oxygen[$j]['date'] == $date && $oxygen[$j]['province_id'] == $province_id && $oxygen[$j]['district_id'] == $district_id) {
				$data['final_data'][$index] = array_merge($oxygen[$j], $data['final_data'][$index]);
				++$j;
			}else{
				$data['final_data'][$index]['available_oxygen_beds'] = 0;
				$data['final_data'][$index]['available_oxygen_beds_for_covid'] = 0;
				$data['final_data'][$index]['oxygen_beds_occupied_by_covid_patients'] = 0;
				$data['final_data'][$index]['patients_on_low_oxygen'] = 0;
				$data['final_data'][$index]['patients_on_high_oxygen'] = 0;
				$data['final_data'][$index]['vacant_beds_with_oxygen'] = 0;
			}

			if (!empty($ventilators[$k]['id']) && $ventilators[$k]['date'] == $date && $ventilators[$k]['province_id'] == $province_id && $ventilators[$k]['district_id'] == $district_id) {
				$data['final_data'][$index] = array_merge($ventilators[$k], $data['final_data'][$index]);
				++$k;
			}else{
				$data['final_data'][$index]['available_ventilators'] = 0;
				$data['final_data'][$index]['ventilators_allocated_for_covid'] = 0;
				$data['final_data'][$index]['ventilators_occupied_by_covid_patients'] = 0;
				$data['final_data'][$index]['currently_vacant_ventilators'] = 0;
				$data['final_data'][$index]['vacant_non_covid_vents'] = 0;
			}
			$index++;
		}
		// echo "<pre>";
		// var_dump($data);die;
		$data['main_content'] = $this->load->view('district_reports/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function
}// end District_reports class