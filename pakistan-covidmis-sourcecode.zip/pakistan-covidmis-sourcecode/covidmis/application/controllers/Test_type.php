<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_type extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Test_type_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// end __construct function

	public function index(){
		$data['page_title'] = 'Test Types';
		$data['test_types'] = $this->Test_type_model->all();
		$data['main_content'] = $this->load->view('test_type/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function

	public function create(){
		$this->form_validation->set_rules('name', 'Test Type', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'Test Types';
			$data['main_content'] = $this->load->view('test_type/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'name'   => $this->input->post('name'),
				'status' => 1,
			);
			$this->Test_type_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'test_type/index');
		}
	}// end create function

	public function edit($id=''){
		$this->form_validation->set_rules('name', 'Test Type', 'required');
		if ($this->form_validation->run() == false) {
			$test_type = $this->Test_type_model->getTestType($id);
			if (!empty($test_type[0]['id'])) {
				$data = array(
					'test_type' => $test_type,
				);
				$data['page_title'] = 'Test Types';
				$data['main_content'] = $this->load->view('test_type/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'test_type/index');
			}
		}else{
			$formArray = array(
				'name'        => $this->input->post('name'),
			);
			$this->Test_type_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'test_type/index');
		}
	}// end edit function

	public function delete($id){
		$this->Test_type_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'test_type/index');
	}//end delete function
}// end Test_type class