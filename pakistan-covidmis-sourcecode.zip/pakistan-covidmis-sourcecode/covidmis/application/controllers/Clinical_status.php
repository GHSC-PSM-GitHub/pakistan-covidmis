<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clinical_status extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Clinical_status_model');
		$this->load->library('encryption');
		// echo $this->session->has_userdata('id');die;
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// end __construct function

	public function index(){
		$data['page_title'] = 'Clinical Status (Table 2A)';
		$data['clinical_status'] = $this->Clinical_status_model->all();
		$data['main_content'] = $this->load->view('clinical_status/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function

	public function create(){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'Clinical Status (Table 2A)';
			$data['provinces'] = $this->Clinical_status_model->getProvinces();
			$data['main_content'] = $this->load->view('clinical_status/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'date'                 => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'          => $this->input->post('province_id'),
				'beds_for_covid_patients' => $this->input->post('beds_for_covid_patients'),
				'hospitals_for_covid_isolation'  => $this->input->post('hospitals_for_covid_isolation'),
				'oxygen_beds_facility_for_covid_patients' => $this->input->post('oxygen_beds_facility_for_covid_patients'),
				'vantilators_for_covid_patients' => $this->input->post('vantilators_for_covid_patients'),
				'admitted_in_last_24_hours' => $this->input->post('admitted_in_last_24_hours'),
				'covid_patients_currently_admitted' => $this->input->post('covid_patients_currently_admitted'),
				'patients_clinically_stable' => $this->input->post('patients_clinically_stable'),
				'patients_on_low_flow_oxygen' => $this->input->post('patients_on_low_flow_oxygen'),
				'patients_on_high_flow_oxygen' => $this->input->post('patients_on_high_flow_oxygen'),
				'patients_on_ventilator' => $this->input->post('patients_on_ventilator'),
				'patients_in_quarantine' => $this->input->post('patients_in_quarantine'),
				'patients_recovered_and_discharged' => $this->input->post('patients_recovered_and_discharged'),
				'total_deaths_today' => $this->input->post('total_deaths_today'),
				'status'      => 1,
			);
			$this->Clinical_status_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'clinical_status/index');
		}
	}//end create function

	public function edit($id=''){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$clinical_status = $this->Clinical_status_model->getDataById($id);
			if (!empty($clinical_status[0]['id'])) {
				$data = array(
					'clinical_status' => $clinical_status,
				);
				$data['page_title'] = 'Clinical Status (Table 2A)';
				$data['provinces'] = $this->Clinical_status_model->getProvinces();
				$data['main_content'] = $this->load->view('clinical_status/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'clinical_status/index');
			}
		}else{
			$formArray = array(
				'date'                 => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'          => $this->input->post('province_id'),
				'beds_for_covid_patients' => $this->input->post('beds_for_covid_patients'),
				'hospitals_for_covid_isolation'  => $this->input->post('hospitals_for_covid_isolation'),
				'oxygen_beds_facility_for_covid_patients' => $this->input->post('oxygen_beds_facility_for_covid_patients'),
				'vantilators_for_covid_patients' => $this->input->post('vantilators_for_covid_patients'),
				'admitted_in_last_24_hours' => $this->input->post('admitted_in_last_24_hours'),
				'covid_patients_currently_admitted' => $this->input->post('covid_patients_currently_admitted'),
				'patients_clinically_stable' => $this->input->post('patients_clinically_stable'),
				'patients_on_low_flow_oxygen' => $this->input->post('patients_on_low_flow_oxygen'),
				'patients_on_high_flow_oxygen' => $this->input->post('patients_on_high_flow_oxygen'),
				'patients_on_ventilator' => $this->input->post('patients_on_ventilator'),
				'patients_in_quarantine' => $this->input->post('patients_in_quarantine'),
				'patients_recovered_and_discharged' => $this->input->post('patients_recovered_and_discharged'),
				'total_deaths_today' => $this->input->post('total_deaths_today'),
			);
			$this->Clinical_status_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'clinical_status/index');
		}
	}// end edit function

	public function delete($id){
		$this->Clinical_status_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'clinical_status/index');
	}//end delete function
}// end Clinical_status class