<?php

class covim extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
//                   check_login_user();
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('dashboard_model');
//		$this->load->model('Application_screening_model');
                $this->load->model('covim_model');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}

     public function stock_status()
	{
            $data['page_title'] = 'COVIM Stock Status';
			$from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m-01', strtotime('-5 month'));
				$to = date('Y-m-d');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;

			$data['fetched_product'] = $this->covim_model->product();
			$data['consumption'] = $this->covim_model->consumption($from, $to);
			$data['stock_on_hand'] = $this->covim_model->stock_on_hand($from, $to);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('covim/stock_status', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
        
           public function consumption_drill_1($product_name,$from,$to)
	{

$product_name = str_replace('%20', ' ', $product_name);
 $product_name = strtok($product_name, ',');
// echo $product_name ; exit;
			$item = $this->covim_model->product_drill($product_name);
                        $item_code = $item[0]['item_code'];
			$data['consumption_drill'] = $this->covim_model->province_consumption($from,$to,$item_code);
                        $data['from_date'] = $from;
			$data['to_date'] = $to;
                        $data['item_code'] = $item_code;
                         $data['item_name'] = $product_name;
			$data['main_content'] = $this->load->view('covim/drill_1', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
        
            public function consumption_drill_2($prov,$from,$to,$item_code,$item_name = NULL)
	{

$prov = str_replace('%20', ' ', $prov);
// echo $product_name ; exit;
			$province_name = $this->covim_model->prov_id($prov);
                        $prov_id = $province_name[0]['pro_id'];
			$data['consumption_drill'] = $this->covim_model->district_consumption($prov_id,$from,$to,$item_code);
                        $data['from_date'] = $from;
			$data['to_date'] = $to;
                        $data['item_code'] = $item_code;
                        $data['item_name'] = $item_name;
			$data['main_content'] = $this->load->view('covim/drill_2', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
        
              public function soh_drill_1($product_name,$from,$to)
	{

$product_name = str_replace('%20', ' ', $product_name);
 $product_name = strtok($product_name, ',');
// echo $product_name ; exit;
			$item = $this->covim_model->product_drill($product_name);
                        $item_code = $item[0]['item_code'];
			$data['consumption_drill'] = $this->covim_model->province_soh($from,$to,$item_code);
                        $data['from_date'] = $from;
			$data['to_date'] = $to;
                        $data['item_code'] = $item_code;
                         $data['item_name'] = $product_name;
			$data['main_content'] = $this->load->view('covim/soh_drill_1', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
        
            public function soh_drill_2($prov,$from,$to,$item_code,$item_name=NULL)
	{
$prov = str_replace('%20', ' ', $prov);
$from = str_replace('%20', '', $from);
$to = str_replace('%20', '', $to);
$item_name = str_replace('%20', '', $item_name);
// echo $item_name ; exit;
			$province_name = $this->covim_model->prov_id($prov);
                        $prov_id = $province_name[0]['pro_id'];
			$data['consumption_drill'] = $this->covim_model->district_soh($prov_id,$from,$to,$item_code);
                        $data['from_date'] = $from;
			$data['to_date'] = $to;
                        $data['item_code'] = $item_code;
                        $data['item_name'] = $item_name;
			$data['main_content'] = $this->load->view('covim/soh_drill_2', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
        
//        xxxxxxxxxxxxxxxxxxxxxxxxxxxx  MONTH WISE CONSUMPTION START  xxxxxxxxxxxxxxxxxxxxxx
          public function monthly_status()
	{
              $data['page_title'] = 'Monthly Consumption & Wastage';
			$from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m', strtotime('-5 month'));
				$to = date('Y-m');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;
			$data['consumption'] = $this->covim_model->monthly_consumption($from, $to);
			$data['monthly_wastage'] = $this->covim_model->monthly_wastage($from, $to);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('covim/monthly_status', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
//        xxxxxxxxxxxxxxxxxxxxxxxxxxxx  MONTH WISE CONSUMPTION END  xxxxxxxxxxxxxxxxxxxxxx   
        
        //        xxxxxxxxxxxxxxxxxxxxxxxxxxxx  CONSUMPTION Pattern START  xxxxxxxxxxxxxxxxxxxxxx
          public function consumption_pattern()
	{
               $data['page_title'] = 'Consumption Pattern';
			$from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m', strtotime('-5 month'));
				$to = date('Y-m');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;
			$data['consumption'] = $this->covim_model->consumption_pattern($from, $to);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('covim/consumption_pattern', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
//        xxxxxxxxxxxxxxxxxxxxxxxxxxxx  CONSUMPTION Pattern END  xxxxxxxxxxxxxxxxxxxxxx  
        
//        xxxxxxxxxxxxxxxxxxxxxxxxxxxx  FDI START  xxxxxxxxxxxxxxxxxxxxxx  
        
//        xxxxxxxxxxxxxxxxxxxxxxxxxxxx  FDI END  xxxxxxxxxxxxxxxxxxxxxx          
        
}

?>
