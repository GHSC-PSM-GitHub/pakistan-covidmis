<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hcp extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Hcp_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// end __construct function

	public function index(){
		$data['page_title'] = 'HCP (Table 3A)';
		$data['hcps'] = $this->Hcp_model->all();
		$data['main_content'] = $this->load->view('hcp/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function

	public function create(){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'HCP (Table 3A)';
			$data['provinces'] = $this->Hcp_model->getProvinces();
			$data['main_content'] = $this->load->view('hcp/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'date'                 => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'          => $this->input->post('province_id'),
				'total_doctors' => $this->input->post('total_doctors'),
				'total_nurses'  => $this->input->post('total_nurses'),
				'other_health_staff' => $this->input->post('other_health_staff'),
				'total_infected' => $this->input->post('total_infected'),
				'total_in_isolation' => $this->input->post('total_in_isolation'),
				'total_in_hospital' => $this->input->post('total_in_hospital'),
				'total_stable' => $this->input->post('total_stable'),
				'total_on_ventilator' => $this->input->post('total_on_ventilator'),
				'total_recovered_or_discharged' => $this->input->post('total_recovered_or_discharged'),
				'total_died' => $this->input->post('total_died'),
				'status'      => 1,
			);
			$this->Hcp_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'hcp/index');
		}
	}//end create function

	public function edit($id=''){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$hcp = $this->Hcp_model->getDataById($id);
			if (!empty($hcp[0]['id'])) {
				$data = array(
					'hcp' => $hcp,
				);
				$data['page_title'] = 'HCP (Table 3A)';
				$data['provinces'] = $this->Hcp_model->getProvinces();
				$data['main_content'] = $this->load->view('hcp/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'hcp/index');
			}
		}else{
			$formArray = array(
				'date'                 => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'          => $this->input->post('province_id'),
				'total_doctors' => $this->input->post('total_doctors'),
				'total_nurses'  => $this->input->post('total_nurses'),
				'other_health_staff' => $this->input->post('other_health_staff'),
				'total_infected' => $this->input->post('total_infected'),
				'total_in_isolation' => $this->input->post('total_in_isolation'),
				'total_in_hospital' => $this->input->post('total_in_hospital'),
				'total_stable' => $this->input->post('total_stable'),
				'total_on_ventilator' => $this->input->post('total_on_ventilator'),
				'total_recovered_or_discharged' => $this->input->post('total_recovered_or_discharged'),
				'total_died' => $this->input->post('total_died'),
			);
			$this->Hcp_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'hcp/index');
		}
	}// end edit function

	public function delete($id){
		$this->Hcp_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'hcp/index');
	}//end delete function
}// end hcp class