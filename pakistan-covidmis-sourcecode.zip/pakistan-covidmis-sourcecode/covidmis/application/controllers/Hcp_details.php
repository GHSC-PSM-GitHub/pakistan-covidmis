<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hcp_details extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Hcp_details_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// end __construct function

	public function index(){
		$data['page_title'] = 'HCP Details (Table 3B)';
		$data['hcp_details'] = $this->Hcp_details_model->all();
		$data['main_content'] = $this->load->view('hcp_details/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function

	public function create(){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'HCP Detail (Table 3B)';
			$data['provinces'] = $this->Hcp_details_model->getProvinces();
			$data['main_content'] = $this->load->view('hcp_details/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'date'                        => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'                 => $this->input->post('province_id'),
				'confirmed_cases_of_workers'  => $this->input->post('confirmed_cases_of_workers'),
				'performing_duties'           => $this->input->post('performing_duties'),
				'performing_duties_elsewhere' => $this->input->post('performing_duties_elsewhere'),
				'contacts_identified'         => $this->input->post('contacts_identified'),
				'contacts_in_quarantine'      => $this->input->post('contacts_in_quarantine'),
				'contacts_tested_today'       => $this->input->post('contacts_tested_today'),
				'results_received'            => $this->input->post('results_received'),
				'contacts_found_positive'     => $this->input->post('contacts_found_positive'),
				'results_awaited'             => $this->input->post('results_awaited'),
				'status'                      => 1,
			);
			$this->Hcp_details_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'hcp_details/index');
		}
	}// end create function

	public function edit($id=''){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$hcp_detail = $this->Hcp_details_model->getDataById($id);
			if (!empty($hcp_detail[0]['id'])) {
				$data = array(
					'hcp_detail' => $hcp_detail,
				);
				$data['page_title'] = 'HCP Detail (Table 3B)';
				$data['provinces'] = $this->Hcp_details_model->getProvinces();
				$data['main_content'] = $this->load->view('hcp_details/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'hcp_details/index');
			}
		}else{
			$formArray = array(
				'date'                        => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'                 => $this->input->post('province_id'),
				'confirmed_cases_of_workers'  => $this->input->post('confirmed_cases_of_workers'),
				'performing_duties'           => $this->input->post('performing_duties'),
				'performing_duties_elsewhere' => $this->input->post('performing_duties_elsewhere'),
				'contacts_identified'         => $this->input->post('contacts_identified'),
				'contacts_in_quarantine'      => $this->input->post('contacts_in_quarantine'),
				'contacts_tested_today'       => $this->input->post('contacts_tested_today'),
				'results_received'            => $this->input->post('results_received'),
				'contacts_found_positive'     => $this->input->post('contacts_found_positive'),
				'results_awaited'             => $this->input->post('results_awaited'),
			);
			$this->Hcp_details_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'hcp_details/index');
		}
	}// end edit function

	public function delete($id){
		$this->Hcp_details_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'hcp_details/index');
	}//end delete function
}// end hcp_details Class