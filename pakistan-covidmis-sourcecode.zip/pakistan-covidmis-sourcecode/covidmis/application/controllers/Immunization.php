<?php

class immunization extends CI_Controller {

    public function __construct() {
        parent::__construct();
//           check_login_user();
        $this->load->database();
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->model('dashboard_model');
//        $this->load->model('Application_screening_model');
//        $this->load->model('covim_model');
        $this->load->model('immunization_model');

		if(!isset($_GET['qr'])){
			if (!$this->session->has_userdata('pk_id')) {
				redirect(base_url().'welcome/index');
			}
		}        
    }

    public function vaccine_stock() {
        $data['page_title'] = 'COVID Vaccine Stock Analysis Dashboard';
        $from = $this->input->post("from_date");
        $to = $this->input->post("to_date");
        if (empty($from)) {
            $from = date('2021-01-01');
            $to = date('Y-m-d');
        }
        $data['from_date'] = $from;
        $data['to_date'] = $to;
//        $prov_id = $this->session->userdata('province_id');
        if($this->immunization_model->is_request_from_mobile())
        {
        $data['is_mobile'] = 'Yes';
        }
        else{
          $data['is_mobile'] = 'No';
        }
        $data['reverse_logistics_analysis'] = $this->immunization_model->reverse_logistics_analysis($from, $to);
        $data['total_vaccination'] = $this->immunization_model->total_vaccination($from, $to);
        $data['daily_vaccination'] = $this->immunization_model->daily_vaccination($from, $to);
        $data['daily_vaccination_1'] = $this->immunization_model->daily_vaccination_1($from, $to);
        $data['reverse_logistics_activity'] = $this->immunization_model->reverse_logistics_activity($from, $to);
        $data['vaccine_wise_stock_received'] = $this->immunization_model->vaccine_wise_stock_received($from, $to);
        $data['covid_vaccine_received'] = $this->immunization_model->covid_vaccine_received($from, $to);
        $data['govt_procured_breakup'] = $this->immunization_model->govt_procured_breakup($from, $to);
        $data['region_vaccine_breakup'] = $this->immunization_model->region_vaccine_breakup($from, $to);
        $data['covax_facility_breakup'] = $this->immunization_model->covax_facility_breakup($from, $to);
        $data['donation_breakup'] = $this->immunization_model->donation_breakup($from, $to);
        $data['covax_usg_breakup'] = $this->immunization_model->covax_usg_breakup($from, $to); 
        $data['covax_chinese_breakup'] = $this->immunization_model->covax_chinese_breakup($from, $to); 
        $data['covax_western_breakup'] = $this->immunization_model->covax_western_breakup($from, $to);  
        $data['covax_region_breakup'] = $this->immunization_model->covax_region_breakup($from, $to);
        $data['yearly_comp'] = $this->immunization_model->yearly_comp();

        //        echo '<pre>'; print_r($data);exit;
        $data['main_content'] = $this->load->view('immunization/index', $data, TRUE);
        $this->load->view('theme/main', $data);
    }

}

?>
