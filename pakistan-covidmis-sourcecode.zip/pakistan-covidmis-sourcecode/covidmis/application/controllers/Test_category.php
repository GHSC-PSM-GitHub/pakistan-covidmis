<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_category extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Test_category_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// constructor function end

	public function index(){
		$data['page_title'] = 'Test Categories';
		$data['test_categories'] = $this->Test_category_model->all();
		$data['main_content'] = $this->load->view('test_category/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function

	public function create(){
		$this->form_validation->set_rules('name', 'Test Category', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'Test Categories';
			$data['main_content'] = $this->load->view('test_category/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'name' => $this->input->post('name'),
				'status'        => 1,
			);
			$this->Test_category_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'test_category/index');
		}
	}// end create function

	public function edit($id=''){
		$this->form_validation->set_rules('name', 'Test Category', 'required');
		if ($this->form_validation->run() == false) {
			$test_category = $this->Test_category_model->getTestCategory($id);
			if (!empty($test_category[0]['id'])) {
				$data = array(
					'test_category' => $test_category,
				);
				$data['page_title'] = 'Test Categories';
				$data['main_content'] = $this->load->view('test_category/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'test_category/index');
			}
		}else{
			$formArray = array(
				'name' => $this->input->post('name'),
			);
			$this->Test_category_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'test_category/index');
		}
	}// end edit function

	public function delete($id){
		$this->Test_category_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'test_category/index');
	}//end delete function
}// end Test_category class