<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Data_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
		date_default_timezone_set('Asia/Karachi');
	}// end __construct function

	public function index(){
		$data['page_title'] = 'Test & Cases';
		$data['test_and_cases'] = $this->Data_model->all();
		$data['main_content'] = $this->load->view('data/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function

	public function create(){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'Test & Cases';
			$data['provinces'] = $this->Data_model->getProvinces();
			$data['main_content'] = $this->load->view('data/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'date'                   => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'            => $this->input->post('province_id'),
				'pcr_in_last_24_hours'   => $this->input->post('pcr_in_last_24_hours'),
				'rapid_in_last_24_hours' => $this->input->post('rapid_in_last_24_hours'),
				'status'                 => 1,
			);
			$this->Data_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'data/index');
		}
	}// end create function

	public function edit($id=''){
		$this->form_validation->set_rules('date', 'Date as of today', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$test_and_case = $this->Data_model->getDataById($id);
			if (!empty($test_and_case[0]['id'])) {
				$data = array(
					'test_and_case' => $test_and_case,
				);
				$data['page_title'] = 'Test & Cases';
				$data['provinces'] = $this->Data_model->getProvinces();
				$data['main_content'] = $this->load->view('data/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'data/index');
			}
		}else{
			$formArray = array(
				'date'                   => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'            => $this->input->post('province_id'),
				'pcr_in_last_24_hours'   => $this->input->post('pcr_in_last_24_hours'),
				'rapid_in_last_24_hours' => $this->input->post('rapid_in_last_24_hours'),
			);
			$this->Data_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'data/index');
		}
	}// end edit function

	public function delete($id){
		$this->Data_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'data/index');
	}//end delete function
}// end Data Class