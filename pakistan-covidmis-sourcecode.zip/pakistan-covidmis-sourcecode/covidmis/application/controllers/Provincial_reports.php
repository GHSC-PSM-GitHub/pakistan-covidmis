<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Provincial_reports extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Provincial_report_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// end __construct function

	public function index(){
		$data['page_title']   = 'Provincial Report';
		$data['date'] = date('Y-m-d', strtotime($this->input->post('date')));
		$test_and_cases = $this->Provincial_report_model->getTestAndCasesProvincialData($data['date']);
		$cases = $this->Provincial_report_model->getCasesProvincialData($data['date']);
		$death_and_suspects = $this->Provincial_report_model->getDeathAndSuspectProvincialData($data['date']);
		$clinical_status = $this->Provincial_report_model->getClinicalStatusProvincialData($data['date']);
		$hcps = $this->Provincial_report_model->getHCPProvincialData($data['date']);
		$hcp_details = $this->Provincial_report_model->getHCPDetailsProvincialData($data['date']);
		$i=$j=$k=$l=$m=$n=$index=0;
		for (; (!empty($test_and_cases[$i]['id']) || !empty($cases[$j]['id']) || !empty($death_and_suspects[$k]['id']) || !empty($clinical_status[$l]['id']) || !empty($hcps[$m]['id']) || !empty($hcp_details[$n]['id'])) ; ) { 
			if (!empty($test_and_cases[$i]['id'])) {
				$date = $test_and_cases[$i]['date'];
				$province_id = $test_and_cases[$i]['province_id'];
			}elseif(!empty($cases[$j]['id'])){
				$date = $cases[$j]['date'];
				$province_id = $cases[$j]['province_id'];
			}elseif(!empty($death_and_suspects[$k]['id'])){
				$date = $death_and_suspects[$k]['date'];
				$province_id = $death_and_suspects[$k]['province_id'];
			}elseif (!empty($clinical_status[$l]['id'])) {
				$date = $clinical_status[$l]['date'];
				$province_id = $clinical_status[$l]['province_id'];
			}elseif(!empty($hcps[$m]['id'])){
				$date = $hcps[$m]['date'];
				$province_id = $hcps[$m]['province_id'];
			}elseif(!empty($hcp_details[$n]['id'])){
				$date = $hcp_details[$n]['date'];
				$province_id = $hcp_details[$n]['province_id'];
			}

			if (!empty($test_and_cases[$i]['id']) && $test_and_cases[$i]['date'] === $date  && $test_and_cases[$i]['province_id'] === $province_id) {
				$data['final_data'][$index] = $test_and_cases[$i];
				++$i;
			}else{
				$data['final_data'][$index]['pcr_till_yesterday'] = 0;
				$data['final_data'][$index]['pcr_in_last_24_hours'] = 0;
				$data['final_data'][$index]['rapid_till_yesterday'] = 0;
				$data['final_data'][$index]['rapid_in_last_24_hours'] = 0;
			}

			if (!empty($cases[$j]['id']) && $cases[$j]['date'] == $date  && $cases[$j]['province_id'] == $province_id) {
				$data['final_data'][$index] = array_merge($cases[$j], $data['final_data'][$index]);
				++$j;
			}else{
				$data['final_data'][$index]['pcases_till_yesterday'] = 0;
				$data['final_data'][$index]['pcases_in_last_24_hours'] = 0;
				$data['final_data'][$index]['acases_till_yesterday'] = 0;
				$data['final_data'][$index]['acases_in_last_24_hrs'] = 0;
			}

			if (!empty($death_and_suspects[$k]['id']) && $death_and_suspects[$k]['date'] == $date  && $death_and_suspects[$k]['province_id'] == $province_id) {
				$data['final_data'][$index] = array_merge($death_and_suspects[$k], $data['final_data'][$index]);
				++$k;
			}else{
				$data['final_data'][$index]['death_till_yesterday'] = 0;
				$data['final_data'][$index]['death_in_last_24_hours'] = 0;
				$data['final_data'][$index]['died_in_hospital_on_ventilator'] = 0;
				$data['final_data'][$index]['died_in_hospital_off_ventilator'] = 0;
				$data['final_data'][$index]['died_at_home_or_elsewhere'] = 0;
				$data['final_data'][$index]['suspect_contacts_of_known_covid_pts'] = 0;
				$data['final_data'][$index]['others_suspected'] = 0;
				$data['final_data'][$index]['suspect_till_yesterday'] = 0;
				$data['final_data'][$index]['suspects_in_last_24_hrs'] = 0;
			}

			if (!empty($clinical_status[$l]['id']) && $clinical_status[$l]['date'] == $date  && $clinical_status[$l]['province_id'] == $province_id) {
				$data['final_data'][$index] = array_merge($clinical_status[$l], $data['final_data'][$index]);
				++$l;
			}else{
				$data['final_data'][$index]['beds_for_covid_patients'] = 0;
				$data['final_data'][$index]['hospitals_for_covid_isolation'] = 0;
				$data['final_data'][$index]['oxygen_beds_facility_for_covid_patients'] = 0;
				$data['final_data'][$index]['vantilators_for_covid_patients'] = 0;
				$data['final_data'][$index]['admitted_in_last_24_hours'] = 0;
				$data['final_data'][$index]['covid_patients_currently_admitted'] = 0;
				$data['final_data'][$index]['patients_clinically_stable'] = 0;
				$data['final_data'][$index]['patients_on_low_flow_oxygen'] = 0;
				$data['final_data'][$index]['patients_on_high_flow_oxygen'] = 0;
				$data['final_data'][$index]['patients_on_ventilator'] = 0;
				$data['final_data'][$index]['patients_in_quarantine'] = 0;
				$data['final_data'][$index]['patients_recovered_and_discharged'] = 0;
				$data['final_data'][$index]['total_deaths_today'] = 0;
			}

			if (!empty($hcps[$m]['id']) && $hcps[$m]['date'] == $date  && $hcps[$m]['province_id'] == $province_id) {
				$data['final_data'][$index] = array_merge($hcps[$m], $data['final_data'][$index]);
				++$m;
			}else{
				$data['final_data'][$index]['total_doctors'] = 0;
				$data['final_data'][$index]['total_nurses'] = 0;
				$data['final_data'][$index]['other_health_staff'] = 0;
				$data['final_data'][$index]['total_infected'] = 0;
				$data['final_data'][$index]['total_in_isolation'] = 0;
				$data['final_data'][$index]['total_in_hospital'] = 0;
				$data['final_data'][$index]['total_stable'] = 0;
				$data['final_data'][$index]['total_on_ventilator'] = 0;
				$data['final_data'][$index]['total_recovered_or_discharged'] = 0;
				$data['final_data'][$index]['total_died'] = 0;
			}

			if (!empty($hcp_details[$n]['id']) && $hcp_details[$n]['date'] == $date  && $hcp_details[$n]['province_id'] == $province_id) {
				$data['final_data'][$index] = array_merge($hcp_details[$n], $data['final_data'][$index]);
				++$n;
			}else{
				$data['final_data'][$index]['confirmed_cases_of_workers'] = 0;
				$data['final_data'][$index]['performing_duties'] = 0;
				$data['final_data'][$index]['performing_duties_elsewhere'] = 0;
				$data['final_data'][$index]['contacts_identified'] = 0;
				$data['final_data'][$index]['contacts_in_quarantine'] = 0;
				$data['final_data'][$index]['contacts_tested_today'] = 0;
				$data['final_data'][$index]['results_received'] = 0;
				$data['final_data'][$index]['contacts_found_positive'] = 0;
				$data['final_data'][$index]['results_awaited'] = 0;
			}
			$index++;
		}
		$data['main_content'] = $this->load->view('provincial_reports/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function
}// end Provincial_reports class