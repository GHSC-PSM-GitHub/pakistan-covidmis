<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Province extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Province_model');
		$this->load->library('encryption');
		// echo $this->session->has_userdata('id');die;
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// constructor function end

	public function index(){
		$data['page_title'] = 'Provinces';
		$data['provinces'] = $this->Province_model->all();
		$data['main_content'] = $this->load->view('province/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}//end index function

	public function create(){
		$this->form_validation->set_rules('province', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'Province';
			$data['main_content'] = $this->load->view('province/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'province' => $this->input->post('province'),
				'status'   => 1,
			);
			$this->Province_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'province/index');
		}
	}//end create function

	public function edit($id=''){
		$this->form_validation->set_rules('province', 'Province', 'required');
		if ($this->form_validation->run() == false) {
			$province = $this->Province_model->getProvince($id);
			if (!empty($province[0]['id'])) {
				$data = array(
					'province' => $province,
				);
				$data['page_title'] = 'Province';
				$data['main_content'] = $this->load->view('province/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'province/index');
			}
		}else{
			$formArray = array(
				'province' => $this->input->post('province'),
			);
			$this->Province_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'province/index');
		}
	}//end edit function

	public function delete($id){
		$this->Province_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'province/index');
	}//end delete function
}//end Province Class