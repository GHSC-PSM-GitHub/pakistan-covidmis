<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Situations extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Situation_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// end __construct function

	public function index(){
		$data['page_title']   = 'Situations (Table 4)';
		$data['situations']   = $this->Situation_model->all();
		$data['main_content'] = $this->load->view('situations/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}// end index function

	public function create(){
		$this->form_validation->set_rules('date', 'Date', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		$this->form_validation->set_rules('district_id', 'District', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'Situation (Table 4)';
			$data['provinces'] = $this->Situation_model->getProvinces();
			$data['main_content'] = $this->load->view('situations/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'date'                 => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'          => $this->input->post('province_id'),
				'district_id'          => $this->input->post('district_id'),
				'covid_test_in_last_24_hrs'    => $this->input->post('covid_test_in_last_24_hrs'),
				'confirm_cases_in_last_24_hrs' => $this->input->post('confirm_cases_in_last_24_hrs'),
				's_in_quarantine'              => $this->input->post('s_in_quarantine'),
				's_admitted_in_hospital'       => $this->input->post('s_admitted_in_hospital'),
				's_clinically_stable'          => $this->input->post('s_clinically_stable'),
				's_on_low_flow_oxygen'         => $this->input->post('s_on_low_flow_oxygen'),
				's_on_high_flow_oxygen'        => $this->input->post('s_on_high_flow_oxygen'),
				's_on_ventilator'              => $this->input->post('s_on_ventilator'),
				's_of_new_patients_admitted_in_hospital' => $this->input->post('s_of_new_patients_admitted_in_hospital'),
				's_in_last_24_hrs' => $this->input->post('s_in_last_24_hrs'),
				'cumulative'       => $this->input->post('cumulative'),
				'status'           => 1,
			);
			$this->Situation_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'situations/index');
		}
	}//end create function

	public function edit($id=''){
		$this->form_validation->set_rules('date', 'Date', 'required');
		$this->form_validation->set_rules('province_id', 'Province', 'required');
		$this->form_validation->set_rules('district_id', 'District', 'required');
		if ($this->form_validation->run() == false) {
			$situation = $this->Situation_model->getDataById($id);
			if (!empty($situation[0]['id'])) {
				$data = array(
					'situation' => $situation,
				);
				$data['page_title'] = 'Situation (Table 4)';
				$data['provinces'] = $this->Situation_model->getProvinces();
				$data['districts'] = $this->Situation_model->getDistrictsById($situation[0]['province_id']);
				$data['main_content'] = $this->load->view('situations/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'situations/index');
			}
		}else{
			$formArray = array(
				'date'                 => date('Y-m-d', strtotime($this->input->post('date'))),
				'province_id'          => $this->input->post('province_id'),
				'district_id'          => $this->input->post('district_id'),
				'covid_test_in_last_24_hrs'    => $this->input->post('covid_test_in_last_24_hrs'),
				'confirm_cases_in_last_24_hrs' => $this->input->post('confirm_cases_in_last_24_hrs'),
				's_in_quarantine'              => $this->input->post('s_in_quarantine'),
				's_admitted_in_hospital'       => $this->input->post('s_admitted_in_hospital'),
				's_clinically_stable'          => $this->input->post('s_clinically_stable'),
				's_on_low_flow_oxygen'         => $this->input->post('s_on_low_flow_oxygen'),
				's_on_high_flow_oxygen'        => $this->input->post('s_on_high_flow_oxygen'),
				's_on_ventilator'              => $this->input->post('s_on_ventilator'),
				's_of_new_patients_admitted_in_hospital' => $this->input->post('s_of_new_patients_admitted_in_hospital'),
				's_in_last_24_hrs' => $this->input->post('s_in_last_24_hrs'),
				'cumulative'       => $this->input->post('cumulative'),
			);
			$this->Situation_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'situations/index');
		}
	}// end edit function

	public function delete($id){
		$this->Situation_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'situations/index');
	}//end delete function
}// end Situations class