<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Dashboard_model');
		$this->load->library('encryption');
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// constructor function end

//	public function index(){
//		$data['page_title'] = 'Dashboard';
//		$data['main_content'] = $this->load->view('dashboard/dashboard', $data, TRUE);
//		$this->load->view('theme/main', $data);
//	}// end index function

	public function dashboard_data(){
		$total_test_cases = $this->Dashboard_model->getTotalTestCases();
		$total_confirm_cases = $this->Dashboard_model->getTotalConfirmCases();
		$data['pcr'] = '["'.((!empty($total_test_cases[0]['pcr_in_last_24_hours']))?$total_test_cases[0]['pcr_in_last_24_hours']:0).'", "';
		$data['pcr'] .= ((!empty($total_confirm_cases[0]['pcases_in_last_24_hours']))?$total_confirm_cases[0]['pcases_in_last_24_hours']:0).'", "';
		$data['pcr'] .= (((!empty($total_test_cases[0]['pcr_in_last_24_hours']))?$total_test_cases[0]['pcr_in_last_24_hours']:0) - ((!empty($total_confirm_cases[0]['pcases_in_last_24_hours']))?$total_confirm_cases[0]['pcases_in_last_24_hours']:0)).'"]';
		echo "<pre>";
		var_dump($data);die;
	}// end get_districts function

	public function get_districts(){
		$province_id = $this->input->post('province_id');
		$data['districts'] = $this->Dashboard_model->getDistricts($province_id);
		if (!empty($data['districts'][0]['pk_id'])) {
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}// end get_districts function
        
//        --------------------  ID DASHBOARD START  ----------------------------------
        public function index()
	{
//            print_r($_SESSION); exit;
            $data['page_title'] = 'Infectious Diseases Dashboard';

			$from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m', strtotime('-5 month'));
				$to = date('Y-m');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;
			$prov_id = $this->session->userdata('province_id');

			$data['disease_wise_data'] = $this->Dashboard_model->disease_wise_data($from, $to, $prov_id);
			$data['province_wise_data'] = $this->Dashboard_model->province_wise_data($from, $to, $prov_id);
			$data['disease_trend'] = $this->Dashboard_model->disease_trend($from, $to, $prov_id);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('dashboard/dashboard', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
        
	public function focused_diseases()
	{
            $data['page_title'] = 'Focused Diseases';
			$from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m', strtotime('-5 month'));
				$to = date('Y-m');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;
			$prov_id = $this->session->userdata('province_id');

			$data['disease_wise_data'] = $this->Dashboard_model->focused_disease_data($from, $to, $prov_id);
			$data['province_wise_data'] = $this->Dashboard_model->focused_province_wise($from, $to, $prov_id);
			$data['disease_trend'] = $this->Dashboard_model->focused_trend($from, $to, $prov_id);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('dashboard/focused_diseases', $data, TRUE);
			$this->load->view('theme/main', $data);
		
                         	}
                                
//         xxxxxxxxxxxxxxxxxxxxxx Province Drilldown Function Start xxxxxxxxxxxxxxxxxxxxxxxxx                       
        public function province_drill($label = NULL, $from_date = NULL, $to_date = NULL)
	{
//         echo $label; exit;
		$from = $from_date;
		$to = $to_date;
//         $from = date('Y-m-01', strtotime('-1 month'));
//            $to = date('Y-m-d');
		$label = str_replace('%20', ' ', $label);
		$label_id = $this->Dashboard_model->province_id($label);
		$label_id = $label_id[0]['pk_id'];
                $prov_id = $label_id;
		$data['label'] = $label;
                $data['disease_wise_data'] = $this->Dashboard_model->prov_drill_disease($from, $to, $prov_id);
                $data['disease_trend'] = $this->Dashboard_model->prov_drill_trend($from, $to, $prov_id);
		$data['from'] = $from_date;
		$data['to'] = $to_date;
		$data['label_id'] = $label_id;
//        echo '<pre>'; print_r($data); exit;
		$data['main_content'] = $this->load->view('dashboard/drill_lvl_1', $data, TRUE);
		$this->load->view('theme/main', $data);
	}
//         xxxxxxxxxxxxxxxxxxxxxx Province Drilldown Function END xxxxxxxxxxxxxxxxxxxxxxxxx
        
//         xxxxxxxxxxxxxxxxxxxxxx Disease Drilldown Function Start xxxxxxxxxxxxxxxxxxxxxxxxx
        public function disease_drill($label = NULL, $from_date = NULL, $to_date = NULL)
	{
        $url = parse_url($_SERVER['REQUEST_URI']);
        parse_str($url['query'], $params);
        $label = $params['label'];
        
            $from = $params['from_date'];
		$to = $params['to_date'];
//         $from = date('Y-m', strtotime('-4 month'));
//            $to = date('Y-m');
		$label = str_replace('%20', ' ', $label);
//		$label_id = $this->dashboard_model->province_id($label);
//		$label_id = $label_id[0]['pk_id'];
                $prov_id = $label;
		$data['label'] = $label;
                $data['disease_wise_data'] = $this->Dashboard_model->disease_drill_prov($from, $to, $prov_id);
                $data['disease_trend'] = $this->Dashboard_model->disease_drill_trend($from, $to, $prov_id);
		$data['from'] = $from_date;
		$data['to'] = $to_date;
//		$data['label_id'] = $label_id;
//        echo '<pre>'; print_r($data); exit;
		$data['main_content'] = $this->load->view('dashboard/drill_lvl_2', $data, TRUE);
		$this->load->view('theme/main', $data);
	}

//         xxxxxxxxxxxxxxxxxxxxxx Disease Drilldown Function END xxxxxxxxxxxxxxxxxxxxxxxxx   
        
//         xxxxxxxxxxxxxxxxxxxxxx Province Drilldown Function Start xxxxxxxxxxxxxxxxxxxxxxxxx                       
        public function focused_drill_prov($label = NULL, $from_date = NULL, $to_date = NULL)
	{
//         echo $label; exit;
		$from = $from_date;
		$to = $to_date;
//         $from = date('Y-m-01', strtotime('-1 month'));
//            $to = date('Y-m-d');
		$label = str_replace('%20', ' ', $label);
		$label_id = $this->Dashboard_model->province_id($label);
		$label_id = $label_id[0]['pk_id'];
                $prov_id = $label_id;
		$data['label'] = $label;
                $data['disease_wise_data'] = $this->Dashboard_model->foc_prov_drill_disease($from, $to, $prov_id);
                $data['disease_trend'] = $this->Dashboard_model->foc_prov_drill_trend($from, $to, $prov_id);
		$data['from'] = $from_date;
		$data['to'] = $to_date;
		$data['label_id'] = $label_id;
//        echo '<pre>'; print_r($data); exit;
		$data['main_content'] = $this->load->view('dashboard/foc_prov_drill', $data, TRUE);
		$this->load->view('theme/main', $data);
	}
//         xxxxxxxxxxxxxxxxxxxxxx Province Drilldown Function END xxxxxxxxxxxxxxxxxxxxxxxxx
        
//        xxxxxxxxxxxxxxxxxxxxxxxxxxxx COVID DASHBOARD START    xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        
         public function vent_map()
	{ 
//             echo 'hello'; exit;
            $data['page_title'] = 'Ventilators Map';
            $prod = $this->input->post("prod");
            if(empty($prod))
            {
                $prod = 3754;
            }
            $data['prod'] = $prod;
			 $data['product'] = $this->Dashboard_model->products();
                        $data['dist_stock'] = $this->Dashboard_model->dist_stock($prod);
                         $data['result'] = $this->Dashboard_model->main_query();
			$data['main_content'] = $this->load->view('covid_dashboard/vent_map', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
        
        public function covid()
	{
            $data['page_title'] = 'COVID Dashboard';
			$from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m-01', strtotime('-2 month'));
				$to = date('Y-m-d');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;
			$prov_id = $this->session->userdata('province_id');
                        $data['total_tests'] = $this->Dashboard_model->getTotalTestCases_1($from, $to, $prov_id);
                        $data['total_positive'] = $this->Dashboard_model->getTotalConfirmCases_1($from, $to, $prov_id);
			$data['vents_data'] = $this->Dashboard_model->vents_data($from, $to, $prov_id);
			$data['deaths_data'] = $this->Dashboard_model->death_data($from, $to, $prov_id);
			$data['positive_cases'] = $this->Dashboard_model->positive_cases_province($from, $to, $prov_id);
                        $data['oxygen_beds'] = $this->Dashboard_model->oxygen_beds($from, $to, $prov_id);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('covid_dashboard/covid', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
        
          public function vent_drill($label = NULL, $from_date = NULL, $to_date = NULL)
	{
//              echo $label; exit;
			$data['from_date'] = $from_date;
			$data['to_date'] = $to_date;
                        $data['label'] = $label;
			$data['vents_drill'] = $this->Dashboard_model->vent_drill($from_date, $to_date,$label);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('covid_dashboard/vent_drill', $data, TRUE);
			$this->load->view('theme/main', $data);
	}

         public function vent_drill_district($label = NULL, $from_date = NULL, $to_date = NULL, $label2 = NULL) 
         {
        $from_date = explode("%", $from_date);
        $from_date = $from_date[0];
        $to_date = explode("%", $to_date);
        $to_date = $to_date[0];
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
        $data['label'] = $label;
        $data['label2'] = $label2;
        $label_id = $this->Dashboard_model->province_id($label);
        $label_id = $label_id[0]['pk_id'];
        $data['vents_drill'] = $this->Dashboard_model->vent_drill_districtwise($from_date, $to_date, $label_id, $label2);
        //        echo '<pre>'; print_r($data);exit;
        $data['main_content'] = $this->load->view('covid_dashboard/vent_drill_district', $data, TRUE);
        $this->load->view('theme/main', $data);
    }
    
     public function vent_drill_hf($label = NULL, $from_date = NULL, $to_date = NULL, $label2 = NULL) 
         {
//        $from_date = explode("%", $from_date);
//        $from_date = $from_date[0];
//        $to_date = explode("%", $to_date);
//        $to_date = $to_date[0];
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
        $data['label'] = $label;
//        $data['label2'] = $label2;
//        $label_id = $this->dashboard_model->province_id($label);
//        $label_id = $label_id[0]['pk_id'];
//        $data['vents_drill'] = $this->dashboard_model->vent_drill_districtwise($from_date, $to_date, $label_id, $label2);
        //        echo '<pre>'; print_r($data);exit;
        $data['main_content'] = $this->load->view('covid_dashboard/vent_drill_hf', $data, TRUE);
        $this->load->view('theme/main', $data);
    }
    
         public function positive_drill($label = NULL, $from_date = NULL, $to_date = NULL)
	{
             $label = str_replace('%20', ' ', $label);
            $label_id = $this->Dashboard_model->province_id($label);
        $label_id = $label_id[0]['pk_id'];
			$data['from_date'] = $from_date;
			$data['to_date'] = $to_date;
                        $data['label'] = $label;
			$data['positive_drill'] = $this->Dashboard_model->positive_cases_dist($from_date, $to_date,$label_id);
			$data['main_content'] = $this->load->view('covid_dashboard/positive_cases_drill', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
        
           public function bed_drill($label = NULL, $from_date = NULL, $to_date = NULL)
	{
//              echo $label; exit;
			$data['from_date'] = $from_date;
			$data['to_date'] = $to_date;
                        $data['label'] = $label;
			$data['bed_drill'] = $this->Dashboard_model->bed_drill($from_date, $to_date,$label);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('covid_dashboard/bed_drill_prov', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
                public function bed_drill_district($label = NULL, $from_date = NULL, $to_date = NULL, $label2 = NULL) 
         {
                    $label = str_replace('%20', ' ', $label);
        $from_date = explode("%", $from_date);
        $from_date = $from_date[0];
        $to_date = explode("%", $to_date);
        $to_date = $to_date[0];
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
        $data['label'] = $label;
        $data['label2'] = $label2;
        $label_id = $this->Dashboard_model->province_id($label);
        $label_id = $label_id[0]['pk_id'];
        $data['bed_drill'] = $this->Dashboard_model->bed_drill_districtwise($from_date, $to_date, $label_id, $label2);
        //        echo '<pre>'; print_r($data);exit;
        $data['main_content'] = $this->load->view('covid_dashboard/bed_drill_district', $data, TRUE);
        $this->load->view('theme/main', $data);
    }
    
     public function age_drill($label = NULL, $from_date = NULL, $to_date = NULL, $label2 = NULL) 
         {
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
        $data['label'] = $label;
        $data['main_content'] = $this->load->view('covid_dashboard/age_drill', $data, TRUE);
        $this->load->view('theme/main', $data);
    }

       public function death_drill_prov($label = NULL, $from_date = NULL, $to_date = NULL, $label2 = NULL) 
         {
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
        $data['label'] = $label;
        $data['main_content'] = $this->load->view('covid_dashboard/death_drill_prov', $data, TRUE);
        $this->load->view('theme/main', $data);
    }
       public function death_drill_dist($label = NULL, $from_date = NULL, $to_date = NULL, $label2 = NULL) 
         {
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
        $data['label'] = $label;
        $data['main_content'] = $this->load->view('covid_dashboard/death_drill_dist', $data, TRUE);
        $this->load->view('theme/main', $data);
    }
//    xxxxxxxxxxxxxxxxxxxxxxxxxxxxx  COVID DASHBOARD END  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    
//    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  VACCINATION DASHBOARD SATRT   xxxxxxxxxxxxxxxxxxxxxxxxxx
       public function vaccination()
	{
           $data['page_title'] = 'Vaccination Status';
			$from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m-01', strtotime('-2 month'));
				$to = date('Y-m-d');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;
			$prov_id = $this->session->userdata('province_id');
                        $data['total_tests'] = $this->Dashboard_model->getTotalTestCases_1($from, $to, $prov_id);
                        $data['total_positive'] = $this->Dashboard_model->getTotalConfirmCases_1($from, $to, $prov_id);
			$data['vents_data'] = $this->Dashboard_model->vents_data($from, $to, $prov_id);
			$data['deaths_data'] = $this->Dashboard_model->death_data($from, $to, $prov_id);
			$data['positive_cases'] = $this->Dashboard_model->positive_cases_province($from, $to, $prov_id);
                        $data['oxygen_beds'] = $this->Dashboard_model->oxygen_beds($from, $to, $prov_id);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('covid_dashboard/vaccination', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
//    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  VACCINATION DASHBOARD END     xxxxxxxxxxxxxxxxxxxxxxxxxx
    
//    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  SNAPSHOt START   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        public function covid_snapshot()
	{
            $data['page_title'] = 'COVID Snapshot';
			$from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m-01', strtotime('-2 month'));
				$to = date('Y-m-d');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;
			$prov_id = $this->session->userdata('province_id');
                        $data['total_tests'] = $this->Dashboard_model->getTotalTestCases_1($from, $to, $prov_id);
                        $data['total_positive'] = $this->Dashboard_model->getTotalConfirmCases_1($from, $to, $prov_id);
			$data['vents_data'] = $this->Dashboard_model->vents_data($from, $to, $prov_id);
			$data['deaths_data'] = $this->Dashboard_model->death_data($from, $to, $prov_id);
			$data['positive_cases'] = $this->Dashboard_model->positive_cases_province($from, $to, $prov_id);
                        $data['oxygen_beds'] = $this->Dashboard_model->oxygen_beds($from, $to, $prov_id);
                        $data['patient_summary'] = $this->Dashboard_model->patient_summary($from, $to, $prov_id);
			//        echo '<pre>'; print_r($data);exit;
			$data['main_content'] = $this->load->view('covid_dashboard/snapshot', $data, TRUE);
			$this->load->view('theme/main', $data);
	}
       

//    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  SNAPSHOt START   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx      
//        ----------------------  ID DASHBOARD END    ----------------------------------
        
        
}// end Dashboard class