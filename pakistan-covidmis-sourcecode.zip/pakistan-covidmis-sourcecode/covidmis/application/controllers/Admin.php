<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
//        check_login_user();
        $this->load->helper('url');
        $this->load->model('Admin_model');
//        $this->load->model('Html_to_doc');
        if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
    }

    public function index() {

        $data = array();
        $data['page_title'] = 'Daily Vaccination';
        $from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m-01', strtotime('-2 month'));
				$to = date('Y-m-d');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;
        $data['page_title'] = 'Vaccination Data';
        $data['display'] = $this->Admin_model->displayproduct($from,$to);
//        $this->load->view('admin/product_management', $data);
        $data['main_content'] = $this->load->view('admin/daily_vaccination', $data, TRUE);
			$this->load->view('theme/main', $data);
    }

    public function save_data() {
        $this->load->model("Admin_model");
        $data = array(
            "date" => $this->input->post("date"),
            "first_dose" => $this->input->post("first_dose"),
            "full_vaccinated" => $this->input->post("full_vaccinated"),
              "booster_1" => $this->input->post("booster_1"),
              "booster_2" => $this->input->post("booster_2"),
        );
        if ($this->input->post('save')) {
            $this->Admin_model->savemproduct($data);
            redirect(base_url().'admin/index');
        }
        if ($this->input->post("hidden_id")) {
//             echo 'hello'; exit;
            $this->Admin_model->edit_product($data, $this->input->post("hidden_id"));
            redirect(base_url().'admin/index');
        }
    }

    public function update_data($sid = 0) {

        $data = array();
        $data['page_title'] = 'Daily Vaccination';
        $from = $this->input->post("from_date");
			$to = $this->input->post("to_date");
			if (empty($from)) {
				$from = date('Y-m-01', strtotime('-2 month'));
				$to = date('Y-m-d');
			}
			$data['from_date'] = $from;
			$data['to_date'] = $to;
        $data['page_title'] = 'Vaccination Data';
        $data["fetch_data"] = $this->Admin_model->fetch_product($sid);
        $data['display'] = $this->Admin_model->displayproduct($from,$to);
//        $this->load->view('admin/product_management', $data);
          $data['main_content'] = $this->load->view('admin/daily_vaccination', $data, TRUE);
			$this->load->view('theme/main', $data);
    }

   
//    ************************************************** Product MANAGEMENT END***********************************************************************    
    

}
