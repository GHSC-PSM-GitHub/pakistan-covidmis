<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('Login_model');
		$this->load->library('encryption');
	}// end __construct function

	public function index(){
		$this->load->view('theme/authentication');
	}// end index function

	public function login(){
		$username = $this->input->get_post('username');
		$password = md5($this->input->get_post('password'));
		$user = $this->Login_model->login($username, $password);               
		if(!empty($user[0])){
                    //print_r($user); exit;
			$this->session->set_userdata($user[0]);
			$this->session->set_flashdata('success', 'User login Successfully!...');
			redirect(base_url().'immunization/vaccine_stock');
		}else{
			$this->session->set_flashdata('danger', 'Please Enter Valid email & password!...');
			redirect(base_url().'welcome/index');
		}
	}// end login function

	public function logout(){
		$this->session->sess_destroy();
		redirect(base_url().'welcome/index');
	}// end logout function
}// end Welcome Class