<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Districts extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('District_model');
		$this->load->library('encryption');
		// echo $this->session->has_userdata('id');die;
		if (!$this->session->has_userdata('pk_id')) {
			redirect(base_url().'welcome/index');
		}
	}// constructor function end

	public function index(){
		$data['page_title'] = 'Districts';
		$data['districts'] = $this->District_model->all();
		$data['main_content'] = $this->load->view('districts/index', $data, TRUE);
		$this->load->view('theme/main', $data);
	}//end index function

	public function create(){
		$this->form_validation->set_rules('name', 'Name', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'District';
			$data['provinces'] = $this->District_model->getProvinces();
			$data['main_content'] = $this->load->view('districts/create', $data, TRUE);
			$this->load->view('theme/main', $data);
		}else{
			$formArray = array(
				'location_name'        => $this->input->post('name'),
				'parent_id' => $this->input->post('province_id'),
				'status'      => 1,
                            'province_id'      => $this->input->post('province_id'),
                            'geo_level_id'      => 4,
                            
			);
			$this->District_model->create($formArray);
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'districts/index');
		}
	}//end create function

	public function edit($id=''){
		$this->form_validation->set_rules('name', 'Name', 'required');
		if ($this->form_validation->run() == false) {
			$district = $this->District_model->getDistrict($id);
			if (!empty($district[0]['pk_id'])) {
				$data = array(
					'district' => $district,
				);
				$data['page_title'] = 'District';
				$data['provinces'] = $this->District_model->getProvinces();
				$data['main_content'] = $this->load->view('districts/edit', $data, TRUE);
				$this->load->view('theme/main', $data);
			}else{
				redirect(base_url().'districts/index');
			}
		}else{
			$formArray = array(
				'location_name'        => $this->input->post('name'),
				'province_id' => $this->input->post('province_id'),
                            'parent_id' => $this->input->post('province_id'),
			);
			$this->District_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'districts/index');
		}
	}//end edit function

	public function delete($id){
		$this->District_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'districts/index');
	}//end delete function
}//end Districts Class