<?php
class Data_model extends CI_model{
	
	public function create($formArray){
		$result = $this->db->get_where('test_and_cases', array('date' => $formArray['date'], 'province_id' => $formArray['province_id'], 'status' => 1))->result_array();
		if (!empty($result[0]['id'])) {
			$this->db->where('id', $result[0]['id']);
			$this->db->update('test_and_cases', $formArray);
		}else{
			$this->db->insert('test_and_cases', $formArray);
		}
	}// end create function

	public function all(){
		$this->db->select('test_and_cases.id, test_and_cases.date, locations.location_name AS province_name, test_and_cases.pcr_in_last_24_hours, test_and_cases.rapid_in_last_24_hours');
		$this->db->from('test_and_cases');
		$this->db->join('locations', 'locations.pk_id = test_and_cases.province_id');
		$this->db->where('test_and_cases.status', 1);
		$this->db->order_by('test_and_cases.id', 'DESC');
		return $this->db->get()->result_array();
	}// end all function

	public function getProvinces(){
		return $this->db->get_where('locations', array('parent_id' => 10))->result_array();
	}// end getProvinces function

	public function getTestCategories(){
		return $this->db->get_where('test_categories', array('status' => 1))->result_array();
	}// end getTestCategories function

	public function getTestTypes(){
		return $this->db->get_where('test_types', array('status' => 1))->result_array();
	}//end getTestTypes function

	public function getDataById($id){
		$data = $this->db->get_where('test_and_cases', array('id' => $id, 'status' => 1));
		return $data->result_array();
	}// end getDataById function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('test_and_cases', $formArray);
	}// end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('test_and_cases');
	}// end delete function
}// end Data_model class
?>