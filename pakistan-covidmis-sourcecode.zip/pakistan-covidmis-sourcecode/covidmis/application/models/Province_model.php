<?php
class Province_model extends CI_model{
	
	public function create($formArray){
		$this->db->insert('provinces', $formArray);
	}//end create function

	public function all(){
		return $this->db->get_where('locations' ,array('parent_id' => 10))->result_array();
	}//end all function

	public function getProvince($id){
		$province = $this->db->get_where('locations', array('pk_id' => $id, 'status' => 1));
		return $province->result_array();
	}//end getProvince function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('provinces', $formArray);
	}//end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('provinces');
	}//end delete function
}//end Province_model class
?>