<?php
class District_model extends CI_model{
	
	public function create($formArray){
		$this->db->insert('locations', $formArray);
	}//end create function

	public function all(){
		$this->db->select('dist.pk_id id,dist.location_name AS `name`,prov.location_name AS province_name ');
		$this->db->from('locations AS dist');
		$this->db->join('locations AS prov', 'dist.province_id = prov.pk_id ');
		$this->db->where('dist.geo_level_id', 4);
		return $this->db->get()->result_array();
	}//end all function

	public function getDistrict($id){
		$district = $this->db->get_where('locations', array('pk_id' => $id, 'status' => 1));
		return $district->result_array();
	}//end getDistrict function

	public function getProvinces(){
		return $this->db->get_where('locations', array('parent_id' => 10))->result_array();
	}//end getProvinces function

	public function update($id, $formArray){
		$this->db->where('pk_id', $id);
		$this->db->update('locations', $formArray);
	}//end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('districts');
	}//end delete function
}//end District_model class
?>