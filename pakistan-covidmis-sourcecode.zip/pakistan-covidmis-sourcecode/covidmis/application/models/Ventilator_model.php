<?php
class Ventilator_model extends CI_model{
	
	public function create($formArray){
		$result = $this->db->get_where('ventilators', array('date' => $formArray['date'], 'province_id' => $formArray['province_id'], 'district_id' => $formArray['district_id'], 'status' => 1))->result_array();
		if (!empty($result[0]['id'])) {
			$this->db->where('id', $result[0]['id']);
			$this->db->update('ventilators', $formArray);
		}else{
			$this->db->insert('ventilators', $formArray);
		}
	}// end create function

	public function all(){
		$this->db->select('ventilators.id, ventilators.date, locations.location_name AS province_name, dist.location_name AS district_name, ventilators.available_ventilators, ventilators.ventilators_allocated_for_covid, ventilators.ventilators_occupied_by_covid_patients, ventilators.currently_vacant_ventilators, ventilators.vacant_non_covid_vents');
		$this->db->from('ventilators');
		$this->db->join('locations', 'locations.pk_id = ventilators.province_id');
		$this->db->join('locations AS dist', 'dist.pk_id = ventilators.district_id');
		$this->db->where('ventilators.status', 1);
		$this->db->order_by('ventilators.id', "DESC");
//                $this->db->get();
//                 echo $this->db->last_query(); exit;
		return $this->db->get()->result_array();
	}// end all function

	public function getProvinces(){
		return $this->db->get_where('locations', array('parent_id' => 10))->result_array();
	}// end getProvinces function

	public function getDistricts(){
		return $this->db->get_where('districts', array('status' => 1))->result_array();
	}// end getDistricts function

	public function getDistrictsById($province_id){
		$districts = $this->db->get_where('locations', array('geo_level_id' => 4, 'parent_id' => $province_id));
		return $districts->result_array();
	}// end getDistrictsById function

	public function getTestCategories(){
		return $this->db->get_where('test_categories', array('status' => 1))->result_array();
	}// end getTestCategories function

	public function getTestTypes(){
		return $this->db->get_where('test_types', array('status' => 1))->result_array();
	}//end getTestTypes function

	public function getDataById($id){
		$data = $this->db->get_where('ventilators', array('id' => $id, 'status' => 1));
		return $data->result_array();
	}// end getDataById function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('ventilators', $formArray);
	}// end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('ventilators');
	}// end delete function
}// end ventilators_model class
?>