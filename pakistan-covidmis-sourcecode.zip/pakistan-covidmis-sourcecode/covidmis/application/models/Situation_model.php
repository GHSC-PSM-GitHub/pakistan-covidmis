<?php
class Situation_model extends CI_model{
	
	public function create($formArray){
		$result = $this->db->get_where('situations', array('date' => $formArray['date'], 'province_id' => $formArray['province_id'], 'district_id' => $formArray['district_id'], 'status' => 1))->result_array();
		if (!empty($result[0]['id'])) {
			$this->db->where('id', $result[0]['id']);
			$this->db->update('situations', $formArray);
		}else{
			$this->db->insert('situations', $formArray);
		}
	}// end create function

	public function all(){
		$this->db->select('situations.id, situations.date, locations.location_name AS province_name, dist.location_name AS district_name, situations.covid_test_in_last_24_hrs, situations.confirm_cases_in_last_24_hrs, situations.s_in_quarantine, situations.s_admitted_in_hospital, situations.s_clinically_stable, situations.s_on_low_flow_oxygen, situations.s_on_high_flow_oxygen, situations.s_on_ventilator, situations.s_of_new_patients_admitted_in_hospital, situations.s_in_last_24_hrs, situations.cumulative');
		$this->db->from('situations');
		$this->db->join('locations', 'locations.pk_id = situations.province_id');
		$this->db->join('locations AS dist', 'dist.pk_id = situations.district_id');
		$this->db->where('situations.status', 1);
		$this->db->order_by('situations.id', 'DESC');
		return $this->db->get()->result_array();
	}// end all function

	public function getProvinces(){
		return $this->db->get_where('locations', array('parent_id' => 10))->result_array();
	}// end getProvinces function

	public function getDistricts(){
		return $this->db->get_where('districts', array('status' => 1))->result_array();
	}// end getDistricts function

	public function getDistrictsById($province_id){
		$districts = $this->db->get_where('locations', array('geo_level_id' => 4, 'parent_id' => $province_id));
		return $districts->result_array();
	}// end getDistrictsById function

	public function getTestCategories(){
		return $this->db->get_where('test_categories', array('status' => 1))->result_array();
	}// end getTestCategories function

	public function getTestTypes(){
		return $this->db->get_where('test_types', array('status' => 1))->result_array();
	}//end getTestTypes function

	public function getDataById($id){
		$data = $this->db->get_where('situations', array('id' => $id, 'status' => 1));
		return $data->result_array();
	}// end getDataById function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('situations', $formArray);
	}// end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('situations');
	}// end delete function
}// end situations_model class
?>