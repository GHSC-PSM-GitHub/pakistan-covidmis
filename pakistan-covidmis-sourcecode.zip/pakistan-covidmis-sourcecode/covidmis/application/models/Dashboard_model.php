<?php
class Dashboard_model extends CI_model{
	public function getDistricts($province_id){
		$districts = $this->db->get_where('locations', array('geo_level_id' => 4, 'parent_id' => $province_id));
		return $districts->result_array();
	}// end getDistricts function

	public function getTotalTestCases(){
		$this->db->select('SUM(test_and_cases.pcr_in_last_24_hours) AS pcr_in_last_24_hours, SUM(test_and_cases.rapid_in_last_24_hours) AS rapid_in_last_24_hours');
		$this->db->from('test_and_cases');
		$this->db->where('test_and_cases.status', 1);
		return $this->db->get()->result_array();
	}// end getTotalTestCases function

	public function getTotalConfirmCases(){
		$this->db->select('SUM(cases.pcases_in_last_24_hours) AS pcases_in_last_24_hours, SUM(cases.acases_in_last_24_hrs) AS acases_in_last_24_hrs');
		$this->db->from('cases');
		$this->db->where('cases.status', 1);
		return $this->db->get()->result_array();
	}// end getTotalConfirmCases function
        
//        --------------------       ID DASHBOARD START    ---------------------------
        //    xxxxxxxxxxxxxxxxxxxxxxxxx  INFECTIOUS DISEASES DASHBOARD START  xxxxxxxxxxxxxxxxxxxxxx
    function disease_wise_data($from_date, $to_date, $prov_id) {
        $q = "SELECT
	SUM( quantity ) AS total,
	`master`.disease_name 
FROM
	`master` 
        WHERE month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
GROUP BY
	`master`.disease_name 
ORDER BY
	total DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function province_wise_data($from_date, $to_date, $prov_id) {
        $q = "SELECT
	SUM( quantity ) AS total,
	locations.location_name location 
FROM
	`master`
	INNER JOIN locations ON `master`.location_id = locations.pk_id 
          WHERE month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
GROUP BY
	`master`.location_id";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function disease_trend($from_date, $to_date, $prov_id) {
        $q = "SELECT
	`master`.disease_name,
	SUM( `master`.quantity ) AS sum,
	`master`.`month` 
FROM
	`master` 
           WHERE month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
GROUP BY
	`master`.`month`,`master`.`disease_id`
		ORDER BY
	sum DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

//    xxxxxxxxxxxxxxxxxxxxxxxxx  INFECTIOUS DISEASES DASHBOARD END  xxxxxxxxxxxxxxxxxxxxxx
//    ------------------------------------------------------------------------------------
//    xxxxxxxxxxxxxxxxxxxxxxxxx  FOCUSED DISEASES DASHBOARD START  xxxxxxxxxxxxxxxxxxxxxx
    function focused_disease_data($from_date, $to_date, $prov_id) {
        $q = "SELECT
	`master`.disease_name, 
	`master`.disease_id, 
	SUM(`master`.quantity) AS total
FROM
	`master`
	WHERE disease_id IN ('5','10','13','15','20','26','31')
        AND month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
	GROUP BY
	disease_id
ORDER BY
	total DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function focused_province_wise($from_date, $to_date, $prov_id) {
        $q = "SELECT
	SUM( quantity ) AS total,
	locations.location_name location 
FROM
	`master`
	INNER JOIN locations ON `master`.location_id = locations.pk_id 
          WHERE disease_id IN ('5','10','13','15','20','26','31')
          AND month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
GROUP BY
	`master`.location_id";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function focused_trend($from_date, $to_date, $prov_id) {
        $q = "SELECT
	`master`.disease_name,
	SUM( `master`.quantity ) AS sum,
	`master`.`month` 
FROM
	`master` 
           WHERE disease_id IN ('5','10','13','15','20','26','31')
           AND month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
GROUP BY
	`master`.`month`,`master`.`disease_id`
		ORDER BY
	sum DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

//    xxxxxxxxxxxxxxxxxxxxxxxxx  FOCUSED DISEASES DASHBOARD END  xxxxxxxxxxxxxxxxxxxxxx    
//    --------------------------------------------------------------------------------
//    xxxxxxxxxxxxxxxxxxxxxxxxx  PROVINCE DILLDOWN DASHBOARD START  xxxxxxxxxxxxxxxxxxxxxx
    function province_id($label) {
        $q = "SELECT
	locations.pk_id
FROM
	locations
WHERE
	locations.location_name = '" . $label . "'";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function prov_drill_disease($from_date, $to_date, $prov_id) {
        $q = "SELECT
	`master`.disease_name,
	SUM( `master`.quantity ) AS total
FROM
	`master` 
WHERE
	location_id = '" . $prov_id . "' 
        AND  month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
GROUP BY
	`master`.`disease_id` 
ORDER BY
	total DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function prov_drill_trend($from_date, $to_date, $prov_id) {
        $q = "SELECT
	`master`.disease_name,
	SUM( `master`.quantity ) AS sum,
	`master`.`month` 
FROM
	`master` 
           WHERE location_id = '" . $prov_id . "' 
           AND month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
GROUP BY
	`master`.`month`,`master`.`disease_id`
		ORDER BY
	sum DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

//    xxxxxxxxxxxxxxxxxxxxxxxxx  PROVINCE DILLDOWN DASHBOARD END  xxxxxxxxxxxxxxxxxxxxxx
//    xxxxxxxxxxxxxxxxxxxxxxxxx  DISEASE DILLDOWN DASHBOARD START  xxxxxxxxxxxxxxxxxxxxxx


    function disease_drill_prov($from_date, $to_date, $disease_name) {
        $q = "SELECT
	SUM(quantity) AS total, 
	`master`.disease_name, 
	locations.location_name location
FROM
	`master`
	INNER JOIN
	locations
	ON 
		`master`.location_id = locations.pk_id
WHERE
	month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "' AND
	`master`.disease_name = '" . $disease_name . "' 
GROUP BY
	`master`.location_id
ORDER BY
	total DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
       function disease_drill_trend($from_date, $to_date, $disease_name) {
        $q = "SELECT
	SUM( `master`.quantity ) AS sum,
	`master`.`month`,
	locations.location_name location 
FROM
	`master`
	INNER JOIN locations ON `master`.location_id = locations.pk_id 
WHERE
	disease_name = '" . $disease_name . "' 
	AND month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "' 
GROUP BY
	`master`.`month`,
	`master`.location_id 
ORDER BY
	sum DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    //    xxxxxxxxxxxxxxxxxxxxxxxxx  DISEASE DILLDOWN DASHBOARD END  xxxxxxxxxxxxxxxxxxxxxx
    
    //    xxxxxxxxxxxxxxxxxxxxxxxxx  FOCUSED DISEASE DILLDOWN DASHBOARD START  xxxxxxxxxxxxxxxxxxxxxx


     function foc_prov_drill_disease($from_date, $to_date, $prov_id) {
        $q = "SELECT
	`master`.disease_name,
	SUM( `master`.quantity ) AS total
FROM
	`master` 
WHERE
	location_id = '" . $prov_id . "' 
            AND disease_id IN ('5','10','13','15','20','26','31')
        AND  month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
GROUP BY
	`master`.`disease_id` 
ORDER BY
	total DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function foc_prov_drill_trend($from_date, $to_date, $prov_id) {
        $q = "SELECT
	`master`.disease_name,
	SUM( `master`.quantity ) AS sum,
	`master`.`month` 
FROM
	`master` 
           WHERE location_id = '" . $prov_id . "' 
               AND disease_id IN ('5','10','13','15','20','26','31')
           AND month BETWEEN'" . $from_date . '-01' . "' AND '" . $to_date . '-01' . "'
GROUP BY
	`master`.`month`,`master`.`disease_id`
		ORDER BY
	sum DESC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    //    xxxxxxxxxxxxxxxxxxxxxxxxx  FOCUSED DISEASE DILLDOWN DASHBOARD END  xxxxxxxxxxxxxxxxxxxxxx
    
    //    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID DASHBOARD QUERIES START    xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    
    public function getTotalTestCases_1($from_date, $to_date, $label){
		      $q = "SELECT
	SUM( test_and_cases.pcr_in_last_24_hours ) AS pcr,
	SUM( test_and_cases.rapid_in_last_24_hours ) AS rat 
FROM
	`test_and_cases` 
WHERE date BETWEEN'" . $from_date  . "' AND '" . $to_date . "' AND
	`test_and_cases`.`status` = '1' ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
	}// end getTotalTestCases function

	   public function getTotalConfirmCases_1($from_date, $to_date, $label){
		      $q = "SELECT
	SUM( cases.pcases_in_last_24_hours ) AS pcr_positive,
	SUM( cases.acases_in_last_24_hrs ) AS rat_positive 
FROM
	`cases` 
WHERE date BETWEEN'" . $from_date  . "' AND '" . $to_date . "' AND
	`cases`.`status` = '1' ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
	}// end getTotalTestCases function
    
    
     function positive_cases_province($from_date, $to_date, $prov_id) {
        $q = "SELECT
	SUM(cases.pcases_in_last_24_hours) AS pcr,
	SUM(cases.acases_in_last_24_hrs) AS rat,
	locations.location_name province 
FROM
	cases
	INNER JOIN locations ON cases.province_id = locations.pk_id 
         WHERE date BETWEEN'" . $from_date  . "' AND '" . $to_date . "'
GROUP BY
	cases.province_id";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
     function positive_cases_dist($from_date, $to_date, $label) {
        $q = "SELECT
	situations.confirm_cases_in_last_24_hrs AS total,
	locations.location_name name 
FROM
	situations
	INNER JOIN locations ON situations.district_id = locations.pk_id
	WHERE situations.province_id = '" . $label . "'    ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
      function vents_data($from_date, $to_date, $prov_id) {
        $q = "SELECT 
	SUM(ventilators.available_ventilators) AS available_ventilators, 
	SUM(ventilators.ventilators_allocated_for_covid) AS ventilators_allocated_for_covid, 
	SUM(ventilators.ventilators_occupied_by_covid_patients) AS ventilators_occupied_by_covid_patients, 
	SUM(ventilators.currently_vacant_ventilators) AS currently_vacant_ventilators, 
	SUM(ventilators.vacant_non_covid_vents) AS vacant_non_covid_vents
FROM
	ventilators
        WHERE date BETWEEN'" . $from_date  . "' AND '" . $to_date . "'";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
     function vent_drill($from_date, $to_date, $label) {
        $q = "SELECT
	SUM( ventilators.$label) AS total,
	locations.location_name location 
FROM
	ventilators
	INNER JOIN locations ON ventilators.province_id = locations.pk_id
        WHERE ventilators.date BETWEEN'" . $from_date  . "' AND '" . $to_date . "'
	GROUP BY ventilators.province_id";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
      function vent_drill_districtwise($from_date, $to_date, $prov_id, $label2) {
        $q = "SELECT
	ventilators.$label2 AS total,
	locations.location_name name 
FROM
	ventilators
	INNER JOIN locations ON ventilators.district_id = locations.pk_id 
WHERE ventilators.date BETWEEN'" . $from_date  . "' AND '" . $to_date . "' AND
	ventilators.province_id =  '" . $prov_id . "'   ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
    function death_data($from_date, $to_date, $prov_id) {
        $q = "SELECT
	SUM(death_and_suspects.died_in_hospital_on_ventilator) AS On_Ventilator, 
	SUM(death_and_suspects.died_in_hospital_off_ventilator) Off_Ventilator, 
	SUM(death_and_suspects.died_at_home_or_elsewhere) AS Home_ElseWhere
FROM
	death_and_suspects
         WHERE date BETWEEN'" . $from_date  . "' AND '" . $to_date . "' ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
       function oxygen_beds($from_date, $to_date, $prov_id) {
        $q = "SELECT
	SUM(oxygen.available_oxygen_beds) AS available_oxygen_beds, 
	SUM(oxygen.available_oxygen_beds_for_covid) AS available_oxygen_beds_for_covid, 
	SUM(oxygen.oxygen_beds_occupied_by_covid_patients) AS oxygen_beds_occupied_by_covid_patients, 
	SUM(oxygen.vacant_beds_with_oxygen) AS vacant_beds_with_oxygen
FROM
	oxygen
        WHERE date BETWEEN'" . $from_date  . "' AND '" . $to_date . "' ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
     function bed_drill($from_date, $to_date, $label) {
        $q = "SELECT
	SUM( oxygen.$label) AS total,
	locations.location_name province 
FROM
	oxygen
	INNER JOIN locations ON oxygen.province_id = locations.pk_id 
        WHERE oxygen.date BETWEEN'" . $from_date  . "' AND '" . $to_date . "'
GROUP BY
	oxygen.province_id";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
      function bed_drill_districtwise($from_date, $to_date, $prov_id, $label2) {
        $q = "SELECT
	oxygen.$label2 AS total,
	locations.location_name name 
FROM
	oxygen
	INNER JOIN locations ON oxygen.district_id = locations.pk_id 
WHERE oxygen.date BETWEEN'" . $from_date  . "' AND '" . $to_date . "' AND
	oxygen.province_id =  '" . $prov_id . "'   ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
    function patient_summary($from_date, $to_date, $prov_id) {
        $q = "SELECT
        locations.location_name location,	
        SUM(clinical_status.patients_on_low_flow_oxygen)patients_on_low_flow_oxygen, 
	SUM(clinical_status.patients_on_high_flow_oxygen)patients_on_high_flow_oxygen, 
	SUM(clinical_status.patients_on_ventilator)patients_on_ventilator, 
	SUM(clinical_status.patients_in_quarantine)patients_in_quarantine
FROM
	clinical_status
	INNER JOIN
	locations
	ON 
		clinical_status.province_id = locations.pk_id
GROUP BY
	clinical_status.province_id  ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
//        ----------------------      ID DASHBOARD END        --------------------------
    
//        ----------------------     Ventilator MAP  START      --------------------------    
     function products() {
        $q = "SELECT
	DISTINCT (map_data.itm_id), 
	map_data.itm_name
FROM
	map_data
        WHERE map_data.itm_id IN (2133,2143,2147,3029,3030,3588,3754)";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    function dist_stock($prod_id) {
        $q = "SELECT
            map_data.province,
            map_data.province_id,
	map_data.district,
	map_data.wh_name, 
	map_data.itm_name, 
	SUM(map_data.qty) qty
FROM
	map_data
	WHERE
	itm_id = '$prod_id'
	GROUP BY
	wh_id ORDER BY map_data.province_id ASC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
      function main_query() {
        $q = "SELECT
	prov.location_name Province,
	dist.location_name District,
	dist.pk_id district_id,
	dist.location_name wh_name,
        dist.location_name batches,
	dist.pk_id wh_id,
	ventilators.available_ventilators Qty
FROM
	ventilators
	INNER JOIN locations AS prov ON ventilators.province_id = prov.pk_id
	INNER JOIN locations AS dist ON ventilators.district_id = dist.pk_id";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
//        ----------------------     Ventilator MAP  END      --------------------------        
        
        
}// end Dashboard_model class
?>