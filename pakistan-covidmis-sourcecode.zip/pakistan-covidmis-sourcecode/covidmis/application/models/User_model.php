<?php
	class User_model extends CI_model{
		public function getAll(){
			$this->db->select('users.pk_id, users.user_name, users.password, users.role_id, users.login_id, users.email, users.cell_number, users.designation, users.status');
			$this->db->from('users');
			$this->db->order_by('users.pk_id', 'DESC');
			$result = $this->db->get();
			return $result->result_array();
		}//end getAll function

		public function user_roles(){
			$this->db->where_not_in('loin_id', array('admin', 'rni'));
			$result = $this->db->get('role_id');
			return $result->result_array();
		}//end user_roles function

		public function check_username($username){
			$this->db->select('user_name');
			$this->db->from('users');
			$this->db->where('user_name', $username);
			$result = $this->db->get();
			return $result->result_array();
		}//end check_username function

		public function create($formArray){
			$result = $this->db->insert('users', $formArray);
			return $result;
		}//end create function

		public function find_by_id($id){
			$this->db->where('pk_id', $id);
			$result = $this->db->get('users');
			return $result->result_array();
		}//end find_by_id function

		public function update($id, $formArray){
			$this->db->where('pk_id', $id);
			$result = $this->db->update('users', $formArray);
			return $result;
		}//end update function

		public function delete($id, $dataArray){
			$this->db->where('pk_id', $id);
			$result = $this->db->update('users', $dataArray);
			return $result;
		}//end delete function

		public function update_password($id, $password){
			$this->db->where('pk_id', $id);
			$result = $this->db->update('users', $password);
			return $result;
		}
	}//end User_model class
?>