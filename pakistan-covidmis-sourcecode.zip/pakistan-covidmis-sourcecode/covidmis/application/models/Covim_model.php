<?php

class covim_model extends CI_model {

//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVIM DASHBOARD START  xxxxxxxxxxxxxxxxxxxxxx
    function product() {
        $q = "SELECT
	covim_items.item_code,
	GROUP_CONCAT(covim_items.item_name) item_name
FROM
	covim_items 
WHERE
	covim_items.item_category = 1 
GROUP BY
	covim_items.item_code";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function consumption($from_date, $to_date) {
        $q = "SELECT
	covim_consumption.item_pack_size_id pk_id,
	SUM( covim_consumption.issue_balance ) consumption	
FROM
	covim_consumption 
WHERE
	covim_consumption.reporting_start_date BETWEEN '" . $from_date . "' 
	AND '" . $to_date . "'
	GROUP BY covim_consumption.item_pack_size_id";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function stock_on_hand($from_date, $to_date) {
        $q = "SELECT
covim_consumption.item_pack_size_id AS pk_id,
	(getOB('" . $from_date . "',covim_consumption.item_pack_size_id)+SUM(covim_consumption.received_balance)-SUM(covim_consumption.issue_balance)) soh
FROM
	covim_consumption 
WHERE
	DATE_FORMAT( covim_consumption.reporting_start_date, '%Y-%m-%d' ) BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	GROUP BY covim_consumption.item_pack_size_id";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

      function monthly_consumption($from_date, $to_date) {
        $q = "SELECT
	DATE_FORMAT(covim_consumption.reporting_start_date,'%Y-%m') dmonth,
	SUM(covim_consumption.issue_balance) consumption 
FROM
	covim_consumption 
        WHERE DATE_FORMAT(covim_consumption.reporting_start_date,'%Y-%m') BETWEEN '" . $from_date . "'  AND '" . $to_date . "'
GROUP BY
	DATE_FORMAT(covim_consumption.reporting_start_date,'%Y-%m') ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
          function monthly_wastage($from_date, $to_date) {
        $q ="SELECT
	A.rep_month,
	SUM( A.wastagerate ) wastages 
FROM
	(
	SELECT
		DATE_FORMAT( covim_consumption.reporting_start_date, '%Y-%m' ) AS rep_month,
		ROUND( SUM( covim_consumption.issue_balance )* IFNULL( covim_items.wastage_rate_allowed, 0 )/ 100 ) wastagerate 
	FROM
		covim_consumption
		INNER JOIN covim_items ON covim_consumption.item_pack_size_id = covim_items.pk_id 
                WHERE DATE_FORMAT(covim_consumption.reporting_start_date,'%Y-%m') BETWEEN '" . $from_date . "'  AND '" . $to_date . "'
	GROUP BY
		DATE_FORMAT( covim_consumption.reporting_start_date, '%Y-%m' ),
		covim_consumption.item_pack_size_id 
	) A 
GROUP BY
	A.rep_month ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
         function consumption_pattern($from_date, $to_date) {
        $q ="SELECT
	DATE_FORMAT(covim_consumption.reporting_start_date,'%Y-%m') dmonth,
	SUM(covim_consumption.issue_balance) consumption 
FROM
	covim_consumption 
WHERE DATE_FORMAT(covim_consumption.reporting_start_date,'%Y-%m') BETWEEN '" . $from_date . "'  AND '" . $to_date . "'
GROUP BY
	DATE_FORMAT(covim_consumption.reporting_start_date,'%Y-%m')
        ORDER BY
	covim_consumption.reporting_start_date ASC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVIM DISEASES DASHBOARD END  xxxxxxxxxxxxxxxxxxxxxx
    
    //    xxxxxxxxxxxxxxxxxxxxxxxxx  Drilldown DASHBOARD START  xxxxxxxxxxxxxxxxxxxxxx
    
       function product_drill($product_name) {
        $q =  "SELECT
	covim_items.item_code
        FROM
	covim_items
	Where 
	covim_items.item_name = '" . $product_name . "'  ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
       function province_consumption($from, $to,$item_code) {
        $q =  "SELECT
	covim_consumption.item_pack_size_id AS item_id,
	covim_provinces.province,
	SUM( covim_consumption.issue_balance ) AS consumption 
FROM
	covim_consumption
	INNER JOIN covim_facilities ON covim_consumption.warehouse_id = covim_facilities.facility_code
	INNER JOIN covim_districts ON covim_facilities.district = covim_districts.distcode
	INNER JOIN covim_provinces ON covim_districts.province = covim_provinces.procode 
WHERE
	DATE_FORMAT( covim_consumption.reporting_start_date, '%Y-%m-%d' ) BETWEEN '" . $from . "' AND '" . $to . "'
	AND covim_consumption.item_pack_size_id =  '" . $item_code . "'
GROUP BY
	covim_provinces.procode ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
       function province_soh($from_date, $to_date,$item_code) {
        $q =  "SELECT
	SUM(covim_consumption.closing_balance) AS soh, 
	covim_provinces.province
FROM
	covim_consumption
	INNER JOIN
	covim_facilities
	ON 
		covim_consumption.warehouse_id = covim_facilities.facility_code
	INNER JOIN
	covim_districts
	ON 
		covim_facilities.district = covim_districts.distcode
	INNER JOIN
	covim_provinces
	ON 
		covim_districts.province = covim_provinces.pro_id
WHERE
	DATE_FORMAT( covim_consumption.reporting_start_date, '%Y-%m-%d' ) BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	AND covim_consumption.item_pack_size_id =  '" . $item_code . "'
GROUP BY
	covim_districts.province ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
    
       function prov_id($province) {
        $q =  "SELECT
	covim_provinces.pro_id
FROM
	covim_provinces
WHERE
	covim_provinces.province = '" . $province . "'  ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
       function district_consumption($prov_id,$from_date,$to_date,$item_code) {
        $q =  "SELECT
	covim_consumption.item_pack_size_id AS item_id,
	covim_districts.district,
	SUM( covim_consumption.issue_balance ) AS consumption 
FROM
	covim_consumption
	INNER JOIN covim_facilities ON covim_consumption.warehouse_id = covim_facilities.facility_code
	INNER JOIN covim_districts ON covim_facilities.district = covim_districts.distcode 
WHERE
	covim_districts.province = '" . $prov_id . "' 
	AND DATE_FORMAT( covim_consumption.reporting_start_date, '%Y-%m-%d' ) BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	AND covim_consumption.item_pack_size_id = '" . $item_code . "' 
GROUP BY
	covim_districts.distid ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
      function district_soh($prov_id,$from_date,$to_date,$item_code) {
        $q =  "SELECT
	covim_districts.district, 
	SUM(covim_consumption.closing_balance) AS soh
FROM
	covim_consumption
	INNER JOIN
	covim_facilities
	ON 
		covim_consumption.warehouse_id = covim_facilities.facility_code
	INNER JOIN
	covim_districts
	ON 
		covim_facilities.district = covim_districts.distcode
WHERE
	DATE_FORMAT( covim_consumption.reporting_start_date, '%Y-%m-%d' ) BETWEEN '" . $from_date . "' AND '" . $to_date . "'
AND
	covim_districts.province = '" . $prov_id . "' 
	AND covim_consumption.item_pack_size_id = '" . $item_code . "'
GROUP BY
	covim_districts.distid ";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
   //    xxxxxxxxxxxxxxxxxxxxxxxxx  Drilldown DASHBOARD END  xxxxxxxxxxxxxxxxxxxxxx

    
    
}

?>
