<?php
class Hcp_model extends CI_model{
	
	public function create($formArray){
		$result = $this->db->get_where('hcp', array('date' => $formArray['date'], 'province_id' => $formArray['province_id'], 'status' => 1))->result_array();
		if (!empty($result[0]['id'])) {
			$this->db->where('id', $result[0]['id']);
			$this->db->update('hcp', $formArray);
		}else{
			$this->db->insert('hcp', $formArray);
		}
	}// end create function

	public function all(){
		$this->db->select('hcp.id, hcp.date, locations.location_name AS province_name, hcp.total_doctors, hcp.total_nurses, hcp.other_health_staff, hcp.total_infected, hcp.total_in_isolation, hcp.total_in_hospital, hcp.total_stable, hcp.total_on_ventilator, hcp.total_recovered_or_discharged, hcp.total_died');
		$this->db->from('hcp');
		$this->db->join('locations', 'locations.pk_id = hcp.province_id');
		$this->db->where('hcp.status', 1);
		$this->db->order_by('hcp.id', 'DESC');
		return $this->db->get()->result_array();
	}// end all function

	public function getProvinces(){
		return $this->db->get_where('locations', array('parent_id' => 10))->result_array();
	}// end getProvinces function

	public function getTestCategories(){
		return $this->db->get_where('test_categories', array('status' => 1))->result_array();
	}// end getTestCategories function

	public function getTestTypes(){
		return $this->db->get_where('test_types', array('status' => 1))->result_array();
	}//end getTestTypes function

	public function getDataById($id){
		$data = $this->db->get_where('hcp', array('id' => $id, 'status' => 1));
		return $data->result_array();
	}// end getDataById function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('hcp', $formArray);
	}// end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('hcp');
	}// end delete function
}// end Hcp_model class
?>