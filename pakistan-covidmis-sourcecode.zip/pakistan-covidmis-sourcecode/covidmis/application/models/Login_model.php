<?php
class Login_model extends CI_model{
	function login($username, $password){
		$user = $this->db->get_where('users', array('login_id' => $username, 'password' => $password));
		// echo $this->db->last_query();die;
		return $user->result_array();
	}
}
?>