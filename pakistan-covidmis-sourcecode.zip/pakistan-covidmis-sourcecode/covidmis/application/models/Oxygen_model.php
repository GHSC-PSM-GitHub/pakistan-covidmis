<?php
class Oxygen_model extends CI_model{
	
	public function create($formArray){
		$result = $this->db->get_where('oxygen', array('date' => $formArray['date'], 'province_id' => $formArray['province_id'], 'district_id' => $formArray['district_id'], 'status' => 1))->result_array();
		if (!empty($result[0]['id'])) {
			$this->db->where('id', $result[0]['id']);
			$this->db->update('oxygen', $formArray);
		}else{
			$this->db->insert('oxygen', $formArray);
		}
	}// end create function

	public function all(){
		$this->db->select('oxygen.id, oxygen.date, locations.location_name AS province_name, dist.location_name AS district_name, oxygen.available_oxygen_beds, oxygen.available_oxygen_beds_for_covid, oxygen.oxygen_beds_occupied_by_covid_patients, oxygen.patients_on_low_oxygen, oxygen.patients_on_high_oxygen, oxygen.vacant_beds_with_oxygen');
		$this->db->from('oxygen');
		$this->db->join('locations', 'locations.pk_id = oxygen.province_id');
		$this->db->join('locations AS dist', 'dist.pk_id = oxygen.district_id');
		$this->db->where('oxygen.status', 1);
		$this->db->order_by('oxygen.id', 'DESC');
		return $this->db->get()->result_array();
	}// end all function

	public function getProvinces(){
		return $this->db->get_where('locations', array('parent_id' => 10))->result_array();
	}// end getProvinces function

	public function getDistricts(){
		return $this->db->get_where('districts', array('status' => 1))->result_array();
	}// end getDistricts function

	public function getDistrictsById($province_id){
		$districts = $this->db->get_where('locations', array('geo_level_id' => 4, 'parent_id' => $province_id));
		return $districts->result_array();
	}// end getDistrictsById function

	public function getTestCategories(){
		return $this->db->get_where('test_categories', array('status' => 1))->result_array();
	}// end getTestCategories function

	public function getTestTypes(){
		return $this->db->get_where('test_types', array('status' => 1))->result_array();
	}//end getTestTypes function

	public function getDataById($id){
		$data = $this->db->get_where('oxygen', array('id' => $id, 'status' => 1));
		return $data->result_array();
	}// end getDataById function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('oxygen', $formArray);
	}// end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('oxygen');
	}// end delete function
}// end Oxygen_model class
?>