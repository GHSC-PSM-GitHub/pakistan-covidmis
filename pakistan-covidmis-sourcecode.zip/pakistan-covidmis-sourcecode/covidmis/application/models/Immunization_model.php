<?php

class immunization_model extends CI_model {
    
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  FDI - USAID Monthly COVAX Reverse Logistics Analysis Start  xxxxxxxxxxxxxxxxxxxxxx
    function reverse_logistics_analysis($from_date, $to_date) {
        $q = "SELECT
	SUM( reverse_logistics_info.return_boxes_qty ) AS sum,
        SUM( reverse_logistics_info.return_boxes_doses ) AS sum_doses,
	DATE_FORMAT( date, '%m-%Y' ) AS month 
FROM
	reverse_logistics_info 
WHERE
	date BETWEEN  '" . $from_date . "' AND '" . $to_date . "' 
GROUP BY
	MONTH ( date ),
	YEAR ( date ) 
        ORDER BY date ASC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  FDI - USAID Monthly COVAX Reverse Logistics Analysis END  xxxxxxxxxxxxxxxxxxxxxx   

//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID MIS - Vaccine Wise Stock Received (Doses) Start  xxxxxxxxxxxxxxxxxxxxxx
    function vaccine_wise_stock_received($from_date, $to_date) {
        $q = "SELECT
	covim_items.item_name AS name,
        SUM( stock_detail.quantity*covim_items.number_of_doses ) total
FROM
	stock_batch_warehouses
        INNER JOIN stock_detail ON stock_batch_warehouses.pk_id = stock_detail.stock_batch_warehouse_id 
        INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON stakeholder_item_pack_sizes.item_pack_size_id = covim_items.vlmis_id	
WHERE
	stock_detail.adjustment_type = 1 
        AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "' 
GROUP BY
	covim_items.item_code";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID MIS - Vaccine Wise Stock Received (Doses) END  xxxxxxxxxxxxxxxxxxxxxx 
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  FDI - USAID COVAX Reverse Logistics Activity Start  xxxxxxxxxxxxxxxxxxxxxx
    function reverse_logistics_activity($from_date, $to_date) {
        $q = "SELECT
	SUM(reverse_logistics_info.return_boxes_qty) AS sum, 
        SUM( reverse_logistics_info.return_boxes_doses ) AS sum_doses,
	reverse_logistics_info.date,
        reverse_logistics_info.activity_type
FROM
	reverse_logistics_info
	WHERE date BETWEEN  '" . $from_date . "' AND '" . $to_date . "'
GROUP BY
        date
        ORDER BY date ASC";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  FDI - USAID COVAX Reverse Logistics Activity END  xxxxxxxxxxxxxxxxxxxxxx    
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID Vaccine Received Start  xxxxxxxxxxxxxxxxxxxxxx
    function covid_vaccine_received($from_date, $to_date) {
        $q = "SELECT
	warehouses.warehouse_name fundingsource,
	SUM( stock_detail.quantity*covim_items.number_of_doses ) totalqty 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1
AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "' GROUP BY warehouses.warehouse_name";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID Vaccine Received END  xxxxxxxxxxxxxxxxxxxxxx  
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID Vaccine - Govt Procured Breakup (Doses) Start  xxxxxxxxxxxxxxxxxxxxxx
    function govt_procured_breakup($from_date, $to_date) {
        $q = "SELECT
	covim_items.item_name itmname,
	SUM( stock_detail.quantity*covim_items.number_of_doses ) totalqty 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1
AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	AND warehouses.pk_id = 3674
	GROUP BY covim_items.item_code
	";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID Vaccine - Govt Procured Breakup (Doses) END  xxxxxxxxxxxxxxxxxxxxxx  

//    xxxxxxxxxxxxxxxxxxxxxxxxx  Region Wise Vaccine Breakup (Doses) Start  xxxxxxxxxxxxxxxxxxxxxx
    function region_vaccine_breakup($from_date, $to_date) {
        $q = "SELECT
	stock_master.transaction_reference,
	SUM( stock_detail.quantity*covim_items.number_of_doses ) totalqty 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1
        AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	GROUP BY stock_master.transaction_reference
	";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  Region Wise Vaccine Breakup (Doses) END  xxxxxxxxxxxxxxxxxxxxxx   
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVAX Facility - Region Wise Vaccine Breakup (Doses) Start  xxxxxxxxxxxxxxxxxxxxxx
    function covax_region_breakup($from_date, $to_date) {
        $q = "SELECT
	stock_master.transaction_reference,
	warehouses.warehouse_name,
	SUM( stock_detail.quantity * covim_items.number_of_doses ) totalqty 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1 
	AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	AND warehouses.pk_id IN (10001043,10001044)
GROUP BY
	stock_master.transaction_reference,
	warehouses.pk_id
	";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx COVAX Facility - Region Wise Vaccine Breakup (Doses) END  xxxxxxxxxxxxxxxxxxxxxx      
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID Vaccine - COVAX Facility Breakup (Doses) Start  xxxxxxxxxxxxxxxxxxxxxx
    function covax_facility_breakup($from_date, $to_date) {
        $q = "SELECT
	covim_items.item_name,
	SUM( stock_detail.quantity*covim_items.number_of_doses ) totalqty 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1
AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	AND warehouses.pk_id IN (10001043,10001044)
	GROUP BY covim_items.item_code
	";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID Vaccine - COVAX Facility Breakup (Doses) END  xxxxxxxxxxxxxxxxxxxxxx  
 
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID Vaccine - Donation Breakup (Doses) Start  xxxxxxxxxxxxxxxxxxxxxx
    function donation_breakup($from_date, $to_date) {
        $q = "SELECT
	covim_items.item_name,
	SUM( stock_detail.quantity*covim_items.number_of_doses ) totalqty 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1
AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	AND warehouses.pk_id = 10001045
	GROUP BY covim_items.item_code
	";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVID Vaccine - Donation Breakup (Doses) END  xxxxxxxxxxxxxxxxxxxxxx       

//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVAX USG Breakup (Doses) Start  xxxxxxxxxxxxxxxxxxxxxx
    function covax_usg_breakup($from_date, $to_date) {
        $q = "	SELECT
	covim_items.item_name itmname,
	SUM( stock_detail.quantity*covim_items.number_of_doses ) totalqty 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1
AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	AND warehouses.pk_id = 10001044
	GROUP BY covim_items.item_code";       // fields name = totalqty, itmname
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx   COVAX USG Breakup (Doses) END  xxxxxxxxxxxxxxxxxxxxxx    
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVAX CHINESE Breakup (Doses) Start  xxxxxxxxxxxxxxxxxxxxxx
    function covax_chinese_breakup($from_date, $to_date) {
        $q = "SELECT
	covim_items.item_name itmname,
	SUM( stock_detail.quantity*covim_items.number_of_doses ) totalqty 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1
AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	AND stock_master.transaction_reference = 'China'
        AND warehouses.pk_id IN (10001043)
	GROUP BY covim_items.item_code";       // fields name = totalqty, itmname
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx   COVAX CHINESE Breakup (Doses) END  xxxxxxxxxxxxxxxxxxxxxx 

//    xxxxxxxxxxxxxxxxxxxxxxxxx  COVAX WESTERN Breakup (Doses) Start  xxxxxxxxxxxxxxxxxxxxxx
    function covax_western_breakup($from_date, $to_date) {
        $q = "SELECT
	covim_items.item_name itmname,
	SUM( stock_detail.quantity*covim_items.number_of_doses ) totalqty 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1
AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	AND stock_master.transaction_reference = 'Western'
        AND warehouses.pk_id IN (10001043)
	GROUP BY covim_items.item_code";   // fields name = totalqty, itmname
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx   COVAX WESTERN Breakup (Doses) END  xxxxxxxxxxxxxxxxxxxxxx  

//    xxxxxxxxxxxxxxxxxxxxxxxxx  Yearly Comparison Start  xxxxxxxxxxxxxxxxxxxxxx
    function yearly_comp() {
        $q = "SELECT
	warehouses.warehouse_name fundingsource,
	SUM( stock_detail.quantity * covim_items.number_of_doses ) totalqty,
	EXTRACT( YEAR FROM stock_master.transaction_date ) year 
FROM
	stock_detail
	INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
	INNER JOIN warehouses ON stock_master.from_warehouse_id = warehouses.pk_id
	INNER JOIN stock_batch_warehouses ON stock_detail.stock_batch_warehouse_id = stock_batch_warehouses.pk_id
	INNER JOIN stock_batch ON stock_batch_warehouses.stock_batch_id = stock_batch.pk_id
	INNER JOIN pack_info ON stock_batch.pack_info_id = pack_info.pk_id
	INNER JOIN stakeholder_item_pack_sizes ON pack_info.stakeholder_item_pack_size_id = stakeholder_item_pack_sizes.pk_id
	INNER JOIN covim_items ON covim_items.vlmis_id = stakeholder_item_pack_sizes.item_pack_size_id 
WHERE
	stock_master.transaction_type_id = 1 
	AND YEAR(stock_master.transaction_date ) IN ( 2021, 2022 ) 
GROUP BY
	warehouses.warehouse_name,
	YEAR(stock_master.transaction_date)
         ORDER BY warehouses.warehouse_name";   // fields name = totalqty, itmname
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//     function yearly_comp() {
//        $q = "SELECT
//	temp_table.fundingsource, 
//	temp_table.totalqty, 
//	temp_table.`year`
//FROM
//	temp_table
//        ORDER BY temp_table.fundingsource ASC";   // fields name = totalqty, itmname
//        $query = $this->db->query($q);
////        echo $this->db->last_query(); exit;
//        return $query->result_array();
//    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx   Yearly Comparison END  xxxxxxxxxxxxxxxxxxxxxx      
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx  Daily Vaccination  Start  xxxxxxxxxxxxxxxxxxxxxx
    function total_vaccination($from_date, $to_date) {
        $q = "SELECT
	SUM( vaccine_data.first_dose ) AS first_dose,
	SUM( vaccine_data.full_vaccinated ) AS full_vaccinated,
	SUM( vaccine_data.booster_1 ) + SUM( vaccine_data.booster_2 ) AS booster
FROM
	vaccine_data
	";   // fields name = totalqty, itmname
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
     function daily_vaccination($from_date, $to_date) {
         $from_date = date('Y-m-d', strtotime('-1 days'));
                 $to_date = date('Y-m-d', strtotime('-1 days'));
        $q = "SELECT
vaccine_data.date,
	SUM( vaccine_data.first_dose ) AS first_dose,
	SUM( vaccine_data.full_vaccinated ) AS full_vaccinated,
	SUM( vaccine_data.booster_1 ) + SUM( vaccine_data.booster_2 ) AS booster 
FROM
	vaccine_data 
WHERE
	vaccine_data.date = (
	SELECT
		MAX( vaccine_data.date ) 
FROM
	vaccine_data)
	";   // fields name = totalqty, itmname
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
     function daily_vaccination_1($from_date, $to_date) {
        $q = "SELECT
	SUM( vaccine_data.first_dose ) AS first_dose,
	SUM( vaccine_data.full_vaccinated ) AS full_vaccinated,
	SUM( vaccine_data.booster_1 ) + SUM( vaccine_data.booster_2 ) AS booster
FROM
	vaccine_data
WHERE
	vaccine_data.date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
	";   // fields name = totalqty, itmname
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxx   Daily Vaccination  END  xxxxxxxxxxxxxxxxxxxxxx     
       function is_request_from_mobile(){
    $useragent=$_SERVER['HTTP_USER_AGENT'];
    if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
    {
        return true;
    }
    else{
        return false;
    }
}
    
}

?>
