<?php
class Test_category_model extends CI_model{
	
	public function create($formArray){
		$this->db->insert('test_categories', $formArray);
	}//end create function

	public function all(){
		return $this->db->get_where('test_categories', array('status' => 1))->result_array();
	}//end all function

	public function getTestCategory($id){
		$province = $this->db->get_where('test_categories', array('id' => $id, 'status' => 1));
		return $province->result_array();
	}//end getTestCategory function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('test_categories', $formArray);
	}//end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('test_categories');
	}//end delete function
}//end Test_category_model class
?>