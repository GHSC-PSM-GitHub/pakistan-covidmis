<?php

//require_once 'database.php';
class Admin_model extends CI_Model {

    private $conn;


        //    ************************************************** PRODUCT MANAGEMENT START***********************************************************************

    public function displayproduct($from,$to) {
        $qry = "SELECT
	`vaccine_data`.`pk_id`,
	`vaccine_data`.`date`,
	`vaccine_data`.`first_dose`,
	`vaccine_data`.`full_vaccinated`,
	`vaccine_data`.`booster_1`,
	vaccine_data.booster_2 
FROM
	`vaccine_data` 
WHERE
	date BETWEEN'" . $from  . "' AND '" . $to . "'  	
        ORDER BY
	date ASC";
        $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function savemproduct($data) {
        $query = $this->db->insert("vaccine_data", $data);
        return $query;
    }
 public function fetch_product($id) {
        $this->db->select('*');
        $this->db->from('vaccine_data');
        $this->db->where("pk_id", $id);
        $query = $this->db->get();
//           echo $this->db->last_query(); exit;
        return $query->result_array();
    }
//
    function edit_product($data, $id) {
        $this->load->database();
        $this->db->select("*");
        $this->db->from("vaccine_data");
        $this->db->where("pk_id", $id);
        $query = $this->db->update("vaccine_data", $data);
//          echo $this->db->last_query(); exit;
        return $query;
    }

 
//    ********************************************** PRODUCT MANAGEMENT END  *******************************************************************  
  
    
}
