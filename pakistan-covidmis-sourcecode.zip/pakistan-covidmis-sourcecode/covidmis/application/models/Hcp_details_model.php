<?php
class Hcp_details_model extends CI_model{
	
	public function create($formArray){
		$result = $this->db->get_where('hcp_details', array('date' => $formArray['date'], 'province_id' => $formArray['province_id'], 'status' => 1))->result_array();
		if (!empty($result[0]['id'])) {
			$this->db->where('id', $result[0]['id']);
			$this->db->update('hcp_details', $formArray);
		}else{
			$this->db->insert('hcp_details', $formArray);
		}
	}// end create function

	public function all(){
		$this->db->select('hcp_details.id, hcp_details.date, locations.location_name AS province_name, hcp_details.confirmed_cases_of_workers, hcp_details.performing_duties, hcp_details.performing_duties_elsewhere, hcp_details.contacts_identified, hcp_details.contacts_in_quarantine, hcp_details.contacts_tested_today, hcp_details.results_received, hcp_details.contacts_found_positive, hcp_details.results_awaited');
		$this->db->from('hcp_details');
		$this->db->join('locations', 'locations.pk_id = hcp_details.province_id');
		$this->db->where('hcp_details.status', 1);
		$this->db->order_by('hcp_details.id', 'DESC');
		return $this->db->get()->result_array();
	}// end all function

	public function getProvinces(){
		return $this->db->get_where('locations', array('parent_id' => 10))->result_array();
	}// end getProvinces function

	public function getTestCategories(){
		return $this->db->get_where('test_categories', array('status' => 1))->result_array();
	}// end getTestCategories function

	public function getTestTypes(){
		return $this->db->get_where('test_types', array('status' => 1))->result_array();
	}//end getTestTypes function

	public function getDataById($id){
		$data = $this->db->get_where('hcp_details', array('id' => $id, 'status' => 1));
		return $data->result_array();
	}// end getDataById function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('hcp_details', $formArray);
	}// end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('hcp_details');
	}// end delete function
}// end Hcp_details_table_3b_model class
?>