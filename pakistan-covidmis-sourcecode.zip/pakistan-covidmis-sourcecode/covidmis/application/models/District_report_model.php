<?php
class District_report_model extends CI_model{
	
	public function getSituationsData($date = ''){
		$this->db->select('situations.id, situations.date, locations.pk_id AS province_id, locations.location_name AS province_name, locations.pk_id AS district_id, locations.location_name AS district_name, situations.covid_test_in_last_24_hrs, situations.confirm_cases_in_last_24_hrs, situations.s_in_quarantine, situations.s_admitted_in_hospital, situations.cumulative, situations.s_clinically_stable, situations.s_on_low_flow_oxygen, situations.s_on_high_flow_oxygen, situations.s_on_ventilator, situations.s_of_new_patients_admitted_in_hospital, situations.s_in_last_24_hrs');
		$this->db->from('situations');
		$this->db->join('locations', 'locations.pk_id = situations.province_id');
		$this->db->join('locations AS dist', 'dist.pk_id = situations.district_id');
		if ($date != '') {
			$this->db->where('situations.date', $date);
		}
		$this->db->where('situations.status', 1);
		$this->db->group_by('situations.date, situations.province_id, situations.district_id');
		return $this->db->get()->result_array();
	}// end getSituationsData function

	public function getOxygenData($date = ''){
		$this->db->select('oxygen.id, oxygen.date, locations.pk_id AS province_id, locations.location_name AS province_name, locations.pk_id AS district_id, locations.location_name AS district_name, oxygen.available_oxygen_beds, oxygen.available_oxygen_beds_for_covid, oxygen.oxygen_beds_occupied_by_covid_patients, oxygen.patients_on_low_oxygen, oxygen.patients_on_high_oxygen, oxygen.vacant_beds_with_oxygen');
		$this->db->from('oxygen');
		$this->db->join('locations', 'locations.pk_id = oxygen.province_id');
		$this->db->join('locations AS dist', 'dist.pk_id = oxygen.district_id');
		if ($date != '') {
			$this->db->where('oxygen.date', $date);
		}
		$this->db->where('oxygen.status', 1);
		$this->db->group_by('oxygen.date, oxygen.province_id, oxygen.district_id');
		return $this->db->get()->result_array();
	}// end getOxygenData function

	public function getVentilatorsData($date = ''){
		$this->db->select('ventilators.id, ventilators.date, locations.pk_id AS province_id, locations.location_name AS province_name, locations.pk_id AS district_id, locations.location_name AS district_name, ventilators.available_ventilators, ventilators.ventilators_allocated_for_covid, ventilators.ventilators_occupied_by_covid_patients, ventilators.currently_vacant_ventilators, ventilators.vacant_non_covid_vents');
		$this->db->from('ventilators');
		$this->db->join('locations', 'locations.pk_id = ventilators.province_id');
		$this->db->join('locations AS dist', 'dist.pk_id = ventilators.district_id');
		if ($date != '') {
			$this->db->where('ventilators.date', $date);
		}
		$this->db->where('ventilators.status', 1);
		$this->db->group_by('ventilators.date, ventilators.province_id, ventilators.district_id');
		return $this->db->get()->result_array();
	}// end getVentilatorsData function
}// end District_report_model class
?>