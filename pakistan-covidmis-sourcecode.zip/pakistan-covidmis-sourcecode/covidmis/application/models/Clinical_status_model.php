<?php
class Clinical_status_model extends CI_model{
	
	public function create($formArray){
		$result = $this->db->get_where('clinical_status', array('date' => $formArray['date'], 'province_id' => $formArray['province_id'], 'status' => 1))->result_array();
		if (!empty($result[0]['id'])) {
			$this->db->where('id', $result[0]['id']);
			$this->db->update('clinical_status', $formArray);
		}else{
			$this->db->insert('clinical_status', $formArray);
		}
	}// end create function

	public function all(){
		$this->db->select('clinical_status.id, clinical_status.date, locations.location_name AS province_name, clinical_status.beds_for_covid_patients, clinical_status.hospitals_for_covid_isolation, clinical_status.oxygen_beds_facility_for_covid_patients, clinical_status.vantilators_for_covid_patients, clinical_status.admitted_in_last_24_hours, clinical_status.covid_patients_currently_admitted, clinical_status.patients_clinically_stable, clinical_status.patients_on_low_flow_oxygen, clinical_status.patients_on_high_flow_oxygen, clinical_status.patients_on_ventilator, clinical_status.patients_in_quarantine, clinical_status.patients_recovered_and_discharged, clinical_status.total_deaths_today');
		$this->db->from('clinical_status');
		$this->db->join('locations', 'locations.pk_id = clinical_status.province_id');
		$this->db->where('clinical_status.status', 1);
		$this->db->order_by('clinical_status.id', 'DESC');
		return $this->db->get()->result_array();
	}// end all function

	public function getProvinces(){
		return $this->db->get_where('locations', array('parent_id' => 10))->result_array();
	}// end getProvinces function

	public function getTestCategories(){
		return $this->db->get_where('test_categories', array('status' => 1))->result_array();
	}// end getTestCategories function

	public function getTestTypes(){
		return $this->db->get_where('test_types', array('status' => 1))->result_array();
	}//end getTestTypes function

	public function getDataById($id){
		$data = $this->db->get_where('clinical_status', array('id' => $id, 'status' => 1));
		return $data->result_array();
	}// end getDataById function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('clinical_status', $formArray);
	}// end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('clinical_status');
	}// end delete function
}// end Clinical_status_model class
?>