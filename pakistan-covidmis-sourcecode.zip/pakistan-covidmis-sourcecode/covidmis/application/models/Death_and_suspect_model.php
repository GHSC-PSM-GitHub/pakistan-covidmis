<?php
class Death_and_suspect_model extends CI_model{
	
	public function create($formArray){
		$result = $this->db->get_where('death_and_suspects', array('date' => $formArray['date'], 'province_id' => $formArray['province_id'], 'status' => 1))->result_array();
		if (!empty($result[0]['id'])) {
			$this->db->where('id', $result[0]['id']);
			$this->db->update('death_and_suspects', $formArray);
		}else{
			$this->db->insert('death_and_suspects', $formArray);
		}
	}// end create function

	public function all(){
		$this->db->select('death_and_suspects.id, death_and_suspects.date, locations.location_name AS province_name, death_and_suspects.death_in_last_24_hours, death_and_suspects.died_in_hospital_on_ventilator, death_and_suspects.died_in_hospital_off_ventilator, death_and_suspects.died_at_home_or_elsewhere, death_and_suspects.suspect_contacts_of_known_covid_pts, death_and_suspects.others_suspected, death_and_suspects.suspects_in_last_24_hrs');
		$this->db->from('death_and_suspects');
		$this->db->join('locations', 'locations.pk_id = death_and_suspects.province_id');
		$this->db->where('death_and_suspects.status', 1);
		$this->db->order_by('death_and_suspects.id', 'DESC');
		return $this->db->get()->result_array();
	}// end all function

	public function getProvinces(){
		return $this->db->get_where('locations', array('parent_id' => 10))->result_array();
	}// end getProvinces function

	public function getTestCategories(){
		return $this->db->get_where('test_categories', array('status' => 1))->result_array();
	}// end getTestCategories function

	public function getTestTypes(){
		return $this->db->get_where('test_types', array('status' => 1))->result_array();
	}//end getTestTypes function

	public function getDataById($id){
		$data = $this->db->get_where('death_and_suspects', array('id' => $id, 'status' => 1));
		return $data->result_array();
	}// end getDataById function

	public function update($id, $formArray){
		$this->db->where('id', $id);
		$this->db->update('death_and_suspects', $formArray);
	}// end update function

	public function delete($id){
		$this->db->set('status', 0);
		$this->db->where('id', $id);
		return $this->db->update('death_and_suspects');
	}// end delete function
}// end Death_and_suspect_model class
?>