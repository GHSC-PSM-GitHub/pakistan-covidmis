<?php
class Provincial_report_model extends CI_model{
	
	public function getTestAndCasesProvincialData($date = ''){
		$this->db->select('test_and_cases.id, test_and_cases.date, locations.pk_id AS province_id, locations.location_name AS province_name, SUM(test_and_cases.pcr_in_last_24_hours) AS pcr_in_last_24_hours, SUM(test_and_cases.rapid_in_last_24_hours) AS rapid_in_last_24_hours');
		$this->db->from('test_and_cases');
		$this->db->join('locations', 'locations.pk_id = test_and_cases.province_id');
		if ($date != '') {
			$this->db->where('test_and_cases.date', $date);
		}
		$this->db->where('test_and_cases.status', 1);
		$this->db->group_by('test_and_cases.date, test_and_cases.province_id');
		$result = $this->db->get()->result_array();
		if (!empty($result[0]['id'])) {
			foreach ($result as $key => $value) {
				$this->db->select('SUM(test_and_cases.pcr_in_last_24_hours) AS pcr_till_yesterday, SUM(test_and_cases.rapid_in_last_24_hours) AS rapid_till_yesterday');
				$this->db->from('test_and_cases');
				$this->db->where('province_id', $result[$key]['province_id']);
				$this->db->where('date < ', $result[$key]['date']);
				$result[$key] = array_merge($result[$key], $this->db->get()->result_array()[0]);
			}
		}
		return $result;
	}// end getTestAndCasesProvincialData function

	public function getCasesProvincialData($date = ''){
		$this->db->select('cases.id, cases.date, locations.pk_id AS province_id, locations.location_name AS province_name, SUM(cases.pcases_in_last_24_hours) AS pcases_in_last_24_hours, SUM(cases.acases_in_last_24_hrs) AS acases_in_last_24_hrs');
		$this->db->from('cases');
		$this->db->join('locations', 'locations.pk_id = cases.province_id');
		if ($date != '') {
			$this->db->where('cases.date', $date);
		}
		$this->db->where('cases.status', 1);
		$this->db->group_by('cases.date, cases.province_id');
		$result = $this->db->get()->result_array();
		if (!empty($result[0]['id'])) {
			foreach ($result as $key => $value) {
				$this->db->select('SUM(cases.pcases_in_last_24_hours) AS pcases_till_yesterday, SUM(cases.acases_in_last_24_hrs) AS acases_till_yesterday');
				$this->db->from('cases');
				$this->db->where('province_id', $result[$key]['province_id']);
				$this->db->where('date < ', $result[$key]['date']);
				$result[$key] = array_merge($result[$key], $this->db->get()->result_array()[0]);
			}
		}
		return $result;
	}// end getCasesProvincialData function

	public function getDeathAndSuspectProvincialData($date = ''){
		$this->db->select('death_and_suspects.id, death_and_suspects.date, locations.pk_id AS province_id, locations.location_name AS province_name, SUM(death_and_suspects.death_in_last_24_hours) AS death_in_last_24_hours, SUM(death_and_suspects.died_in_hospital_on_ventilator) AS died_in_hospital_on_ventilator, SUM(death_and_suspects.died_in_hospital_off_ventilator) AS died_in_hospital_off_ventilator, SUM(death_and_suspects.died_at_home_or_elsewhere) AS died_at_home_or_elsewhere, SUM(death_and_suspects.suspect_contacts_of_known_covid_pts) AS suspect_contacts_of_known_covid_pts, SUM(death_and_suspects.others_suspected) AS others_suspected, SUM(death_and_suspects.suspects_in_last_24_hrs) AS suspects_in_last_24_hrs');
		$this->db->from('death_and_suspects');
		$this->db->join('locations', 'locations.pk_id = death_and_suspects.province_id');
		if ($date != '') {
			$this->db->where('death_and_suspects.date', $date);
		}
		$this->db->where('death_and_suspects.status', 1);
		$this->db->group_by('death_and_suspects.date, death_and_suspects.province_id');
		$result = $this->db->get()->result_array();
		if (!empty($result[0]['id'])) {
			foreach ($result as $key => $value) {
				$this->db->select('SUM(death_and_suspects.death_in_last_24_hours) AS death_till_yesterday, SUM(death_and_suspects.suspects_in_last_24_hrs) AS suspect_till_yesterday');
				$this->db->from('death_and_suspects');
				$this->db->where('province_id', $result[$key]['province_id']);
				$this->db->where('date < ', $result[$key]['date']);
				$result[$key] = array_merge($result[$key], $this->db->get()->result_array()[0]);
			}
		}
		return $result;
	}// end getDeathAndSuspectProvincialData function

	public function getClinicalStatusProvincialData($date = ''){
		$this->db->select('clinical_status.id, clinical_status.date, locations.pk_id AS province_id, locations.location_name AS province_name, SUM(clinical_status.beds_for_covid_patients) AS beds_for_covid_patients, SUM(clinical_status.hospitals_for_covid_isolation) AS hospitals_for_covid_isolation, SUM(clinical_status.oxygen_beds_facility_for_covid_patients) AS oxygen_beds_facility_for_covid_patients, SUM(clinical_status.vantilators_for_covid_patients) AS vantilators_for_covid_patients, SUM(clinical_status.admitted_in_last_24_hours) AS admitted_in_last_24_hours, SUM(clinical_status.covid_patients_currently_admitted) AS covid_patients_currently_admitted, SUM(clinical_status.patients_clinically_stable) AS patients_clinically_stable, SUM(clinical_status.patients_on_low_flow_oxygen) AS patients_on_low_flow_oxygen, SUM(clinical_status.patients_on_high_flow_oxygen) AS patients_on_high_flow_oxygen, SUM(clinical_status.patients_on_ventilator) AS patients_on_ventilator, SUM(clinical_status.patients_in_quarantine) AS patients_in_quarantine, SUM(clinical_status.patients_recovered_and_discharged) AS patients_recovered_and_discharged, SUM(clinical_status.total_deaths_today) AS total_deaths_today');
		$this->db->from('clinical_status');
		$this->db->join('locations', 'locations.pk_id = clinical_status.province_id');
		if ($date != '') {
			$this->db->where('clinical_status.date', $date);
		}
		$this->db->where('clinical_status.status', 1);
		$this->db->group_by('clinical_status.date, clinical_status.province_id');
		return $this->db->get()->result_array();
	}// end getClinicalStatusProvincialData function

	public function getHCPProvincialData($date = ''){
		$this->db->select('hcp.id, hcp.date, locations.pk_id AS province_id, locations.location_name AS province_name, SUM(hcp.total_doctors) AS total_doctors, SUM(hcp.total_nurses) AS total_nurses, SUM(hcp.other_health_staff) AS other_health_staff, SUM(hcp.total_infected) AS total_infected, SUM(hcp.total_in_isolation) AS total_in_isolation, SUM(hcp.total_in_hospital) AS total_in_hospital, SUM(hcp.total_stable) AS total_stable, SUM(hcp.total_on_ventilator) AS total_on_ventilator, SUM(hcp.total_recovered_or_discharged) AS total_recovered_or_discharged, SUM(hcp.total_died) AS total_died');
		$this->db->from('hcp');
		$this->db->join('locations', 'locations.pk_id = hcp.province_id');
		if ($date != '') {
			$this->db->where('hcp.date', $date);
		}
		$this->db->where('hcp.status', 1);
		$this->db->group_by('hcp.date, hcp.province_id');
		return $this->db->get()->result_array();
	}// end getHCPProvincialData function

	public function getHCPDetailsProvincialData($date = ''){
		$this->db->select('hcp_details.id, hcp_details.date, locations.pk_id AS province_id, locations.location_name AS province_name, SUM(hcp_details.confirmed_cases_of_workers) AS confirmed_cases_of_workers, SUM(hcp_details.performing_duties) AS performing_duties, SUM(hcp_details.performing_duties_elsewhere) AS performing_duties_elsewhere, SUM(hcp_details.contacts_identified) AS contacts_identified, SUM(hcp_details.contacts_in_quarantine) AS contacts_in_quarantine, SUM(hcp_details.contacts_tested_today) AS contacts_tested_today, SUM(hcp_details.results_received) AS results_received, SUM(hcp_details.contacts_found_positive) AS contacts_found_positive, SUM(hcp_details.results_awaited) AS results_awaited');
		$this->db->from('hcp_details');
		$this->db->join('locations', 'locations.pk_id = hcp_details.province_id');
		if ($date != '') {
			$this->db->where('hcp_details.date', $date);
		}
		$this->db->where('hcp_details.status', 1);
		$this->db->group_by('hcp_details.date, hcp_details.province_id');
		return $this->db->get()->result_array();
	}// end getHCPDetailsProvincialData function
}// end Provincial_report_model class
?>