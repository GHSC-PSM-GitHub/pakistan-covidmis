require("amcharts3/amcharts/amcharts.js");
require("./export.min.js");
